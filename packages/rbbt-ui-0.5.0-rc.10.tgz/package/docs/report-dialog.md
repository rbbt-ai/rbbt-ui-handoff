# ReportDialog · contrato (0.5.0-rc.9)

O verso da carta, em modal. `ReportDialog` é o `Modal`/`Dialog` do react-aria; `ReportBack` é o conteúdo e pode ser usado fora
do modal (documentação, prancha). Não faz rede nem polling: o consumidor atualiza `card.run` e `detail` pelas props.

## Uso

```tsx
<ReportDialog
  isOpen={aberto}
  onClose={() => setAberto(false)}
  returnFocusId="carta-Q03"
  card={carta}
  detail={reportDetailFromRecords({ rows, gaps, history }, mapping)}
  onRerun={(id) => pedirExecucao(id)}
  onRetry={() => pedirExecucao(carta.id)}
  onCopyLink={(id) => navigator.clipboard.writeText(urlDoRelatorio(id))}
/>
```

## Props

| Prop | Tipo | Notas |
| --- | --- | --- |
| `isOpen` / `onClose` | `boolean` / `() => void` | Esc, clique fora e o botão Fechar chamam `onClose`. |
| `returnFocusId` | `string` | Id da carta que abriu; recebe o foco ao fechar. |
| `card` | `ReportCardData` | Cabeçalho, número e execução. |
| `detail` | `ReportDetail` | Gráfico, tabela, regra, lacunas e histórico. |
| `onRerun` | `(id) => void` | “Rodar de novo”. Desabilitado em `queued`, `running`, `blocked` e no parado; o rodapé diz quem pediu e quando (`aria-describedby`). |
| `onRetry` | `() => void` | Com a execução em `failed`, o botão vira “Tentar de novo”. |
| `onCopyLink` | `(id) => void` | Opcional. O consumidor monta a URL e copia; o botão confirma “Link copiado”. |
| `icon`, `locale`, `timeZone`, `portalContainer`, `className` | | `timeZone` vale para os horários da execução e do histórico. |

## Detalhe (`ReportDetail`)

- `chart?: ReportChart` — `{ kind: "evolution", data: EvolutionChartData }` (EvolutionChart enxuto),
  `{ kind: "columns", data: ColumnDatum[], series }` (ColumnChart) ou `{ kind: "bars", data: BarDatum[] }` (Bars). Sempre com
  `label` e `format: ValueFormat`.
- `table?: ReportTable` — `{ columns: [{ key, label, format?, aggregate?, polarity?, signed? }], rows: Record<string, string |
  number | null>[], rowKey?, totalLabel? }`. A primeira coluna sem `format` nomeia a linha; as outras de texto viram a sublinha.
  Vira `ComparisonTable` com busca, ordenação, CSV e total conferido nas colunas `aggregate: "sum"`
  (`reportTableToComparison`).
- `method: { rule, grain?, period?: { from, to } }` — “Como calculamos” (`MethodologyList`).
- `gaps: { code, text }[]` — “O que falta”.
- `history: { at, state, note? }[]` — “Histórico”, do mais recente para o mais antigo.

## Execução (`ReportRun`)

| Estado | Rodapé | Botão |
| --- | --- | --- |
| `idle` | Sem execução pendente | Rodar de novo |
| `queued` | Na fila · 2º · pedido por Ana · 10/11 às 10:02 | desabilitado |
| `running` | Rodando desde 11:05 · pedido por … | desabilitado |
| `updated` | Atualizado em 10/11 às 02:12 | Rodar de novo |
| `blocked` | Bloqueado · motivo | desabilitado |
| `failed` | Falhou · motivo | Tentar de novo (`onRetry`) |

`reason` é obrigatório em `blocked` e `failed` (sem ele, o rodapé diz “Motivo não informado”).

## Layout

- Até 1100 px de largura; duas colunas acima de 760 px (Resultado | Como calculamos, O que falta, Histórico).
- Até 640 px, tela cheia com fundo opaco; o corpo rola e o rodapé fica fixo.
- O overlay é próprio (`rb-report-overlay`), sem a animação CSS do `rb-modal-overlay`.

## Acessibilidade e movimento

- Diálogo do react-aria com `aria-labelledby` no título, foco preso, Esc fecha e o foco volta à carta.
- O rodapé da execução é `role="status"`: a mudança de `run` é anunciada.
- Entrada com Motion: o verso gira de −70° a 0° (0,34 s) depois da virada da carta. Com movimento reduzido, só fade (0,16 s).
- axe sem violação com o verso aberto, no claro e no escuro.
