# ReportDeck · contrato (0.5.0-rc.9)

Baralho de cartas de relatório: contadores por situação, busca por número ou nome, área, ordem e a grade. É controlado: o
consumidor guarda filtros e ordem (por exemplo, na URL `?modulo=reports&area=…`) e devolve pelas props. Não faz rede nem
polling.

## Uso

```tsx
import { ReportDeck, ReportDialog, reportCardDomId, type ReportDeckState } from "@rbbt/ui";

const [deck, setDeck] = useState<ReportDeckState>({ sort: "serial" });
const [aberto, setAberto] = useState<string | null>(null);

<ReportDeck cards={cartas} {...deck} onChange={setDeck} onOpen={setAberto} favorites={favoritos} onFavoriteChange={gravarFavorito} />
{aberto ? (
  <ReportDialog isOpen onClose={() => setAberto(null)} returnFocusId={reportCardDomId(aberto)} card={…} detail={…} onRerun={pedir} />
) : null}
```

## Props

| Prop | Tipo | Padrão | Notas |
| --- | --- | --- | --- |
| `cards` | `ReportCardData[]` | — | Todas as cartas; o baralho filtra e ordena. |
| `area` | `string \| null` | `null` | Área escolhida (`null` = todas). |
| `status` | `ReportStatus \| null` | `null` | Situação escolhida pelos contadores. |
| `query` | `string` | `""` | Busca sem acento por id, série, título ou área (todas as palavras). |
| `sort` | `"serial" \| "dataAsOf" \| "status"` | `serial` | Série; data do dado (mais recente primeiro, sem data no fim); situação (parados primeiro). |
| `onChange` | `(estado) => void` | — | Recebe `{ area, status, query, sort }` completo a cada mudança. |
| `views` | `Record<id, WidgetStatus>` | — | Estado por carta (`loading`, `empty`, `error`, `restricted`, `partial`, `stale`). |
| `loading` / `skeletonCount` | `boolean` / `number` | `false` / 8 | Baralho inteiro em esqueleto. |
| `onOpen` / `onRetry` | callbacks | — | Repassados às cartas. |
| `favorites` / `onFavoriteChange` | `string[]` / `(id, favorito) => void` | — | Opcionais: com o callback, cada carta mostra a estrela. |
| `icon` | `(card) => ReactNode` | colunas | Arte por carta (ex.: pela área). |
| `cardIdPrefix` | `string` | `rb-report-card-` | Id do botão de cada carta (`reportCardDomId(id, prefixo)`). |
| `label` / `showTitle` | `string` / `boolean` | `Relatórios` / `false` | Nome da região; com `showTitle`, vira `h2`. |

## Comportamento

- Contadores no topo: Todos, Prontos, Preparados e Parados, com ícone, texto e número. São o filtro de situação
  (`ToggleButtonGroup`, um por vez). Contam o recorte de área e busca, sem zerar as outras situações.
- Resultado em texto (“3 de 10 relatórios”) numa região `role="status"`.
- Vazio por filtro: “Nenhum relatório com esses filtros” e o botão “Limpar filtros”, que devolve
  `{ area: null, status: null, query: "" }` (a ordem fica).
- Grade pela largura do contêiner (`auto-fill`, mínimo de 236 px): 5 colunas a ~1340 px, 4 a ~1180, 2 entre 600 e 860 px e 1
  até 520 px. No celular escolhemos uma coluna, não carrossel: a busca e o Tab continuam lineares.
- Cascata só na entrada (Motion, 35 ms por carta, teto de 0,42 s). Filtrar ou reordenar não reanima as cartas. Com movimento
  reduzido, só fade.
- Funções puras para o consumidor reaproveitar (na URL ou no servidor): `filterReportCards`, `sortReportCards`,
  `countReportCards`, `reportAreas`, `reportMatchesQuery` e `hasReportFilter`.

## Desempenho

45 cartas com minigráficos SVG (sem canvas, sem ECharts na frente). A medida fica em `tests/review/report-deck.spec.ts`
(`--grep "45 cartas"`), gravada em `artifacts/review/report-cards/fase2/desempenho-45.json`.

## Acessibilidade

- `section` com nome; lista `ul/li`; Tab percorre as cartas na ordem visível; Enter ou Espaço abre.
- Filtros com nome acessível (“Situação do dado”, “Buscar relatório por número ou nome”, “Área”, “Ordem”).
- axe sem violação no claro e no escuro, Glass e Smooth.
