# DateRangePicker — contrato

Versão do pacote: `@rbbt/ui@0.5.0-rc.10` · estado: **visual aprovado pelo Thiago em 12/11/2026**. Adição: nada muda para quem não usa o seletor; o `ContextBar` e o `PageContextProvider` continuam iguais para quem já os usa.

`DateRangePicker` é o seletor de período **De/Até** de uma página: dois campos de data digitáveis, um calendário e, opcionalmente, atalhos. Serve a qualquer página que filtre por um intervalo de dias (vendas, estoque, atendimentos). Como os filtros do `ContextBar`, é **controlado**: não busca dados, recebe o período e devolve `onChange`. O mesmo seletor entra no `ContextBar` como um filtro `kind: "date-range"`.

```tsx
import { ContextBar, DateRangePicker, formatDateRangeLabel, PageContextProvider, type DateRangeValue } from "@rbbt/ui";

const [periodo, setPeriodo] = useState<DateRangeValue | null>({ from: "2026-11-01", to: "2026-11-12" });

<DateRangePicker label="Período" value={periodo} onChange={setPeriodo} min="2025-01-01" timeZone="America/Sao_Paulo" />;

// No contexto da página: o mesmo seletor como filtro, e o período canônico em texto.
<PageContextProvider period={periodo ? formatDateRangeLabel(periodo) : undefined} anatomy="lean">
  <ContextBar
    title="Vendas da rede"
    filters={[
      { kind: "date-range", id: "periodo", label: "Período", value: periodo, onChange: setPeriodo, min: "2025-01-01", presets: ["thisMonth", "lastMonth", "year", "yearToDate"] },
      { id: "loja", label: "Loja", value: loja, options: lojas, onChange: setLoja },
    ]}
  />
</PageContextProvider>;
```

## DateRangePicker

| Prop | Padrão | Descrição |
| --- | --- | --- |
| `label` | — | Rótulo do campo, visível na pílula (ex.: "Período"). `hideLabel` o tira da tela e mantém no nome acessível. |
| `value` | — | `{ from, to }` em **dias ISO** (`AAAA-MM-DD`, sem hora) ou `null`. `null` é **ausência explícita**: a pílula diz "Sem período" e nada cai num período padrão. |
| `onChange` | — | Recebe só períodos **válidos e completos** (`from <= to`, dentro de `min`/`max`). |
| `min`, `max` | — | Primeiro e último dia que podem ser escolhidos (ISO, inclusivos). Limite inválido é ignorado; `min > max` descarta os dois. |
| `locale` | `pt-BR` | Campos `dd/mm/aaaa`, semana na segunda e meses com `Intl.DateTimeFormat`. `en-US`: `mm/dd/yyyy`, semana no domingo. |
| `timeZone`, `now` | o do navegador | "Hoje" e o mês inicial do calendário vêm do fuso informado; `now` fixa o relógio (testes, prévias). Não há seletor de fuso. |
| `description` | — | Ajuda do campo, como descrição acessível da pílula (como no `PillSelect`). |
| `status` | `ready` | `ready`, `loading`, `empty`, `disabled` ou `error` (abaixo). |
| `presets` | — | Atalhos opcionais (abaixo). Sem `presets`, o painel tem só os campos e o calendário. |
| `firstDayOfWeek` | `mon` em português | Primeiro dia da semana (`sun` … `sat`). |
| `sheetBelow` | `640` | Largura de tela abaixo da qual o painel vira folha em tela cheia com 1 mês. |
| `onRetry` | — | Com `status="error"`, mostra "Tentar de novo". |
| `messages` | `pt-BR` ou `en-US` pelo `locale` | Textos parciais, nos mesmos moldes dos outros componentes (`dateRangePickerMessages`). |

**Desenho.** Gatilho em pílula, como as `PillSelect` do `ContextBar`: rótulo, intervalo compacto ("01–15 out 2026", "28 set – 12 out 2026") e o ícone de calendário num círculo. No desktop, o painel tem os atalhos à esquerda, os campos De/Até no topo e 2 meses; abaixo de `sheetBelow`, folha opaca em tela cheia com os atalhos em fileira e 1 mês. Início e fim do período são círculos cheios na cor de destaque, os dias entre eles ficam numa faixa contínua, hoje tem um ponto, dia fora dos limites é riscado. Glass: painel em vidro denso (`--rb-glass-overlay`). Tema de cliente por tokens (`--rb-accent`, `--rb-on-accent`, `--rb-focus`, superfícies). Movimento só com Motion: entrada do painel ou da folha e troca de mês; com movimento reduzido, só esmaecimento.

### Validação

- Calendário e atalhos confirmam na hora. **Digitação é rascunho**: vale ao sair do campo (Tab, clique no calendário) ou com Enter. Assim o "2" de "20" nunca vira período.
- Data incompleta não dispara `onChange`.
- `from > to`, dia fora dos limites ou data inexistente aparecem com aviso acessível (ícone + texto, `role="alert"`, ligado aos campos por `aria-describedby`). O período anterior continua valendo; nada é corrigido para outro período.
- Esc ou clique fora fecham o painel e descartam o rascunho: os campos voltam ao período recebido.
- `value` recebido inválido: a pílula diz "Período inválido" com ícone e a linha abaixo explica o motivo.

### Estados

| `status` | O que aparece |
| --- | --- |
| `ready` | Pílula com o intervalo compacto ou "Sem período". |
| `loading` | Esqueleto no valor, com a geometria do estado pronto, `aria-busy` e aviso para leitor de tela. Não abre. |
| `empty` | "Sem datas disponíveis", pílula desabilitada. Use quando **não há datas para escolher**. |
| `disabled` | Mostra o período e não abre. |
| `error` | "Período indisponível" com ícone; com `onRetry`, botão "Tentar de novo". |

**Período sem dados não é estado do seletor.** Se o período escolhido não tem dados, a página mostra a ausência nos widgets (estado `empty` deles). O seletor não mostra cobertura nem assume ausência em nome da página.

### Atalhos (addon opcional)

Os atalhos nunca substituem os campos. Lista padrão (`DATE_RANGE_PRESET_IDS`), nesta ordem: "Este mês" (`thisMonth`, do dia 1 até hoje), "Mês passado" (`lastMonth`, o mês inteiro), "Ano" (`year`, 1/1 a 31/12 do ano corrente) e "Ano até hoje (YTD)" (`yearToDate`, de 1/1 até hoje). Atalho próprio: `{ id, label, range: (hoje) => ({ from, to }) }`. Atalho fora de `min`/`max` aparece desabilitado e riscado (nunca é recortado). O atalho igual ao período atual fica marcado com fundo, peso e um visto.

## ContextBar (filtro de período)

| Item de `filters[]` | Padrão | Descrição |
| --- | --- | --- |
| `kind: "date-range"` | — | Vira um `DateRangePicker` em pílula (anatomia `lean`) e no painel do modo recolhido (`collapseBelow`). Filtros sem `kind` (ou `kind: "select"`) continuam iguais. |
| `id`, `label`, `value`, `onChange` | — | Os mesmos termos dos outros filtros; `value` é `{ from, to } \| null`. Controlados: o estado (e a URL) é do consumidor. |
| `min`, `max`, `presets`, `status`, `messages` | — | Repassados ao seletor. `locale`, `timeZone` e `now` vêm da barra. |
| `description`, `isDisabled` | — | Como nos outros filtros. |
| `showInSummary` | `true` | No resumo recolhido, o período aparece compacto ("01–15 out 2026"), ou "Sem período". `false` o tira do resumo quando ele já está na linha de metadados (`period`). |

O `shortLabel` das opções continua valendo para os outros filtros; para o período, o resumo usa sempre o intervalo compacto.

## PageContextProvider

**Não muda.** `period` continua aceitando só a string canônica. Para gerá-la a partir do seletor, use `formatDateRangeLabel(value, { locale, timeZone })`: "Novembro 2026, 01–12", "Setembro–Outubro 2026, 28/09–12/10", "Dezembro 2025 – Janeiro 2026, 28/12–04/01"; em inglês, "November 2026, 1–12". Dias ISO não dependem de fuso; `timeZone` é aceito para chamadas simétricas ao seletor. Informe a mesma string ao `ContextBar.period`, se a página mostrar o período na linha de metadados.

## Funções puras

Exportadas para adaptadores e testes: `dateRangeIssue` (motivo: `incomplete`, `invalidDate`, `reversed`, `beforeMin`, `afterMax`), `isValidDateRange`, `parseIsoDay`, `todayIso(timeZone, now)`, `presetRange`, `resolvePresets`, `formatDateRangeCompact`, `formatDateRangeLong` e `formatDateRangeLabel`.

## Acessibilidade

- Teclado: Tab chega à pílula; Enter, Espaço ou Alt+↓ abrem o painel. Nos campos, cada segmento aceita números e setas. No calendário, setas mudam o dia, Page Up/Page Down mudam o mês (Shift: o ano), Enter marca início e fim. Esc fecha e devolve o foco à pílula.
- Painel com foco preso enquanto aberto (React Aria `Popover`/`Modal` + `Dialog`), título acessível e botões de mês nomeados.
- Nome da pílula = valor visível + rótulo; o período por extenso vai na descrição acessível.
- Alvos: segmentos com 24 px no mínimo; dias, atalhos e botões com 44 px na folha e em ponteiro grosso (a pílula estende a área de toque sem mudar o desenho).
- Situação nunca só por cor: início e fim em círculo cheio, hoje com ponto, dia fora dos limites riscado, erro com ícone e texto. Contraste de 4,5:1 no texto e 3:1 nas bordas, no claro e no escuro. A borda dos campos De/Até mede pelo menos 3,45:1 contra o fundo do campo e do painel, em Glass e Smooth, claro e escuro. O gatilho é uma pílula preenchida, sem borda, e se identifica pelo texto.

## Dependências

`react-aria-components` (`DateRangePicker`, `DateInput`, `DateSegment`, `RangeCalendar`, `Popover`, `Modal`, `Dialog`), `@internationalized/date` (a mesma versão que o React Aria usa), `motion`, `lucide-react`.
