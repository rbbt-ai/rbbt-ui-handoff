# Changelog — @rbbt/ui

## 0.5.0-rc.8 — 2026-10-30

Lote 5 do plano de widgets: **densidade e texto** (ordem do coordenador às 13:00 de 30/10, orquestração autorizada pelo Thiago). **Só aditivo** em relação à rc.7. Candidato local: sem publicação e sem tag antes do aceite.

- **Tabela com minigráficos** (Widgets › Tabela com minigráficos, [contrato](docs/sparkline-table.md)): `sparklineColumnCell` para `ComparisonColumn.cell`, no padrão do `bulletColumnCell`. Minigráfico SVG por linha com o último ponto e o valor, linha de referência opcional (média da rede), escala por linha ou comum declarada no cabeçalho (`sparkScaleNote`), tom pela polaridade e largura mínima de 88 px, que vale também nos cartões a 360 px. Semana sem leitura abre lacuna, nunca zero. A célula é um botão com o texto alternativo completo ("Preço médio em 12 semanas: de R$ 189 a R$ 214, +13%; 2 semanas sem leitura") e abre o `DetailPanel` com a série em tabela; balão do ponto por `placeTip`; raio-X da coluna continua valendo. Adaptadores `sparkSeriesFromRecords` (balde sem registro = `null`; `sum`, `mean` ou `last`) e `topProductsFromRecords` (N configurável, empate `label` ou `shared` declarado, posição anterior → ↑/↓/=/novo, linha "outros" conferida contra o total). A `ComparisonTable` ganha `animateReorder` (opcional): reordenar anima do lugar antigo ao novo com Motion, sem cascata. No catálogo, os usos **preço médio entre lojas** e **top produtos** com a Pedravela (fictícia).
- **Card de insight** (Widgets › Card de insight, [contrato](docs/insight-card.md)): `InsightCard` e `InsightList` com frase principal, até duas de apoio, números com os formatadores da biblioteca, força com o motivo, tom e polaridade em texto, e período, lojas e origem no rodapé. O texto sai de modelos determinísticos (`insightFromComparison`, `insightFromSeries`, mensagens pt-BR/en-US): ausência vira "sem leitura de X", dado parcial qualifica a frase ("com 7 de 8 lojas"), variação dentro do limiar vira "estável" e o apoio diz "coincide com", nunca causa. Link "Ver evidência: <rótulo>" por `href` (só http/https, `noopener noreferrer`) e/ou `onOpenEvidence`; o catálogo liga os três destinos: raio-X do Lote 4, `DetailPanel` e rolagem até o widget de origem. Ações fixar, dispensar e abrir por callback, desabilitadas com o motivo sem permissão. Texto de dados é sempre texto.
- **Animações só com Motion:** revelação da linha e cascata curta das partes do card só na entrada; na troca de filtro, linhas e números vão do antigo ao novo sem cascata e sem passar por zero (`CountUp`); movimento reduzido mostra o final direto. Nenhum `@keyframes`, `animation:`, `transition-delay` ou `requestAnimationFrame` nos arquivos do lote.

## 0.5.0-rc.7 — 2026-10-30

Lote 4 do plano de widgets: **decisão e efeito** (ordem do coordenador às 07:31 de 30/10, orquestração autorizada pelo Thiago). **Só aditivo** em relação à rc.6. Candidato local: sem publicação e sem tag antes do aceite. Valem as regras comuns do plano: adaptador por widget, estados, ausência ≠ zero, período/lojas/origem visíveis, temas, axe/teclado/tabela, 360 px com folga medida e balão sem colisão. **Ação e persistência só por callbacks**: nenhum dos quatro grava, usa `localStorage` ou chama rede; ação sem permissão aparece desabilitada com o motivo, nunca escondida.

- **`PriorityQueue`** (Widgets › Fila de prioridades, [contrato](docs/priority-queue.md)): fila v2 em que cada item traz **impacto estimado em R$** (sempre rotulado "estimado", com a conta), urgência (prazo ou janela), confiança (alta, média ou baixa, com motivo) e responsável. A regra de pontuação está no contrato e aceita pesos (padrão impacto 50% · urgência 30% · confiança 20%, normalizados e mostrados na tela). Cada item diz **por que está acima do seguinte** ("acima de Loja 03 · Centro: impacto 2× maior com a mesma urgência"), inclusive no empate. Ordens por pontuação, impacto, urgência e confiança; a troca anima do lugar antigo ao novo (cascata só na entrada, reduced motion respeitado). O item abre o `DetailPanel` com a evidência, a conta do impacto e a pontuação parte a parte. Item sem impacto calculável recebe o selo **"sem estimativa"**, fica sem pontuação e vai para o fim, nunca R$ 0. Ações (`onCreateDecision`, `onAssign`) só por callback; sem permissão, o botão aparece desabilitado com o motivo. Adaptador `priorityQueueFromRecords`.
- **`DecisionCard`** (Widgets › Cartão de decisão, [contrato](docs/decision-card.md)): **problema**, **evidência** (números com link para a origem), **proposta**, **responsável** e **prazo**, no estado rascunho, proposto, decidido ou descartado, com o motivo do estado visível. **Nasce de um alerta ou de um item da fila** (`decisionFromAlert`, `decisionFromQueueItem`) mantendo o contexto original num **snapshot imutável** (`captureContextSnapshot`: cópia profunda congelada com data e hora obrigatórias, período, filtros, lojas, valores no momento e fonte); "Ver contexto original" abre o `DetailPanel` com a tabela no alerta × agora. **Valores que mudaram** aparecem lado a lado ("no alerta R$ 12.400 · agora R$ 15.800", "+R$ 3.400 (+27,4%)"), e sem leitura agora é ausência, nunca zero. O impacto que vem da fila entra sempre em moeda e rotulado como estimado. Ações propor, decidir, descartar e atribuir só por callback; sem permissão, desabilitadas com cadeado e o motivo. Responsável e prazo validados (`validateAssignment`: obrigatórios, data válida e não antes de hoje), com `aria-invalid`, mensagem ligada por `aria-describedby`, anúncio do número de erros e foco no primeiro campo com erro.
- **`EffectScoreboard`** (Widgets › Placar de efeito, [contrato](docs/effect-scoreboard.md)): **antes → meta → depois** de uma ação, com a janela de avaliação explícita (datas e duração). Médias só com os dias que têm leitura; dia sem leitura fica fora da média, aparece como lacuna na curva e é contado como ausência, nunca zero; hoje não conta; mínimo de leituras por janela (`minDays`, padrão 7). Estados próprios **em avaliação** (janela aberta, "parcial, não final"), **dados insuficientes** (diz qual lado faltou) e **concluído**, além dos estados gerais. A ressalva **"Melhora depois da ação não prova que a ação causou a melhora."** fica visível em todos os estados. Com grupo de comparação, mostra a diferença contra ele ("+1,7 p.p. acima do grupo de comparação"). Resultado em valor e em % (em pontos percentuais quando o valor é %); polaridade declarada como nas barras divergentes, com tom sempre escrito. Minigráfico SVG com a faixa da janela, a linha da ação, a meta, as médias e o grupo tracejado; "Ver tabela" (um dia por linha) e "Ver a conta" (`DetailPanel` com as fórmulas, foco preso e Esc). Ações só por callback ou link, sem permissão desabilitadas com o motivo. Funções puras `effectFromSeries` e `buildEffect`.
- **Raio-X do indicador** (Widgets › Raio-X do indicador, [contrato](docs/kpi-xray.md)): painel com **fórmula**, **fonte** (origem, atualização e cadência), **filtros aplicados**, **exclusões** (lojas e itens, com o porquê e o efeito com sinal no total) e **conferência do total** (`reconcileTotal`: bate, diferença explicada, diferença sem explicação com o resíduo, "não fecha: falta dado" e sem dados). Sem leitura (`null`) e valor inválido (`NaN`) nunca viram zero; a soma mostrada fica "das N de M com leitura". Abre de **qualquer número** por um mecanismo genérico: `XrayProvider` (um painel por árvore, montado na raiz do tema, foco preso, Esc devolve o foco ao número), `XrayTrigger` (sublinhado pontilhado, nome "Raio-X de <indicador>: <valor>") e `useXray()` para abrir pelo código. Ligado de forma **aditiva** em três widgets existentes: `TrendIndicator` (`xray`), célula da `ComparisonTable` (`columns[].xray`) e `BulletBar` (`xray`); sem provedor ou sem a prop, os três ficam idênticos aos de antes. Período, lojas e origem no cabeçalho do painel em todos os estados. Adaptador `xrayFromRecords` (vazio = sem leitura, linha com motivo = exclusão).
- **Animações do lote só com Motion** (correção pedida na validação de 30/10 12:15): a cascata do `DecisionCard` (antes `transition` CSS com `--rb-dc-i`) e a das seções do raio-X (antes `@keyframes rb-xray-in`) viram `motion.*`, só na entrada/abertura; a interpolação da curva do `EffectScoreboard` (antes `requestAnimationFrame` manual) usa `animate` do Motion, do valor na tela ao novo, com ausência trocando na hora e parada no unmount. Nenhum `@keyframes`, `animation:`, `transition-delay` ou `requestAnimationFrame` de entrada nos quatro widgets.
- **Teste de axe com o detalhe aberto**: as anotações do `EvolutionChart` (lacuna 9 do Lote 3) passam no axe com o balão aberto (largo) e com o detalhe embutido sob a legenda (360 px), no claro e no escuro; todos os painéis e cartões abertos do Lote 4 também.

## 0.5.0-rc.6 — 2026-10-30

Lote 3 do plano de widgets: **tempo e contexto** (ordem do coordenador às 06:47 de 30/10, orquestração autorizada pelo Thiago). **Só aditivo** em relação à rc.5. Candidato local: sem publicação e sem tag antes do aceite. Valem as regras comuns do plano: adaptador por widget, estados, ausência ≠ zero, período/lojas/origem visíveis, temas, axe/teclado/tabela, 360 px com folga medida e balão sem colisão (`widgets/place-tip.ts`).

- **Eventos no tempo** (`TimeEvent`, `eventsFromRecords`, `toIsoDay`, `eventsOnDay`, `eventsInRange`, `clipEvent`, `eventWindow`): um formato só para o calendário e para as anotações do gráfico. Um evento dura um dia (`start`) ou um intervalo fechado (`start`–`end`); o tipo vem por configuração (`TimeEventTypes`: rótulo, tom e marca); prioridade alta e grupo de eventos sobrepostos. Datas em ISO, `dd/mm/aaaa` ou série do Excel; linha sem id, sem data ou com fim antes do início vai para `skipped`, com o motivo.
- **`SmallMultiples`** (Widgets › Pequenos múltiplos, [contrato](docs/small-multiples.md)): uma minicurva por loja (ou item configurável) em grade, com nome, último valor e variação em texto. **Escala comum** em todos os painéis por padrão; a escala própria (`scale="own"`) fica declarada na tela. Lojas em queda por regra configurável (padrão: variação do período contra o anterior abaixo de −5%), com selo e texto "em queda", nunca só cor; `sort="decline-first"` põe as quedas primeiro. Dia sem dado quebra a curva. Teclado entre painéis (Tab, ←/→ no ponto, Home/End, Esc), com balão do ponto perto do painel ativo; no estreito, o selo desce para linha própria e o nome continua legível (nome longo sai com reticências e completo no balão, na tabela e no leitor de tela). Tabela com loja, último valor, variação e tendência. Adaptador `smallMultiplesFromRecords`.
- **`CalendarHeatmap`** (Widgets › Calendário de calor, [contrato](docs/calendar-heatmap.md)): dias em semanas × dias da semana (domingo primeiro, como o mapa de calor; `weekStart={1}` começa na segunda), visão de um mês e de vários meses, escala quente pelas faixas e hachura do mapa de calor; ausência com contorno tracejado e "s/ dado", nunca zero; dia fora do período, liso. Na célula, o valor curto aparece inteiro ou não aparece (se algum não couber, nenhum aparece; o valor completo fica no balão e na tabela). Dias com evento ganham marca (anel ou ponto, por tipo) e o nome no balão; o intervalo tem anel no primeiro dia e barra fina nos seguintes. A lista de eventos fica ao lado (embaixo, no estreito) e, acima de 7 eventos, mostra 6 e "Ver todos (n)". O contrato documenta o mapeamento das colunas de uma planilha de eventos de referência para `TimeEvent`. Adaptador `calendarFromRecords`.
- **Anotações no `EvolutionChart`** (Widgets › Evolução com eventos, [contrato](docs/evolution-chart.md)): props opcionais `annotations` (`EvolutionAnnotation` = `TimeEvent`; dia único = linha tracejada, intervalo = faixa clara) e `annotationTypes`. Os rótulos ficam numa faixa própria acima da área de dados e nunca cobrem linha, pontos nem rótulos de valor; quando encostam, deslizam ou usam uma segunda linha e, sem espaço (ou abaixo de 420 px), viram marcadores numerados com legenda. No largo, o balão usa `place-tip` medido contra a geometria do gráfico (pontos, barras e rótulos convertidos do ECharts); no estreito, o detalhe abre embutido sob a legenda, sem cobrir nada. Linhas e faixas entram e mudam junto com o gráfico; a tabela ganha a coluna "Eventos". A API anterior não muda.
- **`place-tip`** (interno): obstáculos já medidos (`hardRects`), para a geometria que o DOM não vê. Aditivo.

## 0.5.0-rc.5 — 2026-10-30

Lote 2 do plano de widgets: **resultado e desvio** (ordem do coordenador às 02:02 de 30/10, orquestração autorizada pelo Thiago). **Só aditivo** em relação à rc.4. Candidato local: sem publicação e sem tag antes do aceite. Os quatro widgets seguem as regras comuns do plano e as notas do coordenador sobre o Lote 1: nenhuma barra sem rótulo de valor quando há o espaço mínimo documentado (abaixo dele, o rótulo sai com guia ou vai para a chave) e folga de colisão a 360 px medida no DOM.

- **`ResultWaterfall`** (Widgets › Cascata do resultado, [contrato](docs/result-waterfall.md)): cascata do resultado da base ao atual, com os degraus volume, preço, mix e resíduo/outros e rótulos configuráveis. O método está no contrato: volume a preço médio da base, preço sobre a quantidade atual e mix pela mudança de participação, em centavos inteiros. A conciliação fecha ao centavo (`reconcileResultWaterfall`): base + degraus = atual. O resíduo é explícito, com item novo, descontinuado, arredondamento e não explicado. Cada degrau tem sinal, seta e valor em texto, além da cor, e as linhas-guia ligam os degraus. Quando o eixo é cortado, há aviso em texto. A tabela mostra cada efeito em R$ e em % da base. Entrada por itens (`decomposeResultItems`) ou por efeitos prontos. Adaptador `resultWaterfallFromRecords`. Em contêiner estreito, abaixo de `RESULT_WATERFALL_MIN_COLUMN` (88 px por coluna), vira linhas.
- **`BulletBar`, `BulletList` e `bulletColumnCell`** (Widgets › Meta × realizado, [contrato](docs/bullet-bar.md)): trilho de 12 a 20 px com faixas qualitativas e cortes configuráveis (padrão < 90%, 90–100% e ≥ 100%), barra do realizado, marca da meta, marca opcional da projeção e o texto "98,0% · −R$ 6,9 mil". **Sem meta é um estado próprio**, sem faixa e sem "0%". Realizado zero com meta é 0,0%. Lista por loja com ordenação. `bulletColumnCell` é o renderizador de coluna da `ComparisonTable`: o desenho é decorativo e o número continua para ordenar e para o leitor de tela. Espaço mínimo do rótulo: abaixo de `BULLET_MIN_TRACK_PX` (64 px) + texto, o texto desce para baixo da barra e nunca some. Adaptador `bulletFromRecords`.
- **`ParetoChart`** (Widgets › Pareto 80-20, [contrato](docs/pareto.md)): barras da maior para a menor, linha do % acumulado e marca configurável dos 80% (`PARETO_THRESHOLD`). Os poucos vitais ficam destacados, com a frase "7 de 14 marcas fazem 80% da receita". Alterna entre marca e produto. As primeiras `PARETO_TOP_N` (12) barras aparecem e o resto vai para "Demais (k)", que pode ser expandido. A conciliação continua valendo (`paretoReconciles`). Item sem dado fica fora do ranking e aparece declarado, nunca como zero. A tabela traz posição, valor, % e % acumulado. Abaixo de `PARETO_MIN_SLOT_PX` (56 px por barra), vira linhas. Adaptador `paretoFromRecords`.
- **`DivergingBars`** (Widgets › Barras divergentes, [contrato](docs/diverging-bars.md)): barras acima e abaixo de uma referência configurável (zero, meta ou previsão), com rótulo sempre visível. Funciona na horizontal e na vertical; colunas com menos de 64 px viram linhas. A **polaridade é declarada**: maior é melhor, menor é melhor ou mais perto é melhor (`closer-is-better`, com tolerância). Toda barra traz o desvio com sinal: o rótulo vai dentro quando cabe com 6 px por lado e, senão, na ponta. Há uma história de acuracidade da previsão com tolerância de ±5%. Ausência fica fora das barras e da contagem, como "sem dado". Adaptador `divergingFromRecords`.
- **Balão sem colisão** nos quatro widgets. A posição é o lugar livre mais perto do item ativo, medido no DOM. O balão nunca cobre texto do quadro nem o próprio item e evita as outras barras quando dá. Sem lugar para o balão completo, entra o compacto. A cascata tem a busca própria; bullet, Pareto e divergentes usam o ajudante interno `widgets/place-tip.ts`. Há e2e de geometria no desktop por widget, além dos de 360 px.

## 0.5.0-rc.4 — 2026-10-30

Lote 1 do plano de widgets: **estoque e capital** (ordem do coordenador às 00:01 de 30/10, orquestração autorizada pelo Thiago). **Só aditivo** em relação à rc.3. Candidato local: sem publicação e sem tag antes do aceite. Os três widgets seguem as regras comuns do plano: adaptador de Bases e de cenário pronto, estados da moldura comum, ausência diferente de zero, período, lojas e origem visíveis, Smooth e Glass no claro e no escuro com tema de cliente, axe, teclado e tabela, 360 px sem rolagem da página, Motion com cascata só na entrada e troca de dado do valor antigo ao novo.

- **`StockCapital`** (Widgets › Capital em estoque, [contrato](docs/stock-capital.md)): barras por idade (0–30, 31–90 e +90 dias, com valor e % do capital; o +90 com hachura e etiqueta de risco) e treemap quadrado por marca e por loja (área = capital; cor = fatia acima de 90 dias em faixas por tokens `--rb-cap-risk-1…4`, a mais alta com hachura). Hierarquia marca → loja ou loja → marca; clique ou Enter abre o detalhe com caminho de volta (Voltar, primeiro nível clicável, Esc) e o foco volta ao bloco de origem. Base de valor (custo ou preço) e posição datada na tela. Somas em centavos inteiros: barras = blocos = total, e cada nível fecha com os filhos (`reconcileStockCapital`, testado nas duas hierarquias); o rodapé mostra o fechamento. Posição sem leitura fica fora da soma e aparece listada; zero é zero. Adaptador `stockCapitalFromRecords` (formato longo ou largo; Bases ou `reader.rows`), lógica pura `buildStockCapital`, `riskBands`, `riskIndex`, `squarify`, `toCents`. DOM em vez de ECharts (foco e nome por bloco, hachura e tokens).
- **`CoverageQuadrant`** (Widgets › Quadrante velocidade × cobertura, [contrato](docs/coverage-quadrant.md)): dispersão em 4 quadrantes com velocidade de venda no x (unidades por semana ou sell-through %, por `metrics`/`metric`) e cobertura em semanas no y. Limites configuráveis (`thresholds`; cobertura 8 semanas por padrão) desenhados como linhas com rótulo. Ação por quadrante, em texto no balão e na tabela: **repor** (vende rápido, pouca cobertura), **remarcar** (vende devagar, muita cobertura), **remanejar** (uma loja com 12 semanas ou mais e outra com 3 ou menos, `rule.imbalance`), manter e acompanhar; a regra é trocável em `rule.actions`. Ruptura = % de dias sem disponibilidade no período, no anel do ponto e em texto. Itens por referência ou por loja (`itemKind`), teclado entre pontos, tabela com quadrante e ação. Item sem leitura de velocidade ou de cobertura vai para a lista "sem leitura", nunca para o zero do eixo; leitura acima de 4× o limite fica na borda com o valor real no balão. Adaptador `quadrantFromRecords` (Bases ou cenário), lógica pura `buildQuadrant`, `quadrantOf`, `quadrantAction`, `storeImbalance`, `sellThrough`, `ruptureFromDays`, `ruptureShare`. Rótulo de região nunca cobre ponto: no largo, vai para um canto livre; em contêiner estreito (abaixo de 420 px), o gráfico fica quase quadrado (mínimo de 280 px) e os rótulos descem para uma chave 2×2 no desenho dos quadrantes. SVG próprio em vez de ECharts (foco e nome por ponto, anel de ruptura e tokens).
- **`MixBalance`** (Widgets › Mix vendido × disponível, [contrato](docs/mix-balance.md)): barras espelhadas, com o mix vendido à esquerda e o disponível à direita, uma linha por categoria, linha ou marca. Mix vendido = unidades vendidas do item ÷ vendidas do total × 100; mix disponível = disponíveis do item ÷ total disponível × 100. Os dois lados usam o **mesmo universo**: só entram itens com as duas leituras, os denominadores ficam visíveis ("Vendido: 12.220 un.", "Disponível: 12.500 un.") e cada lado soma 100% exatos pelo maior resto. Posição do estoque datada e sempre visível, ou o aviso "sem data". Reservado e bloqueado ficam à parte quando o dado existe. Desequilíbrio em texto e em p.p.: vendido acima do disponível é risco de ruptura, o contrário é excesso, e abaixo de 2 p.p. está equilibrado (`tolerance`). Ordenação por desequilíbrio (padrão), por mix vendido ou por nome. Item sem leitura fica fora das barras e listado, nunca vira zero. Um lado sem base mostra o estado vazio com o motivo. Em 360 px, cada linha empilha o rótulo e a situação sobre as duas barras. Adaptador `mixBalanceFromRecords` (Bases ou `reader.rows`; linhas repetidas somam, e uma leitura faltando deixa o item sem leitura) e lógica pura `buildMixBalance`, `sortMixBalance`, `classifyMixBalance`, `mixBalanceShareUnits`, `mixBalanceScaleMax`, `mixBalanceStockPosition`. Barras em DOM em vez de ECharts: foco e nome por linha, tabela e tokens.

## 0.5.0-rc.3 — 2026-10-29

Lote 0 do plano de widgets: **mapa de calor de concentração** (pedido do Thiago, 29/10 23:16, com o adendo do hover das 23:20). **Só aditivo** em relação à rc.2. Candidato local: sem publicação e sem tag antes do aceite.

- **`Heatmap`** (Widgets › Mapa de calor): quanto mais concentração, mais quente a célula. Eixos configuráveis (dia × hora por padrão; loja × dia; semana × dia), seletor de métrica controlado (`metric`/`onMetricChange`), período, lojas e origem visíveis, balão com valor exato e % do total, teclado em grade (setas, Home/End), alternativa em tabela, estados da moldura comum e 360 px sem rolagem da página. Grade própria em DOM (o canvas do ECharts complicaria foco, hachura e tabela por célula).
- **Faixas por tokens** `--rb-heat-1…5` (cliente troca por `heat1…heat5`), hachura nas duas mais frias, brilho na mais quente, ausência tracejada e fora do total (nunca zero). Corte padrão por quantis com a faixa quente nos 10% maiores; limites fixos por configuração.
- **Hover/foco/tap em "mira"** com Motion: célula sobe 1,06 com halo da faixa (sombra curta no Smooth, brilho no Glass), as outras recuam (escuro: 25% mais escuras; claro: opacidade 0,5), rótulos do dia e da hora em destaque e balão junto. 150 ms de entrada ease-out e 110 ms de saída pelos tokens `--rb-heat-hover-*`; movimento reduzido = contorno e rótulos, sem escala nem animação; tap fora fecha.
- **Entrada** em cascata só na entrada; troca de métrica vai da faixa antiga à nova, sem cascata e sem zerar.
- **Adaptadores** `heatmapFromRecords` (Bases e cenário pronto, campos por caminho, regra de `toMetricValue`), `heatmapFromMatrix` (JSON agregado), eixos `weekdayCategories` e `hourCategories`, e a lógica pura `buildHeatmap`, `heatThresholds`, `heatBands`, `bandIndex`, `shareOfTotal`.

## 0.5.0-rc.2 — 2026-10-29

Correções da reconstrução com a rc.1 (`LACUNAS.md` da Prévia 3) e dos achados D1–D3 da comparação com o original. Thiago aprovou a Prévia 3 como prova técnica e liberou a rc.2 às 20:44 de 29/10 (via coordenador). **Mudanças só aditivas em relação à rc.1**; o único efeito visível sem mudar código é a notação compacta, que deixa de arredondar demais (D1). Candidato: espera o aceite antes de publicar.

**Pacote**

- **`DetailPanel` com desfoque no Glass.** O painel de detalhe e a folha de filtros recebem o mesmo `backdrop-filter` das superfícies (`blur(var(--rb-glass-blur)) saturate(1.15)`), sobre um vidro mais denso (token `--rb-glass-overlay`). O conteúdo de trás não aparece mais nítido sob o título. Sem suporte a desfoque no navegador, a superfície fica opaca.
- **Passo do simulador no idioma da página.** Os botões "−" e "+" do `TransferSimulator` passam a se chamar "Diminuir a quantidade" e "Aumentar a quantidade" no `locale` do widget, nunca no idioma do navegador (`I18nProvider` + `messages.decrease`/`increase`). Os números do campo também seguem o `locale`.
- **Valor secundário no card `lean`.** Com linha de comparação, o `secondaryValue` ganha a segunda linha de apoio do card (como no card completo), em vez de ir para "Como calculamos". O juízo pinta só o número.
- **Mínimo e máximo no simulador.** Props `minQuantity` (padrão 0) e `maxQuantity`. O teto efetivo é o menor entre o estoque da origem e o máximo configurado. Nos limites, "−" e "+" ficam desabilitados e o motivo aparece em texto; com a origem zerada, a faixa é 0–0. Adaptadores puros `transferLimits` e `clampTransferQuantity`; textos `quantityRange`, `quantityAtMax`, `quantityAtMin`, `originEmpty`; `messages.pieces(valor, quantidade)` com singular.
- **D1 · valores compactos distinguíveis.** Na notação compacta automática, as casas de `format` (pensadas para a notação padrão) não valem mais: o padrão é até 2 casas, então R$ 3,15 mi e R$ 3,32 mi, nunca "R$ 3 mi" duas vezes. Com `notation: "compact"` explícito, as casas do formato continuam valendo. Novo `distinctCompactFormat(valores, formato, locale)`: valores comparados no mesmo bloco sobem de casas até se distinguirem (no máximo 2) e, na mesma escala, saem com as mesmas casas. Aplicado em `TrendIndicator` (valor × comparável), `EvolutionChart` (resumo), `ComparisonTable` (por coluna, com subtotais e total), `ColumnChart` e `Bars`. Campos novos de `ValueFormat`: `compactMinimumFractionDigits` e `compactMaximumFractionDigits`. Contrato em [trend-indicator.md](docs/trend-indicator.md).
- **D2 · menu do celular.** No menu compacto do `WorkspaceShell`, o módulo ativo rola até a vista ao abrir a página e a cada troca, só dentro do contêiner do menu (a página não rola). Com movimento reduzido, a rolagem é instantânea. Quando fontes ou largura mudam o menu, ele reconfere sem animação.
- **D3 · "Ordenar" sem corte.** A pílula de ordenação da `ComparisonTable` (`lean`) cresce até caber o critério inteiro; quando não cabe, desce de linha e, só num contêiner mais estreito que o texto, quebra em duas linhas.
- **Simulador sob demanda.** `TransferSimulatorDialog`: o mesmo simulador num painel lateral (folha inferior no celular), aberto pelo "Simular transferência" da grade, com o foco dentro; Esc fecha e devolve o foco ao botão. Continua "Simulação" e não movimenta nada. O `TransferSimulator` sempre aberto continua valendo.

**Receita e textos do cliente**

- **Cenários prontos em JSON** (`adapters/scenario.ts`): `createScenarioReader` (cenário por recorte × período, textos, métricas por caminho, listas, formatos, ícones e `indicator` no contrato do `TrendIndicator`), `pickScenario`, `fillTemplate` (marcadores em texto puro, números por Intl, marcador sem valor fica visível), `templateMarkers`, `formatByName` (confere a forma), `iconByName` (registro do consumidor) e `readPath`. `indicatorDataFromRecord` aceita caminhos ("indicadores.receita").
- **Lugar para os textos do cliente:** `advanceLabels` no `ActionBoard` (texto visível do avanço por etapa; o nome acessível começa por ele), `legend` e `note` no `StockGrid`, `note` no simulador, `label` nos cards e `methodologyTitle` no `QualityOverview`. Sem eles, ficam os textos do pacote.
- **Tipagem:** os adaptadores de linhas aceitam linhas tipadas por `interface` (`ReadonlyArray<object>`), e `plate` do logo aceita `boolean` (um JSON importado tipa `false` assim).
- **Receita:** passo novo "Dados prontos em JSON" com um `cenario.json` e um leitor compilados no exemplo; Estoque com o simulador sob demanda e limites; Plano e Qualidade com textos do cliente; regra dos valores compactos; checklist com D1–D3; "o que fica no consumidor" com os pontos da reconstrução. A fumaça da receita confere também o ativo do menu no celular e o simulador aberto (foco, axe e Esc).
- **Catálogo:** Estoque ganha "Simulador sob demanda", "no máximo", "no mínimo" e "com origem zerada"; Plano, "Textos do cliente nos botões"; Qualidade, "Títulos do cliente"; TrendIndicator, "Valor secundário e valores próximos".

### Migração a partir da rc.1

Nada é obrigatório. Para seguir o original: troque o `TransferSimulator` sempre aberto pelo `TransferSimulatorDialog` ligado ao `onSimulate` da grade. Se a página fixou casas na notação compacta e quer "R$ 3 mi", declare `notation: "compact"` no formato.

## 0.5.0-rc.1 — 2026-10-29

**Workspace Glass**: o catálogo passa a ser a fonte única para montar um workspace sem copiar código de outro projeto. Candidato: Thiago aprovou a Prévia 1 às 14:10 e a Prévia 2 às 17:29 de 29/10 (via coordenador). O aceite final é a Prévia 3, em que um agente novo reconstrói um workspace só com o tarball, o catálogo e a receita. **Mudanças só aditivas em relação à 0.4.**

- **Família Glass ao lado do Smooth**: `RbTheme family="glass"`, com vidro acetinado, fundo em gradiente sem foto, borda luminosa, numerais contidos, claro e escuro. A família é herdada por `RbTheme` aninhado. **O Smooth continua o padrão.** Tokens novos, todos opcionais: `canvasImage`, `glassBlur`, `glassLine`, `glassShadow`, `signal`, `navSelected` e `onNavSelected`. Tipo `RbThemeFamily`.
- **Tema de cliente**: `defineClientTheme` + `RbTheme client`, com nome, produto, sigla, logo (com `darkSrc` ou `plate` por modo) e tokens comuns e por modo. Vêm também `clientThemeTokens` e os tipos `RbClientTheme` e `RbClientLogo`. `useRbTheme()` devolve modo, família e cliente. O pacote não traz marca de nenhum cliente.
- **Modelo de workspace**:
  - `WorkspaceShell`: topo com marca, menu de módulos controlado (`module` e `onModuleChange`), ações, troca de tema, perfil, "Ir para o conteúdo" e rodapé. No contêiner estreito, o menu vira uma fileira rolável;
  - `FilterBar`: recorte, período, datas e cobertura (`null` nunca vira "0/N");
  - `WorkspaceHeader`, `WorkspaceSection` e `WorkspaceFooter`, com os textos em `workspaceMessages`.
  - Consultas de contêiner `rb-ws` em 1180, 860 e 640 px, e rótulos com 12 px ou mais.
- **Componentes de operação** (contratos em [estoque](docs/estoque.md), [plano de ação](docs/plano-de-acao.md) e [qualidade](docs/qualidade.md)):
  - `StockGrid`: grade de tamanhos × unidades. O zero não depende só de cor, e sem leitura não é zero. Mostra a cobertura em semanas e a posição datada. Abaixo de 560 px de contêiner, vira lista por unidade;
  - `TransferSimulator`: mostra o efeito previsto nas duas pontas e não movimenta nada;
  - `ActionBoard`: etapas sugerido → aprovado → executado → resultado avaliado, com evidência obrigatória, persistência por callback (`onCreate`, `onMove`, `onEvidence`) e Alt + setas no teclado;
  - `QualityOverview`: cards de confiança, mapa de cobertura com busca e ordenação, e "Origem e fórmula".
  - Os textos ficam em `operationsMessages`.
- **Adaptadores novos**, no mesmo contrato de `adapters/series.ts` (linhas planas, sem rede, `null` nunca vira zero): `coverageFromRecords`, `stockFromRecords`, `coverageWeeks`, `ruptureSizes`, `simulateTransfer`, `actionsFromRecords`, `canMoveAction`, `requiresEvidence`, `ACTION_STAGES` e `coverageMapFromRecords`.
- **Entrada animada com Motion**, sem Anime.js: `RbEntrance`, `useEntrance`, `useReplayEntrance`, `CountUp`, `useCountUp`, `readMotionTokens` e `entranceDelay`.
  - Dentro do `WorkspaceShell`, a entrada vem ligada por padrão (`motion={false}` desliga). Números contam, linhas se desenham, barras crescem em cascata e arcos percorrem, em sequência de ~1,2 s.
  - Na troca de filtro, o valor vai do antigo ao novo, sem cascata e sem buraco. Num eixo novo, tudo entra direto no lugar final.
  - Tokens novos: `durationEnter`, `durationStagger`, `durationPage` e `easeEnter`. Com movimento reduzido, eles zeram.
  - `EvolutionChart`, `SegmentedGauge`, `ColumnChart`, `Sparkline` (prop opcional `entrance`) e `TrendIndicator` entram na sequência só dentro de `RbEntrance`.
- **`EvolutionChart`**: uma mudança de dado não redesenha mais do zero. Antes, o `notMerge` a cada filtro refazia a animação de entrada. No mesmo eixo, o valor vai do antigo ao novo; num eixo novo, entra no lugar final. Isso vale também fora do workspace. O atributo `data-motion` (`running`/`idle`) marca o fim da animação, para testes e capturas.
- `StatusChip` ganha `variant="pill"`.
- **Receita · montar um workspace**, no catálogo e em [docs/receita-workspace.md](docs/receita-workspace.md):
  - workspace = modelo + tema + componentes + configuração;
  - o mapa módulo → componentes → adaptadores, com URL, movimento e validação;
  - um exemplo completo de seis módulos com cliente fictício, a Pedravela Calçados. O nome foi inventado e conferido, e substitui o fictício anterior, que lembrava uma marca real.
  - O pack-and-verify extrai o exemplo da receita, compila contra o tarball e abre os seis módulos no Chromium: desktop e celular, claro e escuro, axe, URL e console.
- **Catálogo**:
  - seção Workspace com Receita, Modelo e Movimento ("Tocar de novo");
  - páginas Widgets › Estoque, Plano de ação e Qualidade, com Contrato;
  - controle "Família" na barra.

### Migração a partir da 0.4

Nada é obrigatório: a 0.5.0-rc.1 só adiciona.

- Sem `family`, o `RbTheme` continua Smooth.
- Sem `client`, não há tema de cliente.
- Fora de `WorkspaceShell`/`RbEntrance`, os widgets não fazem a entrada em sequência. O `SegmentedGauge` continua acendendo ao montar, como na 0.4.
- A única mudança de comportamento fora do workspace é a do `EvolutionChart` (acima). Testes que esperavam a animação de entrada a cada troca de filtro devem esperar por `data-motion="idle"`.

Para adotar:

1. Instale o tarball novo com versão exata: `npm install --save-exact ./rbbt-ui-0.5.0-rc.1.tgz`. Os imports de `@rbbt/ui/styles.css` e `@rbbt/ui/fonts.css` não mudam.
2. Para um workspace, siga a Receita: `RbTheme family="glass" client={…} canvas`, depois `WorkspaceShell` e os módulos.
3. Páginas que já usam os widgets da 0.4 não precisam mudar.

## 0.4.0-rc.2 — 2026-10-28

Adiciona `MixExplorer`, um widget genérico na linguagem smooth. Candidato para revisão visual de Thiago; o aceite do widget não foi inferido.

- Árvore configurável, padrão Linha → Marca → Referência; caminho clicável, Voltar/Esc e detalhe da referência em `DetailPanel`.
- Participação atual e na base, mudança em p.p., variação do item e contribuição para a variação do pai. Maior resto em décimos concilia participações em 100,0% e contribuições no Δ% exibido; filhos são conferidos contra o pai na unidade do dado (centavos).
- `null` é sem leitura. Em dados parciais, variação e contribuição usam o universo comparável, identificado na tela. Novo, saiu do mix e base zero têm estados próprios.
- Caminho, filtros e ordenação controláveis; mudança dos dados recua ao ancestral existente e anuncia o motivo. Cauda agregada “Demais (k)” expansível.
- Cabeçalhos com foco, anúncio do nível, texto e sinais além de cor, cards em 360 px e reduced motion. `Panel` recebe props opcionais `toolbar` e `live` para filtros persistentes e controle do anúncio.
- Página Widgets › Explorador de mix: Padrão com estado na URL, Escuro, Estados, Casos extremos, Estreito e Contrato. Dados fictícios identificados. O Início mantém a composição existente.
- Build do catálogo versiona scripts sem hash e a busca do `index.json` por `?v=<versão>-<hash>`; o preview tem nome com hash. Depende da revalidação do HTML de entrada pelo host. Teste com cache quente e controle sem proteção.
- Consumidor externo importa componente e tipos `MixNode`/`MixExplorerProps`, verifica CSS e compila em Bundler/NodeNext. Contrato e fórmulas em [docs/mix-explorer.md](docs/mix-explorer.md).

Sem mudança incompatível de API em relação à rc.1.

## 0.4.0-rc.1 — 2026-10-27

Linguagem **smooth** no catálogo inteiro, com o azul Rbbt como destaque, a pedido de Thiago ("mais clean, moderno, graficamente mais bonito e smooth"). Aceites de Thiago: Etapa 1 em 26/10; lado smooth do antes × depois ("Aprovado o 0.4") às 19:12 de 27/10; home em galeria ("ok. pode publicar") às 19:20; demos como painel de resultado e fechamento da entrega ("ok. pode seguir") às 21:19. Tag local `ui-v0.4.0-rc.1`, publicada em 27/10. Contratos em [docs/smooth.md](docs/smooth.md).

Etapa 1 (26/10):

- **Destaque azul Rbbt** (`accent`): o tom de texto `#3B68FA` passa de 4,5:1 no branco, e `#3F6DFF` é a ponta da marca nos gradientes (`accentFrom`, com `accentTo` clara). No escuro, o destaque é `#7B9CFF`. Os tokens derivados (`accentSoft`, `accentBorder`, `focus`, `sparkFill`, `rowHighlight`, `onAccent` no escuro) seguem o azul.
- **Tokens novos**, todos opcionais: `smoothRadius` (24), `smoothPadding` (24), `smoothShadow` (duas camadas suaves), `figureWeight` (600), `tile` e `tileRadius` (mini-blocos), `track`, `trackFill` e `gaugeTrack` (colunas e medidor), e `featuredFrom`, `featuredTo`, `featuredGlow` e `onFeatured` (card em destaque).
- **`TrendIndicator` com `anatomy="lean"` ganha o desenho smooth**:
  - topo com título e círculo de ícone de 40 px;
  - número 600 tabular, com decimais e unidade apagados;
  - pílula de variação colada ao número;
  - linha "Rótulo: **valor**", com o juízo em texto quando menor é melhor;
  - ressalva e desatualizado em pílula;
  - mini-gráfico de 2 px com área no gradiente.
  Fonte e atualização saem do card e ficam em "Como calculamos". Props novas: `featured` (card em gradiente azul) e `iconTone` (`selected` ou `accent`).
- **Componentes novos**:
  - `ColumnChart`: colunas com trilha de altura total, uma em destaque azul com hachura, balão com período e valores (na coluna em destaque, no hover e no foco), navegação pelo teclado e texto por coluna. Acompanha o `ColumnChartSkeleton`;
  - `SegmentedGauge`: medidor em meio círculo de segmentos, com o gradiente do destaque;
  - `IconCircle`, `DeltaPill` e `StatTile` (mini-bloco);
  - funções puras `niceScale`, `highlightedColumn`, `filledSegments` e `segmentPath`.
- **Controles e moldura**: `PillSelect` ganha `hideLabel` e o chevron passa a ficar num círculo. `ActionButton` ganha `variant="accent"` (pílula azul). `Panel` com anatomia `lean` passa a ter a superfície smooth.
- Storybook: nova seção "Smooth · Etapa 1" com contrato e as histórias:
  - fileira clara e escura;
  - estados: vazio, erro, desatualizado, sem permissão, parcial, valor ausente, sem comparação, mini-gráfico, mês zerado × sem leitura, medidor em 0% e 118%, painel carregando e com erro;
  - carregando.
- Baselines visuais regeneradas pela troca do destaque, exceto as do `StatCard`. Elas passam dentro da tolerância e ficam para o merge com a branch dos cards de loja.

**Etapa 2** (26/10; Etapa 1 aprovada às 12:48):

- **Destaque de barras em azul**: `highlight` (a barra em destaque de `Bars` e o meio-gauge) passa de laranja para `#3F6DFF` no claro e `#7B9CFF` no escuro.
- **`EvolutionChart` com `lean`**:
  - no topo, dois números grandes (realizado e meta até a última data comparável), com a diferença em pílula colada ao realizado;
  - legenda em pílulas;
  - linha suave monotônica, que não inventa picos nem vales entre os dias, com área um pouco mais cheia;
  - diferença, previsão (quando não cabe no topo) e notas da leitura vão para "Como calculamos" (mensagem nova `readingNotes`).
- **`ComparisonTable` com `lean`**:
  - busca e ordenação em pílula no cabeçalho;
  - cabeçalho da tabela em faixa cinza e linhas mais altas;
  - a busca ignora acento e caixa e casa o início das palavras. Durante a busca, subtotais e total saem da tela, porque somariam linhas ocultas, e a contagem é anunciada;
  - mensagens novas: `searchLabel`, `searchPlaceholder`, `searchCount` e `searchEmpty`.
- **`PriorityList` com `lean`**: cada prioridade vira um card-botão com ícone (ou a posição), título, uma evidência em até 2 linhas e a pílula de impacto. O card abre o `DetailPanel` com evidências, hipótese, próximo passo, estágio e ação, e o foco volta ao card ao fechar. Campo novo `PriorityItem.icon` e mensagens `impact` e `kind`.
- **`PillSearch`**: busca em pílula (React Aria `SearchField`). Esc limpa, e o botão de limpar some com o campo vazio.
- Storybook: nova seção "Smooth · Etapa 2", com a página clara e a escura. A página usa um conjunto fictício só (`stories/fixtures-smooth.ts`): os números do gráfico até 16/10 fecham com a linha Rede da tabela, e as prioridades citam as linhas da tabela, na ordem do critério.

**Catálogo e Fase 2** (27/10: lado smooth aprovado às 19:12, home às 19:20 e o fechamento às 21:19):

- **Início do catálogo**: galeria na composição da referência smooth, clara e escura (histórias `Início`), com o nome dos componentes, o exemplo fictício e o link do contrato em cada família.
- **`ContextBar` com `lean`** ganha o desenho smooth:
  - título 26/600 e perspectiva em trilha de pílula;
  - cada filtro vira uma `PillSelect` de 40 px, com rótulo e valor; recolhida, segue o resumo com o botão "Filtros" em pílula e a folha com cantos de 24 px;
  - prop nova `status` (`ready` | `loading`): esqueleto das pílulas e da linha de metadados, na geometria do estado pronto, com `aria-busy`;
  - filtro sem opções fica desabilitado e diz "Sem opções" (mensagem nova `noOptions`, além de `loading`).
- **`PillSelect`**: prop nova `description` (descrição acessível do gatilho). A lista abre alinhada à pílula inteira.
- **`PillItem.count`** aceita `null`: aparece "—" e é lido "sem contagem" (ausência nunca vira zero).
- **Menus** (listas de `PillSelect` e `SelectField`): cantos de 16 px, opção de 40 px com fundo cinza claro ao focar e check no azul.
- **Filtros e abas**: filtro ativo no gradiente azul, com a contagem numa bolha; desabilitado só com contorno. Abas em trilha de pílula, com a ativa em branco e o ícone no azul.
- **`OpenCard` e `DetailPanel`**: cantos de 24 px, ícone em círculo, número do card no peso 600, cabeçalho do painel sem borda e fechar num círculo cinza; no celular, folha de baixo com cantos de 24 px.
- **`StatCard` em destaque por token**: `statFeaturedFrom`, `statFeaturedTo` e `statFeaturedMuted`. O padrão continua grafite (o aprovado). O azul do indicador é só token: `var(--rb-featured-from)`, `var(--rb-featured-to)` e `var(--rb-on-featured)`. No azul, o texto secundário vai a branco pleno, porque 76% ficaria abaixo de 4,5:1.
- **`ComparisonTable` com `lean`**: prop nova `searchable` (padrão `true`) para dispensar a busca em tabelas curtas. Sem ordenação ativa, a pílula "Ordenar" diz "Ordem da fonte" (antes ficava vazia).
- **Demos** (27/10, decisão do Thiago às 21:05): comercial e agentes viram painel de resultado na estrutura da referência, com um conjunto fictício conciliado em cada uma. Os estados ficam no catálogo (Smooth/Etapa 1 · Estados).
- **Navegação**: "Smooth" agrupa as Etapas 1 e 2 e os componentes da Fase 2; "Legado" recebe os componentes v3 (0.3) e a revisão antes × depois. Os IDs das histórias não mudam. Os estudos editorial e Glass não fazem parte desta branch nem do catálogo.

### Notas de migração

- **Cor de destaque**: sem tokens próprios, o que era verde fica azul (foco, links, mini-gráficos, anéis e linha em destaque). Para manter o verde da 0.3, passe estes valores:
  - claro: `accent: "#0a7f5c"`, `accentSoft: "rgb(10 127 92 / 0.08)"`, `accentBorder: "rgb(10 127 92 / 0.24)"`, `focus: "#0a7f5c"`, `sparkFill: "rgb(10 127 92 / 0.12)"`;
  - escuro: `accent: "#3ad6a5"`, `onAccent: "#03130d"`, `focus: "#7ff2cb"`.
- **`anatomy="lean"`**: as props são as mesmas, mas o desenho muda (veja acima). Quem precisa do desenho enxuto da 0.3 fixa a `0.3.0-rc.3`.
- **`Panel` com `lean`**: só a moldura muda (raio, padding, sombra, sem borda).
- **Barra em destaque** (Etapa 2): para manter o laranja da 0.3, passe `highlight: "#c2410c"` no claro e `highlight: "#fb923c"` no escuro.
- **`PriorityList` com `lean`** (Etapa 2): as prioridades viram cards. Para manter a lista da 0.3, passe `itemDetail="expandable"` (ou `"inline"`).
- **`ComparisonTable` com `lean`** (Etapa 2): os atalhos de ordenação em controle segmentado e o seletor da visão em cards dão lugar à pílula "Ordenar" no cabeçalho, ao lado da busca. As props não mudam.
- **`EvolutionChart` com `lean`** (Etapa 2): os três números do resumo viram dois, e as notas saem de baixo do gráfico para "Como calculamos". Os dados e as props não mudam.

- **Merge da `ui-v0.3.0-rc.3`** (27/10, retomada do catálogo): a 0.4.0-rc.1 passa a trazer o `StatCard` smooth (padrão) e `featured` da tag, sem os estudos posteriores da branch `feat/stat-card`.
- **`ContextBar` com `lean`** (Fase 2): os filtros saem dos campos com rótulo em cima e viram pílulas; as props não mudam. A ajuda do filtro (`description`) continua acessível, mas não aparece embaixo da pílula: o essencial deve ir no rótulo ou nas opções. Quem precisa dos campos usa `anatomy="full"`.
- **Pílulas, menus e painel** (Fase 2): mudam só o desenho e o alinhamento da lista. Capturas-base que mostram filtros, abas, menus abertos ou o painel de detalhe precisam ser regeneradas.

## 0.3.0-rc.3 — 2026-10-26

Revisão do `StatCard` em duas rodadas: "minimalismo equilibrado" (23/10 15:59) e o estilo "mais clean, moderno, smooth" da referência Sales Overview (23/10 16:30). A prévia de 2 cards smooth recebeu o ok de Thiago em 26/10 12:48 para seguir; ainda é candidato para revisão visual (não aprovado como estável).

- **`variant="smooth"`, o novo padrão** (contrato em [docs/stat-card.md](docs/stat-card.md)): card de raio 24 px com sombra suave, ícone de 40 px num círculo (`emblem`), número 34/600 com a pílula de variação colada e a linha "Rótulo: valor", até 3 estatísticas em mini-blocos cinza, forma recente em barras-pílula e no máximo um selo. Sem posição, o selo "—" some da tela e a leitura fica para o leitor de tela. Em card estreito (até 18 rem de conteúdo, como num carrossel de celular), número de 30 px e mini-blocos compactos. Muito estreito, os mini-blocos viram linhas.
- **`featured`**: pinta o card no gradiente `artFrom → artTo` com texto `onArt`, para o primeiro de um ranking (um por grade).
- **`primary.delta`** (`StatCardDelta`: texto, seta `up`/`down`/`flat`, tom e `srLabel`): seta e tom são independentes, porque nem toda alta é boa. **`primary.baseline`** (`StatCardBaseline`: rótulo e valor) desenha a linha "Meta até 15/10: R$ 216,7 mil".
- **Barras-pílula** (`pillGeometry`, tipo `PillBar`): a trilha é a referência do dia e o cheio é o valor. Na referência ou acima, a barra fica cheia. O último dia com valor vai em destaque hachurado, o dia sem operação tracejado e o dia sem dados vira um anel. Um zero de verdade ganha uma marca no fundo.
- **Token novo** `shadowSoft` (`--rb-shadow-soft`), opcional.
- Storybook: as histórias passam para o `smooth`, com a loja #1 em `featured`; o enxuto fica em "Enxuto (plain)" e a anatomia antiga em "Arte (rc.2)".

Da rodada de 23/10 (continua disponível):

- **`StatCard` ganha `variant`**:
  - `plain`: cabeçalho leve na superfície (título, posição num selo "#1", uma linha com tipo e status), um número de 30 px com barra fina, até 3 estatísticas numa fileira (rótulo de uma linha, valor de 15 px na mesma linha de base, sem legendas), forma recente sem moldura (barras finas, referência em linha sutil, resumo "7/10 dias na meta") e no máximo um selo, sempre no pé. Mesma altura para todos os cards de uma grade com os mesmos dados.
  - `art`: a anatomia da 0.3.0-rc.2, sem mudanças.
- Texto novo: `messages.formSummaryShort` (resumo curto do `plain`, pt-BR e en-US).
- Tipo novo exportado: `StatCardVariant`.
- Storybook: as histórias passam para o `plain`; a anatomia antiga fica em "Arte (rc.2)".

### Notas de migração

- Quem usa o `StatCard` da 0.3.0-rc.2 e quer manter o visual: passe `variant="art"`.
- Quem quer o enxuto da rodada de 23/10: passe `variant="plain"`.
- No `plain`: `emblem` e `stats[].note` não aparecem (leve o complemento para `srLabel` ou para o detalhe); `stats` com mais de 3 itens quebra a fileira; de vários `badges`, só o primeiro aparece. `ratio` desenha a barra fina no lugar do anel.

## 0.3.0-rc.2 — 2026-10-23

Um widget novo, sem mudança nos existentes. Candidato para revisão visual (não aprovado).

- **`StatCard`** (contrato em [docs/stat-card.md](docs/stat-card.md)): card de estatísticas "estilo card de jogador", genérico para loja, vendedor, agente ou produto.
  - Arte no topo com posição ("#03 de 12 · critério"), emblema, título, sobrelinha · subtítulo e status em pílula.
  - Número principal em anel (`ratio`) ou número grande, com uma linha de apoio.
  - Grade de 4 a 6 estatísticas (duas colunas; três a partir de 25 rem de card).
  - Forma recente: valor × referência por dia numa escala comum, com polaridade (`higher-is-better` ou `lower-is-better`).
  - Selos de exceção.
  - Um botão só, no título, esticado sobre o card. O nome é o título e a ação vem como descrição.
  - Estados: sem posição, valor ausente ("—", lido "sem valor"), sem meta, carregando (esqueleto da mesma anatomia), estático (sem `onOpen`) e destacado.
  - Ausência (`missing`) e dia sem operação (`closed`) nunca viram zero na forma; zero é zero e negativo desce de um zero comum. Dia parcial ganha hachura.
- Funções puras exportadas: `formPointState`, `classifyFormPoint`, `countForm`, `formGeometry` e `formatRank`. Textos em `statCardMessages` (pt-BR e en-US) e `resolveStatCardMessages`.
- **Tokens novos** (opcionais): `artFrom` e `artTo` (gradiente da arte), `onArt` e `onArtMuted` (texto sobre a arte). Os padrões são grafite no claro e verde-grafite no escuro, com texto de pelo menos 4,5:1. Uma identidade troca a arte só por tokens.
- Storybook: "Widgets/StatCard" com contrato, padrão (quatro contextos), estados, texto longo e container estreito, claro e escuro e identidade por tokens.

### Notas de migração

Nenhuma: só adições. Quem fixa `0.3.0-rc.1` não muda nada até trocar a versão.

## 0.3.0-rc.1 — 2026-10-20

A linguagem visual v3 vira o padrão da biblioteca: clara primeiro, escuro derivado só por tokens, superfícies limpas, raio 20/12/pílula, sombra mínima e contornos finos. Os componentes genéricos que o primeiro concept validou passam para cá. Candidato para revisão visual (não aprovado). Nenhuma prop foi removida ou mudou de tipo; o visual e o modo padrão mudam (veja as notas de migração).

- **Tema v3 por tokens**:
  - Modo claro é o padrão (`RbTheme`, `:root` e Storybook); o escuro sai dos mesmos componentes.
  - Superfícies `#F3F4F6`/branco no claro; contorno quase invisível no lugar da sombra no escuro.
  - Raio `radiusCard` 20 px, `radiusControl` 12 px e `radiusChip` pílula.
  - Uma família por token (`fontSans`), com Plus Jakarta Sans 5.3.0 (OFL) autohospedada em `@rbbt/ui/fonts.css` como opção pronta. `fontDisplay`, `fontNumeric` e `fontTabular` apontam para ela; os tabulares têm zero limpo.
  - Piso tipográfico: `textLabel` 12 px e `textBody` 13 px, aplicado também nos rótulos e notas dos widgets existentes.
  - Números grandes leves (`numberWeight` 500 no claro, 400 no escuro), com decimais, moeda e unidade apagados.
  - Movimento de 160/240/320 ms (`durationFast`/`Base`/`Slow`), zerado com `prefers-reduced-motion`.
  - Tokens novos: `selected`, `onSelected`, `highlight`, `bar`, `barMuted`, `shadowHover`, `numberWeight`, `textLabel` e `textBody`.
- **Componentes novos** (contratos em [docs/v3.md](docs/v3.md)):
  - `OpenCard`: card que abre. O card inteiro é o botão, com a seta circular sinalizando.
  - `DetailPanel`: lateral no desktop e folha inferior no celular, com foco preso, Esc e retorno do foco ao card. `useUrlParam` é o gancho opcional para a URL.
  - `PillSelect`, `PillTabs` e `FilterPills`: seleção, abas e filtros em pílula.
  - `StatusDot` (ponto + texto) e `IconSquare` (quadrado de ícone).
  - `ProgressRing` e `HalfGauge`: anel e meio-gauge, com `gaugeFill`.
  - `Bars`: barras arredondadas, uma em destaque com hachura opcional, ausência ≠ zero e negativos a partir de um zero comum. Acompanha `highlightedBar`.
  - `Figure`: número com partes apagadas, mais `figureParts` e `numberSeparators`.
  - `ActionButton variant="primary"`: a ação principal em pílula preenchida.
- **Componentes existentes no v3, sem mudança de API**: `TrendIndicator`, `EvolutionChart`, `ComparisonTable`, `PriorityList`, `ContextBar`, `Panel` e os primitivos.
  - `StatusChip` vira ponto + texto, sem bloco colorido.
  - O cabeçalho da `ComparisonTable` sai da caixa-alta.
  - Os chips de ícone ficam com 32 px e raio 10.
  - Botões viram pílula.
- Storybook abre no claro e ganhou a seção "Componentes v3", com os dois modos lado a lado.

### Notas de migração

- **Modo padrão**: sem `mode`, `RbTheme` (e `:root`) agora é claro. Para manter o escuro, passe `mode="dark"`.
- **Visual**: os mesmos componentes ficam com outra cara (tipografia, raio, superfícies, sombra, status em ponto). Para revisar a página antes de trocar de versão, compare capturas. Uma identidade pode recuperar parte do visual 0.2 por tokens, por exemplo `fontSans: '"Mona Sans Variable", ui-sans-serif, system-ui, sans-serif'`, `radiusCard: "14px"` e `radiusControl: "8px"`. Mona Sans e Hubot Sans continuam em `fonts.css`.
- **Fontes**: `fonts.css` passa a incluir Plus Jakarta Sans (cerca de 57 kB a mais em woff2, baixados só se a página usar a família). Quem não importa `fonts.css` recebe a fonte do sistema até fornecer a sua.
- **Tokens**: um objeto `RbThemeTokens` parcial continua valendo. As chaves novas são opcionais.
- **CSS**: a folha ganhou a camada `rb-floor`, depois de `utilities`, com o piso de 12/13 px. Uma página que precise de texto menor dentro de um widget deve sobrescrever nessa camada ou fora de camadas.

## 0.2.0-rc.2 — 2026-10-19

Rodada de limpeza depois da primeira prévia que consome o pacote ("cards muito poluídos"). Candidato para revisão visual (não aprovado). Sem mudança incompatível: sem `anatomy="lean"` e fora de um `PageContextProvider`, os widgets renderizam como no 0.2.0-rc.1. A única diferença visual é que o nome da linha da `ComparisonTable` agora fica na mesma linha de base dos números (antes ficava ~3 px abaixo).

- **Contexto da página**: `PageContextProvider` informa período, fonte, atualização, idade máxima, relógio e anatomia uma vez; `usePageContext`, `resolveProvenance` e `useWidgetProvenance`. Com `provenance="inherit"` (padrão), o widget não repete o que for igual ao da página e mostra o que difere (ex.: posição de estoque datada). O que sai do card ou do rodapé continua em "Como calculamos".
- **Anatomia enxuta** (`anatomy="lean"`):
  - `TrendIndicator`: nome, número, uma linha de comparação (selo com seta, sinal e texto, mais a referência), marcador de ressalva e mini-gráfico. Ressalvas, definição, fonte e atualização ficam em "Como calculamos", que o marcador e o botão de informação abrem. No máximo uma ação. Props novas: `anatomy`, `marker`, `methodology`, `provenance`, `valueAsChange.label`.
  - Widgets de painel (`Panel`): ressalvas em linha, sem caixa dentro do card; fonte e atualização herdadas saem do rodapé.
  - `PriorityList`: `itemDetail="expandable"` (padrão na enxuta) mostra problema e assunto, evidência principal, próximo passo e diferença; as demais evidências, a hipótese e a posição na lista abrem em "Ver evidências".
  - `ContextBar`: `period`; metadados numa linha só, com a cobertura como marcador; filtros recolhidos num resumo de uma linha com o botão "Filtros"; `ContextFilter.showInSummary` e `SelectOption.shortLabel`.
- `Marker`: ressalva de uma linha (ícone e palavra, sem caixa colorida), com o detalhe em painel por clique, toque ou teclado; alvo de 24 px (44 px em ponteiro grosso) e anel de foco.
- `ComparisonTable`: `columnGroups` com `ComparisonColumn.group` (cabeçalho comum por bloco, ex.: "Mês até 17/10" | "Comparação com a meta até 15/10", e seções nos cartões); `ComparisonColumn.derived` com `verifyDerived` (a conta de diferença, razão ou variação é conferida em cada linha, subtotal e total, e o resultado vai para o rodapé); rótulo do grupo no cabeçalho do CSV; o CSV leva a fonte mesmo quando a tela a mostra só no contexto; etiquetas ao lado do nome na enxuta. Funções `checkDerived` e `deriveValue`.
- `InfoPopover.title` (título visível, ex.: "Como calculamos"); conteúdo longo rola dentro do painel. `hasMethodologyContent`.
- `EvolutionChart`: `anatomy` e `provenance`.

### Notas de migração

- Nenhuma prop foi removida ou mudou de sentido; o padrão continua `full`. Para adotar, envolva a página em `PageContextProvider` com `anatomy="lean"` e informe período, fonte e atualização uma vez.
- Textos novos nos tipos de mensagens:
  - `TrendIndicatorMessages`: `methodologyTitle`, `methodologyFor`.
  - `PriorityListMessages`: `mainEvidence`, `otherEvidence`, `rankReason`, `showDetail`, `hideDetail`.
  - `ComparisonTableMessages`: `derivedOk`, `derivedMismatch`, `formulaDifference`, `formulaRatio`, `formulaChange`.
  - `ContextBarMessages`: `filtersSummary`.
  - Um objeto **completo** tipado com esses tipos precisa incluí-las; `messages` parciais não mudam.
- CSV com `columnGroups`: o cabeçalho de cada coluna leva o rótulo do grupo ("Grupo · Coluna (BRL)"). Sem grupos, o arquivo é o mesmo.
- Quem monta `Panel` com `useWidgetFrame` diretamente não precisa mudar nada. Para a fonte do rodapé ser comparada à da página, passe `source` também ao `useWidgetFrame`.

## 0.2.0-rc.1 — 2026-10-18

Candidato para revisão visual conjunta com a primeira prévia que consome o pacote (não aprovado). Sem mudança incompatível na API de props do 0.1.0-rc.1.

- Widgets de painel novos:
  - `EvolutionChart` (ECharts 6, SVG, carregado sob demanda): realizado, meta e previsão nas visões acumulada, diária e tabela; realizado termina no corte; lacunas, dias futuros e dias sem operação nunca viram zero; meta diária só com distribuição (meta do período à parte); previsão com versão, método e data; dias parciais marcados; diferença na última data comparável; teclado (setas, Home/End, Esc) e resumo textual. Rótulos diretos fixos no último ponto de cada série: não acompanham a animação de entrada (o `endLabel` do ECharts nascia com posição inválida numa série que começa vazia, como a previsão).
  - `ComparisonTable` (TanStack Table 9): ordenação com critério visível e presets (o botão do cabeçalho se chama só pelo rótulo da coluna, que o leitor de tela repete a cada célula; o estado fica em `aria-sort`), números tabulares, selos de situação por linha, grupos com subtotal, total conferido contra a soma das linhas, cartões abaixo de 640 px de container, linha em destaque, detalhe por link/callback e exportação CSV com recorte e instante.
  - `PriorityList`: problema → evidência → hipótese → próximo passo, critério de ordenação visível, estágio em texto (sugestão ≠ aprovação ≠ execução) e `evidenceLimit` com "Mais N evidências" por item.
  - `ContextBar` (título, perspectiva, filtros, atualização, cobertura e fonte; painel de filtros no estreito) e `ScopeNote` (recorte efetivo).
- Primitivos: `Panel` (moldura com estados desenhados, notas visíveis e rodapé de fonte/atualização/metodologia), `WidgetState`, `SegmentedControl`, `SelectField`, `StatusChip`, `Methodology`/`MethodologyList` ("Como calculamos") e `useWidgetFrame` (estados `ready`, `loading`, `empty`, `error`, `restricted`, `partial`, `stale`).
- `TrendIndicator` (aditivo): estados `restricted` e `partial` (`partialNote`), `caveat` sempre visível, `secondaryValue` e `valueAsChange`. No estado sem permissão a ação some.
- Fundação: tokens de séries, grade, faixas e cursor de gráfico; linha em destaque e faixa de grupo de tabela; `info`/`infoSoft`; `fontTabular`, `displayWeight` e `panelTitleSize`. Chips `positive` e `accent` com o texto puxado 15% para `--rb-fg`, para manter AA sobre o próprio fundo suave nos dois modos. `ValueFormat.signDisplay` opcional. Formatação de dias ISO sem fuso (`formatDay`, `formatDayRange`, `dayRange`…).
- Formatação: o texto por extenso (`full`) de moeda passa a mostrar centavos completos quando houver (R$ 50.710,40, não R$ 50.710,4); valores inteiros continuam sem casas.
- Dependências novas e exatas: `echarts` 6.1.0 e `@tanstack/react-table` 9.3.1.

### Notas de migração

- Nenhuma prop foi removida ou mudou de sentido. Quem só passa `messages` parciais não precisa mudar nada.
- `TrendIndicatorMessages` ganhou chaves (`restrictedTitle`, `restrictedDescription`, `partial`, `partialDescription`): um objeto **completo** tipado como `TrendIndicatorMessages` precisa incluí-las.
- `TrendIndicatorStatus` ganhou `restricted` e `partial`: um `switch` exaustivo sobre o tipo precisa tratar os dois.
- `InfoPopover` envolve o conteúdo em `div` (antes `p`) para aceitar conteúdo rico.

## 0.1.0-rc.1 — 2026-10-18

Primeiro candidato para revisão visual (não aprovado).

- Fundação: tokens semânticos `--rb-*`, modos escuro e claro, densidade compacta, identidade por tokens via `RbTheme` ou CSS.
- Primitivos: `ActionButton` (React Aria), `InfoPopover`, `Skeleton`.
- Widget `TrendIndicator`: valor com hierarquia tipográfica, comparação com polaridade e modos `percent`/`points`/`absolute`, base zero, micro-tendência SVG com alternativa textual, fonte, atualização, ação com restrição, estados pronto/carregando/vazio/erro/desatualizado, distinção de zero/ausência/negativo/inválido, layout por container queries, redução de movimento, textos pt-BR/en-US.
- Adaptadores: `summarizeSeries`, `indicatorDataFromRecord`, `toMetricValue`.
- Build: ESM + `styles.css` (Tailwind v4, prefixo `rb:`, sem preflight global) + `fonts.css` opcional + declarações TypeScript.
