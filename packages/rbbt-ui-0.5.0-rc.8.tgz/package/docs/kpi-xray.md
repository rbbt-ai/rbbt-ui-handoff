# Raio-X do indicador (0.5.0-rc.7)

Abre, a partir de qualquer número, um painel que explica de onde o número vem: **fórmula**, **fonte** (origem e atualização), **filtros aplicados**, **exclusões** (lojas, itens e por quê) e **conferência do total**. A soma das partes bate com o total, ou a diferença aparece explicada. Ausência e exclusões aparecem listadas com o efeito no total; **ausência nunca vira zero**.

O componente não grava nada, não usa localStorage e não chama rede: a definição e o contexto chegam por props, e abrir ou fechar só avisa por callback.

## Mecanismo

```tsx
<RbTheme client={cliente}>
  <XrayProvider locale="pt-BR" onOpen={(r) => log(r.definition.id)}>
    <TrendIndicator label="Venda líquida" data={dados} format={brl} xray={{ definition, context }} />
    <ComparisonTable columns={[{ id: "actual", header: "Venda", format: brl, xray: (ctx) => pedidoDaLinha(ctx) }]} />
    <BulletBar label="Centro" actual={336_900} target={343_800} xray={pedidoDaLoja("centro")} />
    <XrayTrigger request={pedido} valueText="R$ 1.719.800">R$ 1.719.800</XrayTrigger>
  </XrayProvider>
</RbTheme>
```

- **`XrayProvider`** guarda o painel aberto (estado interno) e monta um único painel por árvore. Fica dentro do `RbTheme`: o painel é montado na raiz do tema (`UNSTABLE_portalContainer`) e só abre quando ela existe, para herdar fontes, cores e o modo escuro.
- **`XrayTrigger`** envolve qualquer número. Dentro do provedor e com `request`, vira um botão discreto (sublinhado pontilhado, sem mudar o tamanho do número) com o nome **"Raio-X de <indicador>: <valor>"**. Sem provedor ou sem `request`, devolve o número como está.
- **`useXray()`** abre pelo código: `xray.open(request, { returnFocusId })`, para atalho, menu ou botão próprio. Fora do provedor, `available` é `false` e `open` não faz nada.

| Prop do `XrayTrigger` | Tipo | O que faz |
| --- | --- | --- |
| `request` | `XrayRequest \| null` | Definição + contexto. `null` = sem botão. |
| `valueText` | `string` | Valor no nome do botão (use o texto visível). Padrão: o total no formato da definição. |
| `id` | `string` | Id do botão; recebe o foco ao fechar. Padrão: gerado. |
| `size` | `"md" \| "sm"` | `sm` em célula e barra: o alvo cresce até 24 px sem mexer no layout. |

### Nos widgets existentes (aditivo)

| Widget | Prop | Onde vira botão |
| --- | --- | --- |
| `TrendIndicator` | `xray?: XrayRequest \| null` | O valor principal (smooth e anatomia completa). |
| `ComparisonTable` | `columns[].xray?: (ctx: ComparisonCellContext) => XrayRequest \| null` | A célula da coluna (linha, subtotal ou total; tabela e cartões). |
| `BulletBar` | `xray?: XrayRequest \| null` | O texto ao lado do trilho (ou o trilho, com `text="none"`). Ignorado com `decorative`. |

Sem `XrayProvider` ou sem a prop, os três widgets ficam idênticos aos de antes.

## Definição e contexto

`XrayRequest = { definition, context, subject?, action? }`.

- **`KpiDefinition`** (estável): `id`, `label`, `formula`, `description?`, `source { origin, updatedAt?, cadence? }`, `format` e `partsLabel?` ("lojas", "semanas").
- **`XrayContext`** (o recorte atual): `period`, `stores`, `filters?`, `total`, `parts?`, `exclusions?`, `tolerance?`, `status?` (`ready`, `loading`, `partial`, `empty`, `error`), `partialNote?` e `errorMessage?`.
- **`subject`** entra no título e no nome do botão ("Venda líquida · Centro").
- **`action`** (opcional) fica no rodapé, por callback ou link; com `disabledReason`, aparece desabilitada com o motivo, nunca escondida.

Período, lojas e origem ficam no cabeçalho do painel em todos os estados.

## Conferência do total (`reconcileTotal`)

| Resultado | Quando |
| --- | --- |
| **Bate** | soma das partes = total (dentro de `tolerance`). |
| **Diferença explicada** | difere, e as exclusões ainda somadas nas partes (`inParts: true`) explicam a diferença inteira. |
| **Diferença sem explicação** | sobra diferença (`residual`) que nenhuma exclusão explica; o valor aparece. |
| **Não fecha: falta dado** | alguma parte (ou efeito de exclusão nas partes) está sem leitura ou inválida. A soma mostrada é "das N de M com leitura", nunca o total. |
| **Sem dados** | total sem leitura ou nenhuma parte. |

- `value: null` é **sem leitura** e `NaN` é inválido: nenhum dos dois vira zero.
- Exclusão sem `inParts` informa o que ficou de fora (as partes já vêm sem ela) e mostra o efeito com sinal ("−R$ 2.350 no total"). Efeito `null` aparece como "Efeito sem leitura".
- Arredondamento: `tolerance` na unidade do valor (ex.: `1` = R$ 1).

## Adaptador

`xrayFromRecords(registros, { label, value, id?, note?, exclusionReason?, exclusionKind? })` converte linhas de uma view (Bases, API) em partes e exclusões com `toMetricValue`: "336.900" → 336900, vazio → sem leitura, "abc" → inválido. Linha com motivo de exclusão vira exclusão fora das partes com efeito `−valor`.

## Acessibilidade e motion

- Painel = `dialog` nomeado pelo título, foco preso, **Esc** e clique fora fecham, e o foco volta ao número que abriu.
- Lateral no desktop e folha inferior abaixo de 760 px; o corpo rola por dentro (focável) e nada corta a 360 px.
- As partes têm tabela com legenda ("Venda líquida: partes do total · Outubro até 29/10 · 7 lojas"); até 6 partes ela abre sozinha (`defaultPartsOpen` muda isso).
- O painel entra e sai pelo `DetailPanel`; as seções sobem 4 px em cascata curta com Motion, só na abertura (o que chega depois, como carregando → pronto, aparece no lugar); com reduced motion, sem deslocamento.

## O que não faz

Não calcula o indicador nem busca a fonte: quem usa entrega o total, as partes e as exclusões. Não valida permissão de dado (o backend valida); a interface só mostra.
