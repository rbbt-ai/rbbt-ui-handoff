# Capital em estoque (`StockCapital`, 0.5.0-rc.4)

Quanto dinheiro está parado no estoque, há quanto tempo e onde. Duas leituras do mesmo número:
**barras por idade** (0–30, 31–90 e +90 dias) e **treemap** por marca e por loja. Barras e blocos fecham
ao centavo.

## Dados

```ts
interface StockCapitalData {
  brands: StockEntity[];        // { id, label }
  stores: StockEntity[];
  positions: {                  // uma posição = uma marca numa loja
    brand: string;
    store: string;
    ages: { "0-30"?: number | null; "31-90"?: number | null; "90+"?: number | null };
  }[];
}
```

- **Base de valor declarada**: `basis="cost" | "price"` (e `basisLabel`, ex.: "custo médio"). O texto aparece
  no topo dos números ("Capital total a custo"). O widget não converte: os valores já vêm na base escolhida.
- **Posição datada**: `position` ("26/10/2026") aparece no topo, com `scope` ("8 lojas") e `period`, se houver.
  `source` fica no rodapé, sempre.
- **Ausência nunca vira zero.** Faixa `null` (ou ausente) = *sem leitura*: fica **fora da soma** e aparece na lista
  "N posições sem leitura (fora da soma, não é zero)", com loja, marca e faixas. Um nó sem nenhuma leitura não
  ocupa área no treemap. Zero é leitura: um bloco zerado não tem área e aparece em "Sem capital: …".
- **Par marca × loja sem posição** = a loja não trabalha a marca. Não é ausência e não entra na lista.

### Adaptadores

- `stockCapitalFromRecords(rows, mapping)`: linhas de uma view de Bases ou `reader.rows("capital")` de um
  cenário pronto (`createScenarioReader`). Número pela regra de `toMetricValue` ("1.234,56" → 1234,56); vazio,
  `null` e texto inválido são ausência. Linhas repetidas na mesma posição e faixa somam.
  - **Formato longo**: `{ brand, store, age, value, ageValues? }`, uma linha por posição × faixa. A faixa aceita
    "0-30", "31-90", "90+" e "+90" (ou o mapa `ageValues`).
  - **Formato largo**: `{ brand, store, ages: { "0-30": "ate30", "31-90": "de31a90", "90+": "acima90" } }`.
  - `brandLabel`/`storeLabel` (campos dos rótulos) e `brandOrder`/`storeOrder` (ordem e rótulos prontos).

## Regras e fórmulas

- Tudo é somado em **centavos inteiros** (`toCents`): 0,1 + 0,2 fecha em 0,30.
- **Capital da faixa** = soma das leituras da faixa. **% do capital** = faixa ÷ total com leitura.
- **Capital do bloco** = soma das leituras das suas posições (todas as faixas).
- **Fatia acima de 90 dias** = capital +90 do bloco ÷ capital do bloco. Sem leitura da faixa +90 no bloco, ou
  com capital zero, a fatia é *sem leitura* (nunca 0%).
- **Faixas de risco** pela fatia +90: `riskThresholds`, padrão `[0.1, 0.2, 0.35]` → `< 10%`, `10–20%`, `20–35%`
  e `≥ 35%`. A mais alta leva **hachura**, além da cor.
- **Conciliação** (`reconcileStockCapital`): soma das barras = soma dos blocos = total; cada marca = soma das
  suas lojas e cada loja = soma das suas marcas, por faixa. O rodapé mostra "Barras e blocos fecham em R$ …"
  só quando tudo fecha. Testado ao centavo nas duas hierarquias.

| Token | Uso |
| --- | --- |
| `--rb-cap-risk-1` … `--rb-cap-risk-4` | Tons dos blocos pela fatia +90 (o 1 vem do acento do tema ou do cliente) |
| `--rb-cap-on-risk-1` … `--rb-cap-on-risk-4` | Texto sobre cada tom (contraste AA) |
| `--rb-cap-hatch` | Hachura do +90 nas barras e da faixa de risco mais alta |
| `--rb-cap-risk-ink` / `--rb-cap-risk-soft` | Etiqueta "risco" da barra +90 |
| `--rb-cap-absent` | Tracejado da ausência |
| `--rb-cap-hover-in` / `--rb-cap-hover-out` | 150 ms / 110 ms (zeram com movimento reduzido) |
| `--rb-cap-update` | 480 ms: troca de dado, do valor antigo ao novo |
| `--rb-cap-fade` | Recuo dos outros itens com um ativo (opacidade 0,45 no claro, 0,5 no escuro) |
| `--rb-cap-hover-ease` | `cubic-bezier(0.22, 1, 0.36, 1)` |

## Interação

- **Treemap**: área = capital; cor = faixa de risco. A hierarquia alterna entre **marca → loja** e
  **loja → marca** (`hierarchy`/`defaultHierarchy`/`onHierarchyChange`).
- **Clique ou Enter** num bloco abre o nível de baixo (as lojas da marca). O caminho aparece em cima, com
  "Voltar" e o primeiro nível clicável; **Esc** também volta. `focus`/`defaultFocus`/`onFocusChange` controlam
  o bloco aberto. No detalhe, as barras e o total passam a ser os do bloco: o detalhe também fecha ao centavo.
- **Hover, foco do teclado ou tap**: o bloco ativo ganha contorno e sombra curta; os outros recuam
  (`--rb-cap-fade`); o balão mostra nome, valor exato, % do total (ou do bloco de cima), fatia +90, posições sem
  leitura, "Clique ou Enter abre as lojas" e o contexto. As barras seguem o mesmo recuo no hover.
- **Movimento reduzido**: sem recuo animado; só contorno no bloco ativo.

## Acessibilidade

- Treemap em `role="list"`, um `listitem` por bloco, tabindex móvel (um bloco na ordem de Tab) e **setas pelo
  vizinho mais próximo na direção**, Home/End, Enter (detalhe) e Esc (fecha o balão; de novo, volta).
- Nome de cada bloco: "‹nome›: ‹valor exato›, ‹%› do capital, +90 dias: ‹%›, Clique ou Enter abre as lojas"
  (no detalhe, "‹%› de ‹bloco de cima›" e sem a ação).
- Ao abrir o detalhe, o foco vai para o primeiro bloco; ao voltar, para o bloco de onde saiu.
- **Ver tabela**: idade (faixa, capital, %) e o nível atual do treemap (nome, capital, %, +90 em R$ e %), com
  ausência por extenso e total. No primeiro nível, o nome abre o detalhe.
- O balão é visual (`aria-hidden`): o leitor de tela recebe tudo no nome do bloco.

## Movimento

- Entrada na página, troca de módulo ou entrada na tela: as barras crescem da base e os blocos surgem em
  **cascata** (`--rb-duration-enter`, `--rb-duration-stagger`, até 12 passos). O total conta até o valor.
- **Troca de recorte ou de dado**: barras vão da largura antiga à nova; blocos vão da posição e do tamanho
  antigos aos novos (Motion), **sem cascata e sem voltar a zero**. O total conta do antigo ao novo.
- **Detalhe e hierarquia**: os blocos do novo nível nascem no lugar final, com um fade curto (150 ms). Nada
  cresce do zero fora da entrada.
- Movimento reduzido: estado final direto.

## Estados

Carregando (esqueleto com barras e área do treemap), vazio, erro (com "Tentar novamente"), sem permissão,
parcial (aviso visível) e desatualizado, pela moldura comum (`Panel`).

## Layout

- A partir de 720 px de container: barras à esquerda, treemap à direita. Abaixo disso, uma coluna.
- Abaixo de 520 px o treemap fica mais alto que largo (1 : 1,1). Blocos pequenos escondem textos que não cabem
  (nome a partir de 64 × 34 px); o valor continua no balão, no nome acessível e na tabela.
- A 360 px não há rolagem lateral; a tabela rola só dentro do widget.

## Por que DOM e não ECharts

O treemap do ECharts desenha em canvas: foco por bloco, nome acessível, hachura, tokens de tema e de cliente e o
caminho de volta ficariam fora do componente. O treemap quadrado (Bruls, Huizing e van Wijk) tem ~60 linhas
puras e testadas (`squarify`); os blocos são DOM focável, com CSS por tokens e Motion pelas regras dos outros
widgets, sem biblioteca nova.
