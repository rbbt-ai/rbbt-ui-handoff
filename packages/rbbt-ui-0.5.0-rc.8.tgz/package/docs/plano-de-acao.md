## Uso

`ActionBoard` organiza ações em quatro etapas: **sugerido → aprovado → executado → resultado avaliado**. Avançar para executado e para avaliado **exige evidência escrita**. Voltar uma etapa não exige.

## Persistência por callback

O componente não guarda nada (sem `localStorage`). Quem usa grava e devolve em `items`:

- `onCreate(draft)`: "Nova ação" (título, unidade, responsável).
- `onMove(id, etapa, evidência?)`: mover uma etapa; a evidência vem junto quando é obrigatória.
- `onEvidence(id, etapa, texto)`: registro da evidência (ex.: linha de histórico).

Numa base, grave com `--idempotency-key` e atualize com `--expected-version` (`ActionItem.version`).

## Dados (contrato com Bases)

`actionsFromRecords(rows, mapping)` lê linhas planas: `id`, `title`, `stage` (aceita "sugerido", "aprovado", "executado", "avaliado" e os nomes em inglês), `unit`, `owner`, `due`, `rationale`, `executedEvidence`, `evaluatedEvidence`, `version`. Etapa desconhecida vira "sugerido": nada avança sem evidência.

`canMoveAction(item, para, evidência?)` aplica a regra: uma etapa por vez e evidência para executado/avaliado.

## Textos do cliente nos botões (0.5.0-rc.2)

`advanceLabels` troca o texto visível do botão de avanço, por etapa de destino:

```tsx
<ActionBoard advanceLabels={{ approved: "Simular aprovação", executed: "Registrar execução", evaluated: "Registrar avaliação" }} … />
```

- Sem `advanceLabels`, o botão mostra o nome da etapa ("Aprovado →"), como antes.
- O nome acessível **começa pelo texto visível** ("Simular aprovação: Repor numeração 35"), sem `label-content-name-mismatch` (WCAG 2.5.3).
- Nas etapas que pedem evidência, o mesmo texto confirma o registro (no lugar de "Registrar e avançar").
- Texto longo quebra em duas linhas dentro do card, sem estourar a coluna.

## Teclado

- Cada card recebe foco. **Alt + →** avança; **Alt + ←** volta.
- Ao pedir evidência, o foco vai para o campo; sem texto, aparece o erro e o foco volta ao campo.
- Depois de mover, o foco acompanha o card na etapa nova e um aviso `aria-live` informa a mudança.

## Estados

Carregando, sem ações (colunas vazias com aviso), erro (com "Tentar de novo").
