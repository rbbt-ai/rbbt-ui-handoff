# MixExplorer — contrato

Versão do pacote: `@rbbt/ui@0.4.0-rc.2` · estado: **candidato para revisão visual** (o aceite é do Thiago e nunca é inferido).

Explorador de mix: navega uma árvore de níveis (padrão **Linha → Marca → Referência**) e mostra, em cada nível, a **participação** de cada item no mix e a **contribuição** dele para a variação do nível, em pontos percentuais. Cada clique detalha o número, o caminho volta a qualquer nível, os filtros ficam como estão e o último nível abre o detalhe do item. Sem rede: os dados de cada recorte vêm da página. Linguagem smooth (painel r24, pílulas, mini-blocos, números 600).

```tsx
import { MixExplorer } from "@rbbt/ui";

<MixExplorer
  title="Explorador de mix"
  context="Outubro 2026 vs outubro 2025 · venda líquida · todos os canais · mesmo universo de lojas"
  metric={{ label: "Venda líquida", format: { style: "currency", currency: "BRL", notation: "standard" }, scale: 100 }}
  data={arvore /* MixNode: raiz "Todas as linhas" → linhas → marcas → referências, em centavos */}
  filters={[{ id: "canal", label: "Canal", options: [{ value: "todos", label: "Todos os canais" }, { value: "online", label: "Online" }] }]}
  filterValues={filtros}
  onFiltersChange={(next) => setFiltros(next) /* a página busca a árvore do recorte novo */}
  path={caminho}
  onPathChange={(next) => setCaminho(next) /* ex.: guardar na URL */}
/>;
```

## Dados (`data: MixNode`)

| Campo | Significado |
| --- | --- |
| `id` | Único entre os irmãos; vai no caminho e na URL. |
| `label` | Nome exibido (dado, nunca instrução). |
| `current` | Valor do período atual, na menor unidade (centavos, unidades), de preferência inteiro. `null` = **sem leitura**. |
| `base` | Valor do período de comparação. `0` com `current > 0` = item **novo**. `null` = sem leitura. |
| `children` | Filhos no próximo nível. A soma deles deve ser igual a `current` e `base` do nó. |

- A raiz é o "todos" (ex.: "Todas as linhas") e não entra no caminho.
- Nó com filhos e sem valor próprio (`null`) vale a **soma dos filhos**, se todos tiverem leitura; senão continua sem leitura.
- `metric`: `label`, `format` (Intl via `formatValue`), `scale` (100 para centavos) e `polarity` (padrão `higher-is-better`: contribuição positiva é favorável).
- `levels`: nomes dos níveis abaixo da raiz. Padrão `["Linha", "Marca", "Referência"]`; texto simples usa o plural `${label}s`, ou passe `{ label, plural }`.

## Fórmulas

O nó *i* tem pai *P*; `C` é o atual e `B` a base.

| Conta | Fórmula | Observação |
| --- | --- | --- |
| Participação no mix (atual) | `s_i = C_i / C_P` | `C_P` = soma dos filhos com leitura. |
| Participação na base | `B_i / B_P` | `B_P` = soma das bases com leitura. |
| Mudança de participação | `s_i − B_i / B_P`, em p.p. | Diferença das participações **exibidas**: soma zero no nível. |
| Variação do item | `Δ_i = C_i − B_i`; `Δ%_i = Δ_i / B_i` | `B_i = 0` → **novo**, sem percentual. |
| Contribuição para o pai | `c_i = Δ_i / B_P`, em p.p. | A soma dos `c_i` é `Δ%_P`: "+2,1 p.p. dos +8,4%". `B_P = 0` → "sem base". |

Casos especiais:

- **Saiu do mix**: `C_i = 0` com `B_i > 0`. Participação 0%, variação −100%, contribuição negativa.
- **Sem leitura** (`null`): nunca vira zero. Sem leitura do atual, o item fica fora das participações; sem leitura da base, fica fora da variação e da contribuição.
- **Universo comparável**: com itens sem leitura, a variação e a contribuição do nível usam só os filhos com atual e base. Assim a soma das contribuições continua igual ao `Δ%_P` e o Δ% não incha. A nota do nível e a conciliação dizem quantos ficaram fora ("comparável: 3 de 5").
- **Variação zero**: `Δ_i = 0` → `0,0%` e `0,0 p.p.`, com seta neutra.

### Arredondamento declarado

Percentuais e p.p. com `decimals` casas (padrão 1), pelo **método do maior resto** (Hamilton):

1. as contas são feitas na unidade do dado e divididas uma vez só (`Δ × 1000 / B`, sem fração intermediária);
2. cada valor vai para o piso; as unidades que faltam vão para os maiores restos;
3. empate no resto (restos que diferem menos de 10⁻⁹ contam como iguais: é ruído de ponto flutuante): maior valor primeiro, depois a ordem dos dados;
4. o meio arredonda para longe do zero, como o Intl.

Resultado: as participações exibidas somam **exatamente 100,0%** e as contribuições exibidas somam **exatamente o Δ% exibido** do nível. Um zero arredondado de um valor não nulo mantém o sinal ("+0,0 p.p."), para a direção não sumir.

### Conciliação em todo nível

- A soma dos filhos é igual ao pai, **ao centavo** (inteiros; com decimais, tolerância de ruído de ponto flutuante). Se não for, uma nota diz a diferença e as participações usam a soma dos filhos.
- As participações somam 100,0%; as contribuições somam o `Δ%` do pai.
- O rodapé mostra a conta: "12 referências somam R$ 262.400 (igual a Bruma) · participações 100,0% · contribuições +10,3 p.p. = +10,3%".

### Exemplo de conta (dados fictícios do catálogo)

Outubro 2026 vs outubro 2025, todos os canais. Total: base R$ 2.400.000, atual R$ 2.601.600 → `Δ` = +R$ 201.600 → `Δ%` = **+8,4%**.

| Linha | Base | Atual | Δ% | Participação (base → atual) | Contribuição |
| --- | ---: | ---: | ---: | ---: | ---: |
| Casa | 760.000 | 810.400 | +6,6% | 31,7% → 31,2% (−0,5 p.p.) | **+2,1 p.p.** |
| Mesa | 520.000 | 590.200 | +13,5% | 21,7% → 22,7% (+1,0 p.p.) | +2,9 p.p. |
| Banho | 410.000 | 398.100 | −2,9% | 17,1% → 15,3% (−1,8 p.p.) | −0,5 p.p. |
| Jardim | 300.000 | 351.000 | +17,0% | 12,5% → 13,5% (+1,0 p.p.) | +2,1 p.p. |
| Pet | 250.000 | 281.500 | +12,6% | 10,4% → 10,8% (+0,4 p.p.) | +1,3 p.p. |
| Papelaria | 160.000 | 170.400 | +6,5% | 6,6% → 6,5% (−0,1 p.p.) | +0,5 p.p. |
| **Soma** | 2.400.000 | 2.601.600 | +8,4% | 100,0% → 100,0% (0,0 p.p.) | **+8,4 p.p.** |

- Casa: `c` = 50.400 / 2.400.000 = **+2,1 p.p. dos +8,4%**. Mesmo contribuindo para a alta, a Casa **perde participação** (−0,5 p.p.), porque cresce 6,6%, menos que o total. É a diferença entre participação e contribuição.
- Maior resto nas participações do atual: exatas 31,150, 22,686, 15,302, 13,492, 10,820 e 6,550. Os pisos somam 99,7; os três décimos que faltam vão para os maiores restos (Jardim 0,92, Mesa 0,86 e Casa 0,501); a Papelaria, com 0,498, fica no piso. A soma exibida é 100,0%.
- Maior resto nas contribuições: exatas +2,100, +2,925, −0,496, +2,125, +1,313 e +0,433. Os pisos somam 8,3; o décimo que falta vai para o maior resto (Papelaria, 0,33), que fica com +0,5. A soma exibida é +8,4.

## Interação

1. **Cabeçalho do nível**: nome do nó, valor atual e pílula de Δ%, mini-blocos com base, variação em R$ e, fora da raiz, a participação e a contribuição no nível acima ("+2,1 p.p. dos +8,4%"). São os mesmos números da linha clicada no nível anterior.
2. **Contexto** (`context`): sempre visível abaixo do título, com período, comparação, métrica e universo.
3. **Caminho**: "Todas as linhas › Linha Casa › Marca Bruma". Cada passo anterior é um botão que volta ao nível; o atual tem `aria-current="location"`. "Voltar" e **Esc** sobem um nível.
4. **Filtros** (`filters`, em `PillSelect`): preservados ao detalhar e ao voltar. Se o nó atual some com o filtro novo, o explorador volta ao ancestral mais próximo que existe e avisa ("Marca Seriema não tem dados em Canal: Loja física. O explorador voltou para Linha Jardim."), chamando `onPathChange` com `reason: "fallback"`.
5. **Ordenação em pílula**: Participação (maior primeiro), Contribuição (maior em módulo, para cima ou para baixo) ou Variação (novos primeiro, depois maior Δ% em módulo). Sem leitura por último; o critério fica escrito abaixo.
6. **Linha**: rótulo (e situação: Novo, Saiu do mix, Sem base, Sem leitura); barra de participação de 0 a 100% com o % e a mudança em p.p.; barra divergente de contribuição com sinal, seta e p.p. em texto (nunca só cor); valor atual e Δ%.
   - Linha com filhos: clique ou Enter detalha o nível.
   - Item sem filhos (o último nível): abre o `DetailPanel` com atual, base, variação, participação e contribuição.
7. **Cauda longa**: os `tailAfter` primeiros (padrão 8) e "Demais (k)", que soma os outros e abre por baixo. A conciliação vale com a cauda fechada ou aberta.

### Estado controlado (para a URL)

| Prop | Tipo | Uso |
| --- | --- | --- |
| `path` / `defaultPath` / `onPathChange` | `string[]` | Ids a partir dos filhos da raiz. Termina num item sem filhos → detalhe aberto. `onPathChange(next, { reason })` com `drill`, `up`, `detail` ou `fallback` (`missing` traz os ids que sumiram). |
| `filterValues` / `defaultFilterValues` / `onFiltersChange` | `Record<string, string>` | Valores dos filtros; a navegação nunca os muda. |
| `sort` / `defaultSort` / `onSortChange` | `"share" \| "contribution" \| "variation"` | Ordem da lista. |

No catálogo, a história Padrão guarda caminho, filtros e ordem nos args da história, que vão para a URL: `?path=/story/widgets-mixexplorer--padrao&args=linha:casa;marca:bruma` abre já na Marca Bruma.

## Estados

`loading` (esqueleto com a geometria do pronto), `empty` (sem itens no recorte), `error` (com "Tentar novamente" via `onRetry`), `restricted`, `partial` (itens sem leitura: nota no nível e universo comparável), `stale` (pílula "Desatualizado" no rodapé, com a fonte) e sem leitura (`null`, "—" e "Sem leitura"). Os filtros ficam visíveis em todos os estados, para um recorte vazio ou com erro poder ser trocado.

## Acessibilidade

- Lista de botões: o nome acessível usa o texto visível da linha, começando pelo rótulo. Uma descrição associada (`aria-describedby`) explica as contas em frases curtas ("Casa: participação 31,2%, −0,5 pontos percentuais sobre a base; contribuição +2,1 pontos percentuais; Venda líquida R$ 810.400, alta 6,6%. ver marcas"), sem substituir o nome visível.
- Caminho em `nav` com lista ordenada; passo atual com `aria-current`.
- Depois de detalhar, o foco vai ao título do nível (`tabIndex=-1`); ao subir, volta à linha de onde se veio (a cauda abre se ela estiver lá). O nível novo é anunciado numa região `role="status"` ("Marca Bruma: 12 referências. Venda líquida R$ 262.400, alta 10,3%."); recuo, erro e vazio também.
- Teclado completo: Tab entre filtros, caminho, ordenação e linhas; Enter/Espaço detalham; Esc sobe; setas na ordenação; o detalhe prende o foco e devolve à linha.
- Sinal, seta e texto em toda variação e contribuição; contraste mínimo de 4,5:1 nos textos, no claro e no escuro (axe nos testes).
- `prefers-reduced-motion`: sem transição nas barras, no chevron e nas linhas.
- Em container estreito (< 40rem, inclusive 360 px), cada linha vira um card com o rótulo de cada número à vista.

## Limites

- Valores negativos (devoluções) entram nas contas, mas as barras não desenham abaixo de zero.
- O widget não busca dados nem guarda a URL sozinho: a página faz as duas coisas pelas props controladas.
- Nomes, cores e textos vêm de props, tokens e `messages` (pt-BR e en-US); nenhuma regra de cliente entra no componente.
