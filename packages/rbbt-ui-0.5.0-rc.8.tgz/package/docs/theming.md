# Temas, identidade e densidade

Os widgets leem apenas tokens semânticos `--rb-*`. Trocar modo, identidade ou densidade não exige editar componentes.

## Modo

```tsx
import { RbTheme } from "@rbbt/ui";

<RbTheme mode="light">…</RbTheme>  // padrão desde a 0.3.0
<RbTheme mode="dark">…</RbTheme>   // derivado: mesmos componentes, outros tokens
```

Sem `RbTheme`, valem os valores do modo claro declarados em `:root` (até a 0.2, o escuro). Também dá para usar o atributo direto: `<div data-rb-theme="light">`. Escopos podem ser aninhados.

## Identidade por tokens

Uma identidade é um conjunto parcial de tokens. O que não for informado herda do modo ativo.

```tsx
import { RbTheme, type RbThemeTokens } from "@rbbt/ui";

const marca: RbThemeTokens = {
  accent: "#8f9bff",
  accentSoft: "rgb(143 155 255 / 0.14)",
  accentBorder: "rgb(143 155 255 / 0.32)",
  surface: "#131529",
  canvas: "#0c0d1b",
  glow: "rgb(124 108 255 / 0.16)",
  sparkStroke: "#a48bff",
  radiusCard: "18px",
};

<RbTheme mode="dark" tokens={marca}>…</RbTheme>;
```

Equivalente em CSS, sem React:

```css
.minha-marca {
  --rb-accent: #8f9bff;
  --rb-surface: #131529;
  --rb-radius-card: 18px;
}
```

## Tokens

| Grupo | Tokens |
| --- | --- |
| Superfícies | `canvas`, `surface`, `surfaceRaised`, `surfaceSunken`, `border`, `borderStrong`, `sheen`, `glow` |
| Texto | `fg`, `fgMuted`, `fgSubtle`, `onAccent` |
| Marca | `accent`, `accentSoft`, `accentBorder`, `focus`, `sparkStroke`, `sparkFill` |
| Seleção e barras (0.3) | `selected`, `onSelected` (aba ativa, filtro escolhido, ação principal), `highlight` (a barra em destaque), `bar`, `barMuted` |
| Semântica | `positive`, `positiveSoft`, `negative`, `negativeSoft`, `warning`, `warningSoft`, `neutral`, `neutralSoft`, `info`, `infoSoft` (0.2) |
| Estados | `skeleton`, `skeletonHighlight` |
| Gráficos (0.2) | `seriesActual`, `seriesTarget`, `seriesForecast`, `seriesReference`, `chartGrid`, `chartAxis`, `chartBand`, `chartCursor` |
| Tabelas (0.2) | `rowHighlight`, `rowGroup` |
| Arte do StatCard (0.3.0-rc.2) | `artFrom`, `artTo` (gradiente), `onArt`, `onArtMuted` (texto sobre a arte, pelo menos 4,5:1) |
| Forma e profundidade | `radiusCard` (20 px), `radiusControl` (12 px), `radiusChip` (pílula), `shadowCard`, `shadowPopover`, `shadowHover` (0.3) |
| Tipografia | `fontSans`, `fontDisplay`, `fontNumeric`, `fontMono`, `fontTabular` (0.2), `displayWeight` (0.2), `panelTitleSize` (0.2), `numberWeight`, `textLabel` (12 px), `textBody` (13 px) (0.3) |
| Densidade e movimento | `spaceUnit`, `durationFast`, `durationBase`, `durationSlow`, `easeOut` |

Cada papel de série tem cor **e** traço próprios (realizado contínuo, meta tracejada, previsão pontilhada); os tokens só mudam a cor. O ECharts não lê `var()`: o gráfico resolve os tokens no próprio container e redesenha quando um escopo de tema acima muda (`data-rb-theme`, `style`, `class`).

A lista tipada está em `tokenVariables` (nome → propriedade CSS).

Cuidados ao criar identidade: mantenha contraste de texto ≥ 4,5:1 sobre `surface`; não reutilize a cor de `positive`/`negative` como `accent` se isso confundir a leitura de variações.

## Densidade

`<RbTheme density="compact">` reduz o espaçamento base (`--rb-space-unit` de 0,25 rem para 0,2 rem).

## Fontes

Desde a 0.3, uma família só por token: `fontSans` é Plus Jakarta Sans (OFL, 5.3.0), e `fontDisplay`, `fontNumeric` e `fontTabular` apontam para ela. Os algarismos tabulares dela têm zero limpo, então tabelas e eixos usam a mesma família do texto. A fonte vem autohospedada em `@rbbt/ui/fonts.css`, junto com Mona Sans e Hubot Sans (a família da 0.2), que continuam disponíveis para identidades. Uma página pode trocar a família pelos tokens e não importar o arquivo de fontes; sem fonte carregada, a do sistema assume.

Piso tipográfico: rótulos usam `textLabel` (12 px) e texto corrido `textBody` (13 px). A camada CSS `rb-floor`, depois dos utilitários, aplica o piso também aos rótulos e notas dos widgets. `numberWeight` deixa os números grandes leves (500 no claro, 400 no escuro), e `Figure` apaga moeda, decimais e unidade. `displayWeight` ajusta o peso dos títulos de painel.

## Movimento

`durationFast` 160 ms, `durationBase` 240 ms e `durationSlow` 320 ms (entrada do painel de detalhe), com `easeOut`. Com `prefers-reduced-motion: reduce`, as durações vão a zero e o card não se desloca no hover.
