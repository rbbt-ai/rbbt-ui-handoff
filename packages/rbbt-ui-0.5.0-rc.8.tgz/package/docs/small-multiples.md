# Pequenos múltiplos · contrato (0.5.0-rc.6, Lote 3)

Uma minicurva por loja (ou por item configurável), numa grade de painéis de altura igual. Cada painel mostra
o nome numa linha, **um número** (o último valor com leitura), a variação em texto e a curva do período.
DOM e SVG próprios, sem biblioteca de gráfico. Cliente das histórias: Pedravela Calçados (fictício).

## Props

| Prop | Tipo | Padrão | Uso |
| --- | --- | --- | --- |
| `title` | `string` | — | Título visível; nomeia a região e a lista. |
| `data` | `SmallMultiplesData \| null` | — | Itens e séries. `null` ou sem leitura → vazio. |
| `scale` | `"shared" \| "own"` | `"shared"` | Escala de y. `own` aparece declarada na tela. |
| `decline` | `{ threshold?, window? } \| (resumo) => boolean` | `{ threshold: -0.05 }` | Regra de queda. |
| `sort` | `"input" \| "decline-first"` | `"input"` | Quedas primeiro (da maior para a menor). |
| `metricLabel` | `string` | `"Receita"` | Nome da métrica (tabela). |
| `valueFormat` | `ValueFormat` | BRL sem centavos | Painel em notação compacta; balão e tabela por extenso. |
| `period`, `scope` | `string` | — | Contexto visível no topo ("1–30 de out. 2026 · 12 lojas"). |
| `source` | `string` | — | Origem, sempre no rodapé. |
| `view`, `defaultView`, `onViewChange` | `"chart" \| "table"` | `"chart"` | Gráfico ou tabela alternativa. |
| `status`, `partialNote`, `onRetry` | — | `"ready"` | Carregando, vazio, parcial, erro (moldura comum). |
| `messages` | `Partial<SmallMultiplesMessages>` | pt-BR | Qualquer texto sobrescrevível. |

## Dados

```ts
interface SmallMultiplesData { items: SmallMultiplesItem[] }
interface SmallMultiplesItem { id: string; label: string; points: SmallMultiplesPoint[] }
interface SmallMultiplesPoint { day: IsoDay; value: number | null }
```

- O eixo x é comum: a união dos dias de todos os itens, em ordem.
- `null`, `NaN`, valor não finito **ou dia que falta** num item = ausência. A curva **quebra** nesse dia
  (trechos separados); a ausência nunca vira zero e não puxa o domínio para baixo. Zero é leitura.
- Ponto isolado entre duas faltas aparece como um ponto, não como traço.

## Adaptador

`smallMultiplesFromRecords(records, mapping)` lê linhas de uma view de Bases ou de um cenário
(`createScenarioReader(...).rows("vendas")`), compatível com `adapters/series.ts` (`readPath`, `toMetricValue`):

```ts
smallMultiplesFromRecords(rows, { item: "loja", itemLabel: "nome", day: "dia", value: "receita" });
// { loja: "centro", nome: "Centro", dia: "2026-10-01", receita: "1.234,5" } → ponto 1234,5
```

- Campos aceitam caminho com pontos (`"metricas.receita"`).
- `""`, `null` e texto inválido → `null` (ausência). Linha sem dia ISO válido ou sem item é ignorada.
- Linhas repetidas do mesmo item e dia somam; se alguma não tem leitura, o dia inteiro fica sem dado.

## Regra de queda

- Variação = média dos dias com leitura do **período atual** (últimos `window` dias; padrão: metade dos dias)
  contra a média do período anterior de mesmo tamanho. Sem leitura num dos períodos → sem base, não é queda.
- Queda: variação abaixo de `threshold` (padrão −5%). Ou uma função própria sobre o resumo
  (`{ id, label, variation, current, previous, last }`).
- Destaque **nunca só cor**: selo "em queda" com ícone e texto, curva no token `--rb-sm-decline`,
  resumo "3 lojas em queda" no topo e a regra escrita no rodapé ("Em queda: variação abaixo de −5%").
- `sort="decline-first"` põe as quedas primeiro e declara "Quedas primeiro".

## Escala

- `shared` (padrão): o mesmo domínio de y em todos os painéis (extensão de todas as leituras, com 6% de folga),
  para a leitura entre lojas ser honesta. Declarada: "Escala comum a todas as lojas".
- `own`: domínio de cada painel. Declarada em destaque: "Escala própria por loja: compare a forma, não o nível".

## Estados

Carregando (esqueleto de painéis), vazio, parcial (nota da moldura), erro (com tentar de novo), restrito e
desatualizado pela moldura comum. Contexto visível: período e lojas no topo, origem no rodapé.

## Acessibilidade e teclado

- Cada painel é focável e está na ordem de Tab; nome acessível com último valor, dia, variação, tendência,
  queda e dias sem dado.
- Foco pelo teclado abre o balão no último dia com leitura; ←/→ percorrem os dias, Home/End vão ao primeiro e
  ao último; Esc fecha o balão (o foco fica). Dia sem dado aparece como "sem dado" no balão.
- Região viva (educada) anuncia o ponto ativo. Tabela alternativa: loja, último valor, variação e tendência.
- Movimento reduzido: sem desenho nem transição; o painel ativo ganha contorno.

## Balão

Um balão por grade, posicionado por `placeTip` (`widgets/place-tip.ts`): âncora no ponto ativo, nunca cobre
texto da grade (nomes, valores, variações, selos) nem o ponto; evita as curvas quando possível; sem lugar,
entra o compacto (só dia e valor). Fica dentro do quadro também a 360 px.

## Movimento

Entrada: as curvas se desenham em cascata (máx. 12 passos). Troca de dados: valores e domínio vão do antigo ao
novo, sem cascata e sem passar por zero. Hover discreto: só o fundo do painel muda.

## Tokens

`--rb-sm-line`, `--rb-sm-decline`, `--rb-sm-decline-soft`, `--rb-sm-card`, `--rb-sm-card-hover`, `--rb-sm-guide`,
por tema (Smooth/Glass, claro/escuro) e sobre o tema de cliente (`--rb-accent`).
