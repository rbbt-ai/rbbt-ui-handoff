# TrendIndicator — contrato

Versão do pacote: `@rbbt/ui@0.2.0-rc.2` · estado: **candidato para revisão visual** (não aprovado). O contrato do 0.1.0-rc.1 continua válido; as adições estão marcadas com (0.2) e (rc.2). Sem `anatomy` e fora de um `PageContextProvider`, o card é o mesmo do 0.2.0-rc.1.

Indicador com tendência: mostra o valor de um período, a comparação com uma referência (com semântica declarada), uma micro-tendência, a fonte e a atualização. Não faz rede, não conhece cliente e não contém regra de negócio: tudo chega por props.

```tsx
import "@rbbt/ui/styles.css";
import { TrendIndicator } from "@rbbt/ui";
import { BadgeDollarSign } from "lucide-react";

<TrendIndicator
  label="Receita líquida"
  period="Outubro 2026"
  icon={<BadgeDollarSign />}
  data={{ value: 1284600, previousValue: 1142900, series: [968000, 1012500, 1142900, 1284600] }}
  format={{ style: "currency", currency: "BRL" }}
  locale="pt-BR"
  comparison={{ label: "set/2026", mode: "percent", polarity: "higher-is-better" }}
  source="ERP"
  updatedAt="2026-10-18T14:54:00-03:00"
  staleAfterMs={2 * 60 * 60 * 1000}
  action={{ label: "Detalhes", onAction: () => abrirDetalhe() }}
  onRetry={() => recarregar()}
/>;
```

## Dados de entrada (`data`)

| Campo | Tipo | Significado |
| --- | --- | --- |
| `value` | `number \| null` | Valor do período. `0` é zero; `null` é **ausência**; `NaN`/`Infinity` são **inválidos**. |
| `previousValue` | `number \| null` (opcional) | Referência da comparação. Omitido sem `comparison` = sem comparação; `null` com `comparison` = "Sem valor de comparação". |
| `series` | `Array<number \| null \| { at?, value }>` (opcional) | Série cronológica da micro-tendência. `null` abre lacuna. Precisa de 2+ pontos válidos para desenhar. |

`data` ausente com `status="ready"` é tratado como vazio. Os adaptadores (`summarizeSeries`, `indicatorDataFromRecord`, `toMetricValue`) convertem séries e linhas de Bases/APIs para este formato fora do widget.

## Opções

| Prop | Padrão | Descrição |
| --- | --- | --- |
| `label` | — (obrigatória) | Nome da métrica; também nomeia a região para leitores de tela. Até 2 linhas, depois reticências. |
| `status` | `"ready"` | `ready`, `loading`, `empty`, `error`, `stale`, `restricted` (0.2) ou `partial` (0.2). |
| `partialNote` (0.2) | — | Nota de dados parciais; aparece como aviso âmbar sempre que houver valor. Presente → estado parcial. |
| `restrictedMessage` (0.2) | texto padrão | Explicação do estado sem permissão. |
| `caveat` (0.2) | — | Ressalva que muda a interpretação, sempre visível (nunca só no botão de informação). |
| `secondaryValue` (0.2) | — | `{ value, format?, label?, signed?, polarity? }`: valor complementar formatado pelo widget, ex.: diferença em R$ ao lado de um atingimento em %. |
| `valueAsChange` (0.2) | — | `{ polarity?, flatThreshold? }`: o valor principal já é uma variação (ex.: +3,2%); seta, cor e texto ("Alta · favorável") vêm do sinal. |
| `format` | `{ style: "number" }` | `number` (com `prefix`/`suffix`), `currency` (`currency` ISO 4217), `percent` (valor em fração: 0.124 = 12,4%) ou `unit` (unidade Intl, ex.: `millisecond`). `notation`: `auto` (padrão; compacta a partir de 1.000.000), `standard` ou `compact`. Casas decimais configuráveis; regra da notação compacta abaixo (0.5.0-rc.2). |
| `locale` | `"pt-BR"` | BCP 47. Formata números/datas com `Intl` e escolhe os textos (pt → português, demais → inglês). |
| `timeZone` | do navegador | Fuso das datas absolutas. |
| `period` | — | Texto do período, abaixo do rótulo. |
| `comparison` | — | `{ label, mode?, polarity?, flatThreshold? }`. Ver semântica abaixo. |
| `icon` | — | Ícone decorativo (ex.: Lucide). |
| `description` | — | Definição da métrica, aberta por botão de informação (clique, toque ou teclado; nunca só hover). |
| `source` | — | Origem dos dados, exibida no rodapé. |
| `updatedAt` | — | Data da última atualização (Date, ISO ou epoch ms). |
| `staleAfterMs` | — | Idade máxima; acima dela, `ready` vira desatualizado automaticamente. |
| `now` | relógio local, a cada 30 s | Relógio de referência para testes, SSR e snapshots. |
| `messages` | pt-BR ou en-US | Sobrescreve qualquer texto da interface. |
| `showSparkline` | `true` se houver série | Esconde a micro-tendência quando `false`. |
| `headingLevel` | `3` | Nível do título (`h2`–`h6`) para encaixar na hierarquia da página. |
| `anatomy` (rc.2) | a do `PageContextProvider`, senão `"full"` | `"lean"`: anatomia enxuta (abaixo). `"full"`: desenho do 0.2.0-rc.1. |
| `marker` (rc.2) | — | `{ label, value?, tone?, icon?, detail? }`: ressalva curta de uma linha, ex.: `{ label: "Parcial", value: "21/22 lojas" }`. Use só quando a ressalva muda a leitura do número. |
| `methodology` (rc.2) | — | Conteúdo estruturado de "Como calculamos" (`source`, `updated`, `period`, `scope`, `coverage`, `formula`, `exclusions`, `limitations`, `validation`, `extra`). Fonte e atualização entram sozinhas se faltarem. |
| `provenance` (rc.2) | `"inherit"` | Dentro de um `PageContextProvider`: `inherit` não repete período, fonte e atualização iguais aos da página; `always` mostra sempre. |
| `valueAsChange.label` (rc.2) | — | Referência da variação sem o "vs.", ex.: `"01–17/09"` → linha "vs. 01–17/09 · favorável". |
| `className`, `id` | — | Repassados ao elemento raiz (`section`). |

## Anatomia enxuta (rc.2)

> **Desde a 0.4.0-rc.1, `lean` usa o desenho smooth**, com as mesmas props e as novas `featured` e `iconTone`. O card tem topo com título e círculo de ícone, número com a pílula de variação colada e a linha "Rótulo: valor". Ressalvas aparecem em pílula, e fonte e atualização ficam fora do card. Elas só voltam quando diferem das da página. Contrato em [smooth.md](smooth.md). O texto abaixo descreve a regra de conteúdo, que continua valendo, e o desenho da 0.2/0.3.

Com `anatomy="lean"` (direto ou herdado do `PageContextProvider`), o card mostra só quatro coisas:

1. **nome**, com o período apenas quando diferir do período da página;
2. **número**;
3. **uma linha de comparação**: selo com seta, sinal e texto, mais a referência (ex.: "−R$ 196.448 · vs. meta até 15/10"). A prioridade é comparação > valor-variação > valor complementar;
4. **mini-gráfico**, quando houver série.

**Valor complementar no card lean (0.5.0-rc.2).** Com linha de comparação, o `secondaryValue` ganha a segunda linha de apoio do card, logo abaixo dela, como no card completo: "**+R$ 165.915** vs. comparável". O número leva o juízo (`polarity`) só na cor; sinal e rótulo dizem o mesmo sem cor. No card em destaque, fica branco. Ele não vai mais para "Como calculamos". Sem comparação, o valor complementar continua sendo a linha de comparação (selo, quando tem sinal ou juízo).

**Notação compacta (0.5.0-rc.2, vale para todo o pacote).** As casas de `format` valem para a notação padrão. Na compacta automática (`notation: "auto"`, a partir de `compactFrom`) e na compacta que um widget força (eixo, rótulo de gráfico), o padrão é **até 2 casas, sem zeros à direita**: um formato `{ style: "currency", currency: "BRL", maximumFractionDigits: 0 }` mostra R$ 3.323.187 na padrão e R$ 3,32 mi na compacta, nunca "R$ 3 mi". Com `notation: "compact"` explícito, as casas do formato valem. `compactMinimumFractionDigits` e `compactMaximumFractionDigits` fixam as casas só da compacta.

**Valores comparados no mesmo bloco** (valor × comparável no indicador; realizado × meta no resumo do gráfico; células de uma coluna da tabela; colunas e barras de um gráfico) passam por `distinctCompactFormat(valores, formato, locale)`: se dois valores diferentes caem no mesmo texto compacto, as casas sobem até se distinguirem, **no máximo 2**; na mesma escala, todos saem com as mesmas casas (R$ 3,10 mi ao lado de R$ 3,32 mi). Valores iguais, ausentes e em notação padrão não mudam. Num bloco montado pela página (ex.: dois `CountUp`), chame `distinctCompactFormat` e passe o resultado a todos os valores do bloco. O texto por extenso, para leitor de tela, continua na notação padrão.

Ressalvas viram um **marcador** de uma linha (ícone e palavra, sem caixa colorida). Sem `marker`, o estado parcial gera "Parcial" automaticamente. O marcador e o botão de informação abrem o mesmo painel **"Como calculamos"** (clique, toque ou teclado; nunca só hover), com o detalhe do marcador, a nota de parcial, a ressalva (`caveat`), o valor complementar que não coube, a definição e a metodologia.

Fonte e atualização saem do rodapé quando iguais às da página e vão para "Como calculamos"; ficam no card quando diferem (ex.: posição de estoque datada). "Desatualizado" continua no card mesmo herdado, porque muda a leitura. No máximo uma ação por card: com dados desatualizados, "Atualizar" ocupa o lugar da ação.

```tsx
<PageContextProvider period="Outubro 2026, até 17/10" source="ERP" updatedAt={atualizadoEm} staleAfterMs={26 * 3600_000} anatomy="lean">
  <TrendIndicator
    label="Venda líquida"
    period="Outubro 2026, até 17/10" // igual ao da página: não se repete
    data={{ value: 6627346, series }}
    format={{ style: "currency", currency: "BRL" }}
    status="partial"
    partialNote="Loja 13 sem dados em 16–17/10."
    marker={{ label: "Parcial", value: "21/22 lojas" }}
    methodology={{ formula: "Vendas − devoluções − cancelamentos." }}
  />
</PageContextProvider>
```

## Ações e callbacks

| Prop | Quando aparece | Contrato |
| --- | --- | --- |
| `action` | Rodapé, à direita | `{ label, onAction?, href?, target?, disabledReason? }`. Com `href`, vira link. Com `disabledReason`, fica indisponível e o motivo aparece no lugar do texto (ex.: "Sem permissão para detalhar"). A interface não é controle de acesso: o backend continua validando. |
| `onRetry` | Erro ("Tentar novamente") e desatualizado ("Atualizar") | Chamado sem argumentos. Quem consome decide como recarregar e passa `status="loading"` enquanto isso. |

## Estados

| Estado | Como aparece |
| --- | --- |
| `ready` | Valor, variação, comparação, micro-tendência, fonte e atualização. |
| `loading` | Esqueleto com a mesma geometria do pronto (sem salto de layout); `aria-busy`. Brilho desligado com redução de movimento. |
| `empty` | Traço longo e mensagem "Sem dados no período" (sobrescrevível por `emptyMessage`). |
| `error` | Ícone, título, `errorMessage` e "Tentar novamente" se houver `onRetry`. Os dados anteriores não são exibidos para evitar leitura errada. Borda em tom negativo. |
| `stale` | Dados visíveis, borda e selo âmbar "Desatualizado · há X", e "Atualizar" se houver `onRetry`. Automático com `staleAfterMs`. |
| `restricted` (0.2) | Traço longo, cadeado e "Sem permissão para ver este indicador"; nenhum valor nem ação aparece. A restrição real é do servidor. |
| `partial` (0.2) | Dados visíveis, borda âmbar suave e nota "Parcial." com `partialNote`. |

Dentro de `ready`, o widget ainda distingue: **zero** (`R$ 0`), **ausência** (`—` + "Sem valor no período"), **negativo** (sinal tipográfico `−`) e **inválido** (`—` + selo "Valor inválido recebido").

## Semântica da comparação

- `polarity`: `higher-is-better` (padrão), `lower-is-better` (ex.: cancelamentos, latência, custo) ou `neutral` (sem juízo de valor). Define se a variação é **favorável** ou **desfavorável**; a direção (seta) é sempre a do número.
- `mode`:
  - `percent` (padrão): (atual − anterior) / |anterior|. Com anterior negativo, o sinal segue a direção real.
  - `points`: diferença em pontos percentuais, para taxas (`format.style = "percent"`). Ex.: 3,41% → 3,82% = `+0,4 p.p.`.
  - `absolute`: diferença na unidade do valor (ex.: `+0,25 s`).
- **Base zero**: anterior = 0 em `percent` não tem variação relativa. O widget mostra a diferença absoluta e "sem base de comparação (anterior = 0)" em vez de `+∞%`. Atual e anterior iguais a zero = estável.
- `flatThreshold`: faixa considerada estável, na unidade do `mode` (fração em `percent` e `points`; unidade do valor em `absolute`).
- A variação não depende só de cor: seta, sinal e o qualificador textual ("favorável", "desfavorável", "estável") aparecem juntos.

## Limites de tamanho

- Largura: mínimo **160 px**; recomendado **220 px ou mais**. O layout responde ao **container** (container queries), não à viewport:
  - abaixo de 400 px: valor em cima e micro-tendência embaixo, em largura total;
  - a partir de 400 px: micro-tendência à direita do valor;
  - a partir de 320 px: respiro interno maior.
- O tamanho do número acompanha a largura do card (22–44 px).
- Altura: definida pelo conteúdo (≈ 170–230 px). O card ocupa 100% da altura da célula do grid; o rodapé fica ancorado embaixo.
- Rótulo até 2 linhas; período, fonte e textos longos são truncados sem quebrar o layout.

## Acessibilidade

- Raiz `section` nomeada pelo título; frase completa para leitores de tela com valor por extenso, variação, referência e qualificador.
- Micro-tendência com alternativa textual (pontos, início, fim, mínimo, máximo e intervalo de datas).
- Mudanças de estado anunciadas com `aria-live="polite"`.
- Foco visível em todas as ações; área de toque ampliada para 44 px em ponteiros grossos.
- `prefers-reduced-motion`: sem brilho no esqueleto, sem desenho animado da linha e sem deslocamento na troca de valores.
- Contraste dos textos verificado nos temas escuro e claro (ver relatório de testes).

## Dependências

`react` e `react-dom` 19 (peer), `react-aria-components` 1.22.1, `motion` 14.3.0, `lucide-react` 1.59.0. CSS próprio em `@rbbt/ui/styles.css` (Tailwind v4 compilado, prefixo `rb:`, sem preflight global). Fontes opcionais em `@rbbt/ui/fonts.css` (OFL).
