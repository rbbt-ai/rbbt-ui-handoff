# PriorityList — contrato

Versão do pacote: `@rbbt/ui@0.2.0-rc.2` · estado: **candidato para revisão visual** (não aprovado). Adições do rc.2 marcadas com (rc.2); sem elas, a lista é a do 0.2.0-rc.1.

Lista curta de prioridades de atenção. Cada item segue **problema → evidência → hipótese → próximo passo**, com o **critério de ordenação sempre visível** e o **estágio em texto** (sugestão ≠ aprovação ≠ execução). O widget não executa nada: no máximo navega para um detalhe.

```tsx
import { PriorityList } from "@rbbt/ui";

<PriorityList
  title="Prioridades de atenção"
  criterion="pendências de dados primeiro; depois, maior diferença negativa para a meta (R$)"
  items={[
    {
      id: "p1",
      subject: "Unidade Porto",
      kind: { label: "Venda", tone: "negative" },
      problem: "9,3% abaixo da meta acumulada",
      impact: { value: -29559.9, format: { style: "currency", currency: "BRL" }, label: "diferença para a meta" },
      evidence: ["Venda R$ 288.940 contra meta de R$ 318.500 até 16/10", "Ticket médio estável (−0,8%)"],
      hypothesis: "Menos atendimentos, não preço.",
      nextStep: "Comparar fluxo e disponibilidade com a Unidade Centro.",
      action: { label: "Ver unidade", href: "/unidades/porto" },
    },
  ]}
/>;
```

## Dados de entrada (`items`)

| Campo | Significado |
| --- | --- |
| `id`, `problem` | Identificador e problema observado, curto, em linguagem de gestão. |
| `subject`, `kind` | Onde (unidade, produto) e tipo (`{ label, tone }`, ex.: "Dados", "Venda", "Estoque"). |
| `evidence[]` | Fatos observados (números já formatados pelo consumidor). |
| `hypothesis` | Explicação **a verificar**; nunca apresentada como causa. |
| `nextStep` | Próximo passo **sugerido**. |
| `stage` | `suggestion` (padrão), `approved`, `in-progress`, `done`, `dismissed`. Só muda quando a fonte registrar. |
| `impact` | `{ value, format, label?, signed?, tone? }` formatado pelo widget; negativo é desfavorável por padrão. |
| `rankReason` | Por que está nesta posição (complementa o critério). |
| `action` | `{ label, onAction?, href?, disabledReason? }` — navegação/detalhe. |

A ordem dos itens é a do consumidor; o critério descreve essa ordem.

## Opções

| Prop | Padrão | Descrição |
| --- | --- | --- |
| `criterion` | — (obrigatória) | Critério explícito, sempre visível acima da lista. |
| `initialCount` | `3` | Itens antes de "Mostrar todas (N)". |
| `evidenceLimit` | todas | Evidências visíveis por item; o restante abre em "Mais N evidências" (`aria-expanded`). Vale no modo `inline`. |
| `itemDetail` (rc.2) | `expandable` na anatomia enxuta, senão `inline` | `inline`: evidências e hipótese sempre visíveis (0.2.0-rc.1). `expandable`: cada item mostra problema e assunto, a **evidência principal** (a primeira), o **próximo passo** e a diferença (`impact`); as demais evidências, a hipótese e a posição na lista (`rankReason`) abrem em **"Ver evidências"** (`aria-expanded` + `aria-controls`). O selo de estágio continua visível. |
| `anatomy` (rc.2) | a do `PageContextProvider`, senão `full` | `lean`: ressalvas da moldura em linha, sem caixa, e itens expansíveis. |
| `provenance` (rc.2) | `inherit` | Dentro de um `PageContextProvider`, fonte e atualização iguais às da página saem do rodapé e entram em "Como calculamos". |
| moldura e estados | — | `status`, `scope`, `caveat`, `partialNote`, `description`, `methodology`, `source`, `updatedAt`, `staleAfterMs`, `now`, `messages`, `headingLevel`. |

## Estados

`loading`, `empty` ("Nenhuma prioridade no recorte"), `error`, `restricted`, `partial`, `stale`. Para dependência de outra etapa (ex.: ações sem persistência), use `<WidgetState kind="dependency">` num painel próprio em vez de botões que aparentem registrar.

## Limites de tamanho

Mínimo útil **300 px**. A partir de **34 rem** de container, evidência, hipótese e próximo passo ficam em três colunas (no modo `expandable`, evidência principal e próximo passo em duas); abaixo, empilham.

## Acessibilidade

`ol` com cada item nomeado por "Prioridade N: problema"; partes em `dl` com rótulos visíveis; estágio em texto + tom; foco visível nas ações; nenhuma informação só em hover.

## Dependências

`react-aria-components`, `lucide-react`.
