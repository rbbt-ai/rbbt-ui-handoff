# EvolutionChart — contrato

Versão do pacote: `@rbbt/ui@0.2.0-rc.2` · estado: **candidato para revisão visual** (não aprovado). Adições do rc.2 marcadas com (rc.2).

Evolução temporal de um período em três visões: **acumulado** (realizado × meta × previsão), **diário** (colunas do realizado, meta do dia em degraus, previsão pontilhada) e **tabela** (alternativa acessível com todos os dias). Sem rede e sem regra de negócio: o consumidor entrega os pontos já calculados.

```tsx
import { EvolutionChart } from "@rbbt/ui";

<EvolutionChart
  title="Ritmo de vendas"
  subtitle="Outubro 2026 · dados até 17/10"
  data={{
    points: [{ day: "2026-10-01", actual: 41250.3, target: 43100, forecast: 42000 }, /* … até 2026-10-31 */],
    lastActualDay: "2026-10-17",
    lastComparableDay: "2026-10-15",
    forecast: { version: "v3", method: "média de 5 semanas por dia da semana", generatedAt: "2026-10-13T07:00:00-03:00" },
  }}
  format={{ style: "currency", currency: "BRL" }}
  partialNote="16 e 17/10 sem dados de 1 unidade."
/>;
```

## Dados de entrada (`data`)

| Campo | Tipo | Significado |
| --- | --- | --- |
| `points` | `EvolutionPoint[]` | Um item por dia do período, inclusive futuros. Ordem livre (o widget ordena); dia inválido ou repetido é descartado e contado. |
| `points[].day` | `"AAAA-MM-DD"` | Dia de calendário, sem fuso (não desloca com o fuso de quem lê). |
| `points[].actual` | `number \| null` | Realizado do dia na unidade de `format` (reais, não centavos). `0` é zero; `null` é sem valor. |
| `points[].target` | `number \| null` | Meta do dia **só com distribuição**. Dia sem meta planejada = `0`. Se a distribuição for interrompida (`null`), a curva para ali. |
| `points[].forecast` | `number \| null` | Previsão do dia, usada depois de `forecast.from`. |
| `points[].status` | `complete \| partial \| missing \| inactive \| future` | Padrão: `complete` com realizado, `future` depois do corte, `missing` sem realizado antes do corte. |
| `points[].note` | `string` | Explicação curta do dia, na dica e na tabela. |
| `lastActualDay` | dia | Corte do realizado. Padrão: último dia com valor válido. Depois dele tudo é futuro. |
| `lastComparableDay` | dia | Onde realizado e meta são comparados. Padrão: último dia antes do primeiro dia parcial ou sem dados. |
| `periodTarget` | `number \| null` | Meta do período **sem distribuição**: aparece como valor, nota e linha de nível no acumulado; nunca vira curva diária. |
| `forecast` | `{ method, version, generatedAt, from?, assumptions? }` | Metadados obrigatórios para desenhar a previsão. A curva parte do realizado acumulado em `from` (padrão: última data comparável). |

### Regras de desenho

- O realizado termina no corte; dias futuros e lacunas nunca viram zero.
- `missing`: sem valor; a linha acumulada interrompe e os dias seguintes são marcados como "acumulado sem todos os dias anteriores".
- `inactive` (sem operação): sem coluna; o acumulado fica parado; faixa neutra no fundo.
- `partial`: valor desenhado com marcador vazado/hachura e faixa âmbar; entra no acumulado, mas não na comparação.
- Zero no diário recebe um traço na base (zero é valor, não ausência). Valores negativos ficam abaixo do zero.
- A diferença para a meta é destacada por um colchete na última data comparável e no resumo.
- A previsão nunca prolonga o realizado: começa na data de partida e soma a previsão de cada dia seguinte.

## Opções

| Prop | Padrão | Descrição |
| --- | --- | --- |
| `title` | — (obrigatória) | Título; nomeia a região. |
| `subtitle` | — | Período e corte em linguagem de gestão. |
| `status` | `ready` | `ready`, `loading`, `empty`, `error`, `restricted`, `partial`, `stale`. |
| `format` | `{ style: "number" }` | Mesmo `ValueFormat` do pacote; eixo em notação compacta, dica e tabela em notação padrão. |
| `locale`, `timeZone` | `pt-BR`, navegador | Intl para números e datas; textos pt/en. |
| `view` / `defaultView` / `onViewChange` | `cumulative` | Visão controlada ou inicial. |
| `views` | as três | Visões oferecidas. Mantenha `table`: é a alternativa acessível. |
| `polarity` | `higher-is-better` | Semântica da diferença para a meta. |
| `height` | 42% da largura (220–340 px) | Altura da área do gráfico. |
| `scope` | — | `<ScopeNote>` com o recorte efetivo quando o widget não segue um filtro da página. |
| `caveat` | — | Ressalva sempre visível. |
| `partialNote` | — | Nota de dados parciais (visível). |
| `description`, `methodology` | — | Definição (botão de informação) e "Como calculamos" (painel expansível). |
| `source`, `updatedAt`, `staleAfterMs`, `now` | — | Rodapé de fonte e atualização; desatualizado automático. |
| `anatomy` (rc.2) | a do `PageContextProvider`, senão `full` | `lean`: recorte efetivo, parcial e ressalva em linha, sem caixa dentro do card. |
| `provenance` (rc.2) | `inherit` | Dentro de um `PageContextProvider`, fonte e atualização iguais às da página saem do rodapé e entram em "Como calculamos". |
| `messages`, `stateMessages` | pt-BR/en-US | Sobrescrevem textos do gráfico e dos estados. |

## Ações e callbacks

`onViewChange(view)` e `onRetry()` (erro e desatualizado). O gráfico não tem ações de negócio.

## Estados

`loading` (esqueleto do resumo e do gráfico), `empty`, `error` (sem dados anteriores), `restricted` (nada aparece), `partial` (dados + nota âmbar), `stale` (dados + selo e "Atualizar"). O motor do gráfico é carregado sob demanda; até lá aparece o mesmo esqueleto.

## Limites de tamanho

- Largura mínima útil: **300 px**. Abaixo de **360 px** os rótulos diretos saem (legenda e resumo continuam); o eixo reduz rótulos conforme a largura do container.
- Números do resumo (0.5.0-rc.2): realizado, meta e previsão nunca caem no mesmo texto compacto (R$ 3,15 mi × R$ 3,32 mi, não "R$ 3 mi" duas vezes); regra da notação compacta em [trend-indicator.md](trend-indicator.md).
- Altura do gráfico: 220–340 px proporcional à largura, ou `height`.
- Tabela: rola dentro do card, com data fixa à esquerda e cabeçalho fixo.

## Acessibilidade

- Área do gráfico focável (`role="group"`): **setas** percorrem os dias, **Home/End** vão ao início/fim, **Esc** fecha a dica; cada dia é anunciado em texto.
- Resumo textual (`role="img"`) com realizado, meta, diferença e previsão; notas ligadas por `aria-describedby`.
- Traços distintos e rótulos diretos: realizado contínuo, meta tracejada, previsão pontilhada; faixas com legenda textual. Nunca só cor.
- Redução de movimento: sem animação de entrada nem de troca.

## Anotações (0.5.0-rc.6)

Eventos no tempo marcados no gráfico, pela prop **opcional** `annotations` (sem ela, o gráfico é o mesmo de antes).

| Prop | Tipo | Regra |
| --- | --- | --- |
| `annotations` | `EvolutionAnnotation[]` (= `TimeEvent` de `adapters/events.ts`) | `{ id, start, end?, type?, label, title?, description?, priority?, group? }`. Sem `end` (ou `end = start`): dia único. Com `end`: intervalo fechado, os dois dias inclusos. |
| `annotationTypes` | `TimeEventTypes` | Rótulo do tipo, mostrado no balão ao lado da data. |

- **Desenho:** dia único = linha fina tracejada; intervalo = faixa muito clara, de borda a borda dos dias. As duas marcas ficam atrás dos dados e entram e mudam junto com o gráfico (ECharts).
- **Rótulos fora dos dados:** os rótulos ficam numa faixa própria acima da área dos dados (a altura do gráfico cresce o mesmo tanto). Nunca ficam sobre a linha, os pontos ou os rótulos de valor.
- **Sem espaço:** se dois rótulos se tocam, ou se o container tem menos de 420 px, todos viram marcadores numerados (1, 2, 3…, na ordem de início, até duas linhas), e a legenda embaixo do gráfico traz número, nome e data.
- **Balão:** nome (`title`, senão `label`), data (as datas originais, mesmo quando recortado), tipo e descrição. Em gráfico de 420 px ou mais, flutua, posicionado por `placeTip` contra o texto do quadro e a geometria dos dados medida no ECharts (`convertToPixel`: pontos, segmentos, barras e rótulos de valor).
- **Gráfico estreito (< 420 px):** nada flutua sobre os dados. O detalhe (nome, data, tipo e descrição) abre em linha, logo abaixo da legenda numerada, por foco, clique ou toque no marcador ou no item da legenda; fecha com Esc ou com um segundo clique.
- **Período:** evento todo fora do eixo some; o que cruza a borda é recortado (`clipEvent`) e o balão avisa "parte fora do período". Na troca de filtro, as marcas e os rótulos vão da posição antiga à nova, sem piscar; a cascata só toca na entrada.
- **Teclado e leitor de tela:** os rótulos (ou a legenda numerada) são botões; o foco abre o balão (`aria-describedby`), Esc fecha. As setas do gráfico continuam percorrendo os dias.
- **Tabela alternativa:** com anotações, ganha a coluna "Eventos" com os rótulos dos eventos que tocam cada dia.
- **Redução de movimento:** sem entrada nem transição de rótulos.
- Exportado: só o tipo `EvolutionAnnotation`. Recorte, numeração e distribuição dos rótulos são internos.

## Dependências

`echarts` 6.1.0 (módulos de linha, barra, dispersão, grade, dica e marcações; renderizador SVG; import dinâmico), `react-aria-components`, `motion`, `lucide-react`.
