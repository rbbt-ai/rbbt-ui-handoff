# Linguagem smooth, Etapas 1 e 2 (0.4.0-rc.1)

Mais limpa, suave e amigável, com o **azul Rbbt** como destaque da biblioteca. Clara primeiro; o escuro sai dos mesmos componentes só por tokens. Estado: Etapa 1 aprovada por Thiago (26/10, 12:48); Etapa 2 em **prévia para aprovação**. Nada publicado e sem tag até o ok.

A Etapa 1 cobre a base, o indicador, as colunas e o medidor. A Etapa 2 cobre a evolução, a tabela comparável, as prioridades e a barra em destaque. As demos continuam no v3 até a Etapa 3.

Todos os componentes são genéricos. Dados, textos, locale e formatação entram por props. Não fazem chamadas de rede e não conhecem cliente. Dependências: React 19, React Aria Components, Motion e Lucide (ícones internos).

No Storybook, veja **Smooth · Etapa 1** (fileira clara, escura, estados e carregando) e **Smooth · Etapa 2** (página clara e escura).

## Base

| Peça | Como é | Tokens |
| --- | --- | --- |
| Destaque | Azul Rbbt. `#3F6DFF` é a ponta da marca nos gradientes e gráficos. O tom de texto `#3B68FA` passa de 4,5:1 no branco. Verde, âmbar e vermelho ficam só para status. | `accent`, `accentFrom`, `accentTo` |
| Card | Raio 24, padding 24, sombra suave em duas camadas e nenhuma borda. | `smoothRadius`, `smoothPadding`, `smoothShadow` |
| Número | 32–36 px, peso 600, tabular, quase preto. Decimais e "%" ficam apagados; moeda e unidade ("R$", "mi"), apagadas e menores. | `figureWeight` |
| Variação | `DeltaPill` colada ao número: seta + valor, fundo tingido pelo juízo da polaridade declarada. | `positive*`, `negative*`, `neutral*` |
| Apoio | Linha "Rótulo: **valor**" (ex.: "Mês anterior: **R$ 1,14 mi**"). | |
| Ícone | `IconCircle` de 40 px no canto superior direito: quase preto (`selected`) ou no gradiente do destaque (`accent`). | `selected`, `accentFrom`, `accentTo` |
| Destaque de seção | Card em gradiente azul, texto branco e círculo branco. Use um por seção. | `featuredFrom`, `featuredTo`, `featuredGlow`, `onFeatured` |
| Mini-bloco | `StatTile` em `#F6F7F9`, raio 14, para estatísticas secundárias. | `tile`, `tileRadius` |
| Controles | `PillSelect` com chevron num círculo (e `hideLabel` quando o valor se explica sozinho). Ação principal em pílula azul com ícone: `ActionButton variant="accent"`. | `tile` |

Contraste: no card em destaque, o texto branco fica sobre a parte funda do gradiente. O brilho claro mora no canto vazio. Pela amostragem dos pixels atrás do texto, o contraste fica em pelo menos 4,8:1 no claro e 5,1:1 no escuro. As pílulas sobre o azul são brancas com o texto no tom do juízo.

## TrendIndicator, anatomia `lean` (desenho smooth)

Sem prop nova obrigatória. Com `anatomy="lean"` (direto ou herdada do `PageContextProvider`), o card mostra:

1. **topo**: título e, se houver `icon`, o círculo de ícone. O botão de informação abre "Como calculamos";
2. **número** com a **pílula de variação** colada;
3. **linha de apoio** `comparison.label: valor anterior`. Quando a polaridade é `lower-is-better`, a cor da pílula contraria a seta; por isso o juízo também aparece em texto ("Mês anterior: **68** · desfavorável"). Em `higher-is-better`, a seta já diz o juízo. A frase completa para leitores de tela sempre leva direção, referência e juízo;
4. **ressalvas em pílula**, sem caixa: o `marker`, o "Parcial" automático e o "Desatualizado · há X";
5. **mini-gráfico** opcional (`data.series`): linha de 2 px com área no gradiente do destaque, à direita do número a partir de 25 rem de card.

Fonte e atualização **ficam fora do card**. Moram em "Como calculamos" e no contexto da página. Voltam ao card, em pílula, só quando mudam a leitura: "Desatualizado · há X", ou fonte e atualização diferentes das da página (ex.: "Posição de estoque há 9 h"). No máximo uma ação, no pé.

Um valor complementar com sinal ou juízo (`secondaryValue` com `signed` ou `polarity`, ex.: −R$ 52 mil vs. meta) ocupa a pílula, e o rótulo dele vira a linha de apoio. Um valor que já é variação (`valueAsChange`) mostra a referência e o juízo na linha de apoio.

| Prop nova | Tipo | Notas |
| --- | --- | --- |
| `featured` | `boolean` | Card em destaque (gradiente azul, texto branco, círculo branco). Um por seção. |
| `iconTone` | `"selected" \| "accent"` | Tom do círculo de ícone. Padrão `selected` (quase preto). No card em destaque o círculo é sempre branco. |

Estados no novo estilo: carregando (esqueleto com a mesma anatomia e `aria-busy`), vazio, erro (com "Tentar novamente"), sem permissão, parcial e desatualizado.

## ColumnChart

Colunas com trilha cinza clara de altura total, preenchimento cinza médio e **uma coluna em destaque**, azul com hachura diagonal. O **balão flutuante** (cartão branco, raio 12, sombra) mostra o período e os valores de todas as séries. Ele aparece na coluna em destaque, no hover e no foco, ao lado da coluna e na altura do topo da barra.

| Prop | Tipo | Notas |
| --- | --- | --- |
| `data` | `ColumnDatum[]` | `id`, `label` (eixo, ex.: "Ago"), `title` (balão e texto, ex.: "Agosto de 2026") e `values` por série. `null` ou ausente = sem valor ("—"), com trilha tracejada e nenhuma barra. Zero é zero: um traço baixo. |
| `series` | `[ColumnSeries, ...]` | `id`, `label` e `format`. A primeira define a altura; as outras aparecem no balão e no texto. |
| `label` | `string` | Nome da lista para leitores de tela. |
| `highlight` | `string \| "max" \| "min" \| "none"` | Padrão `max`. Ausência e valor inválido nunca são destaque. |
| `format`, `locale` | | Formatação por `Intl`; o eixo usa a notação compacta. |
| `max`, `ticks` | `number` | Topo da escala e intervalos. Padrão: topo redondo e justo, de 3 a 5 intervalos (`niceScale`). |
| `height` | `string` | Altura da área das colunas. Padrão `14rem`. |
| `axis` | `boolean` | Valores do eixo à esquerda. Padrão `true`. |
| `messages` | `Partial<ColumnChartMessages>` | "sem valor" e "em destaque" (pt e en). |
| `footer` | `ReactNode` | Legenda embaixo. |

Teclado: uma parada de Tab (a coluna em destaque). As setas, Home e End andam entre as colunas, e o balão acompanha o foco. Cada coluna tem o texto completo para leitores de tela, como em "Agosto de 2026: Pedidos 412, Receita R$ 178,6 mil (em destaque)". O balão é só visual (`aria-hidden`), porque repete esse texto. Valores negativos não são desenhados; para eles, use `Bars`. Com `prefers-reduced-motion`, as barras e o balão não animam.

Limites: de 3 a 12 colunas cabem bem a partir de 20 rem de largura. A trilha tem no máximo 3,5 rem.

Funções puras: `niceScale(max, ticks)` e `highlightedColumn(data, seriesId, highlight)`. `ColumnChartSkeleton` (`columns`, `height`) desenha o esqueleto com a mesma geometria, para o `loadingSkeleton` do `Panel`.

## SegmentedGauge

Meio círculo de segmentos arredondados, com o valor grande no centro e um rótulo pequeno embaixo. Os segmentos preenchidos levam o gradiente do destaque: começam fundos e clareiam até a ponta. O resto fica cinza claro. É a opção padrão para atingimento; o `ProgressRing` continua existindo.

| Prop | Tipo | Notas |
| --- | --- | --- |
| `value` | `number \| null` | Razão feita (0,708 = 70,8%). Fica cheio só a partir de 100%. Qualquer valor acima de zero acende ao menos um segmento; zero, negativo e `null` não acendem nenhum. |
| `segments` | `number` | Padrão 17 (o do meio fica no topo). |
| `label` | `string` | Nome acessível (`role="img"`), ex.: "70,8% da meta do trimestre". Sem ele, o desenho é decorativo e o texto do centro diz tudo. |
| `children` | `ReactNode` | Valor do centro, ex.: `<Figure text="70,8%" />`. |
| `caption` | `ReactNode` | Rótulo pequeno, ex.: "da meta". |
| `size` | `string` | Largura. Padrão `15rem`; também por `--rb-sgauge-size`. |

Os segmentos acendem da esquerda para a direita ao montar. Com movimento reduzido, aparecem sem animação. Funções puras: `filledSegments(value, count)` e `segmentPath(index, count)`.

## IconCircle, DeltaPill e StatTile

- `IconCircle`: ícone decorativo num círculo de 40 px. Tons: `selected` (padrão), `accent`, `inverse` (branco, para o card em destaque) e `soft`. O tamanho vem de `size` ou de `--rb-icon-circle-size`.
- `DeltaPill`: `text` (já formatado, com sinal), `direction`, `sentiment`, `srText` (frase completa para leitores de tela) e `size` (`md` ou `sm`). A seta mostra a direção; o juízo também precisa estar em texto, no `srText` ou na frase do widget.
- `StatTile`: `label`, `value` (texto formatado vira `Figure`) e `delta` (uma `DeltaPill` pequena).

## Etapa 2: evolução, tabela, prioridades e barra em destaque

Vale para `anatomy="lean"`, que vem da página (`PageContextProvider`) ou da prop. Com `full`, nada muda. As props e os dados são os mesmos da 0.3.

### EvolutionChart

- **Topo com dois números**: realizado e meta até a última data comparável, com a diferença em `DeltaPill` colada ao realizado. Sem meta diária, entra a meta do período; sem meta, a previsão de fim de mês ocupa o segundo lugar. O formato dos números é o `format` do widget: para que o topo se leia igual a uma tabela da mesma página, use o mesmo formato das colunas (por exemplo, reais sem centavos e sem notação compacta).
- **Legenda em pílulas** e **linha suave monotônica**: a curva não passa dos pontos, e a área termina onde termina a linha.
- **"Como calculamos"** recebe a diferença em reais, a previsão que não coube no topo e as notas da leitura (dia parcial, dias sem dados, valores inválidos), em vez de mostrá-las sob o gráfico.

### ComparisonTable

- **Busca em pílula** (`PillSearch`) e **ordenação em pílula** (`PillSelect` com presets e colunas) no cabeçalho, ao lado do CSV.
- A busca filtra pelo nome da linha e pelo complemento em texto. Ela ignora acento e caixa e casa o início das palavras: "rio" acha "Unidade Rio", mas não "período". Com várias palavras, todas precisam casar.
- Durante a busca, subtotais e total saem da tela, porque somariam linhas ocultas. A contagem é anunciada ("1 de 8 linhas na busca…"), e a mensagem de busca vazia cita o termo.
- Cabeçalho em faixa cinza e linhas mais altas. Percentuais seguem o `format` de cada coluna: para alinhar a coluna, fixe as casas (`minimumFractionDigits` igual a `maximumFractionDigits`).

### PriorityList

- Cada prioridade vira um **card-botão**. Ele mostra o ícone (`PriorityItem.icon`, ou a posição, sem ícone), o assunto com o tipo, o problema como título, a primeira evidência e a pílula de impacto.
- A evidência quebra em até 2 linhas. Texto maior que isso é cortado no card e aparece inteiro no detalhe.
- O card abre o `DetailPanel` com impacto, tipo, todas as evidências, hipótese, próximo passo, motivo da posição, estágio e ação. Esc ou o botão fechar devolvem o foco ao card.
- Para manter a lista com "Ver evidências", passe `itemDetail` explicitamente.

### Barra em destaque

`highlight` (a barra em destaque de `Bars` e o meio-gauge) passa a ser o azul Rbbt: `#3F6DFF` no claro e `#7B9CFF` no escuro.

### Dados da página de exemplo

A história "Smooth · Etapa 2" usa um conjunto fictício só (`stories/fixtures-smooth.ts`). A venda e a meta das 8 unidades até 16/10 são distribuídas pelos dias, em centavos. Com isso, o gráfico até 16/10 fecha com a linha Rede da tabela: R$ 1.618.456 contra R$ 1.636.500, −R$ 18.044 e 98,9%. As prioridades citam as linhas da tabela e seguem o critério declarado. A conciliação é conferida ao centavo em `tests/unit/smooth-etapa2.spec.ts` e na tela em `tests/e2e/smooth-etapa2.spec.ts`.

## Fase 2: contexto, filtros, abas, menus, card que abre e painel

História "Smooth/Componentes · contexto, filtros e painel" (id `smooth-componentes`), clara e escura, com todos os estados abaixo. Capturas de revisão: `tests/review/componentes.spec.ts`.

### ContextBar, anatomia `lean`

- Título 26/600 com subtítulo curto; a perspectiva fica numa trilha de pílula à direita.
- Cada filtro vira uma `PillSelect` de 40 px, com rótulo e valor. A ajuda do filtro (`description`) vira descrição acessível da pílula.
- Abaixo de `collapseBelow` (padrão 640 px), os filtros viram um resumo de uma linha e o botão "Filtros" abre a folha. A folha usa os campos com rótulo e ajuda visíveis.
- Estados:
  - `status="loading"`: esqueleto das pílulas (ou do resumo e do botão, se recolhida) e da linha de metadados, com `aria-busy` e aviso para leitor de tela; o título continua visível;
  - filtro sem opções: pílula desabilitada com "Sem opções", também no resumo. O valor nunca some nem vira outro;
  - erro numa lista: passe a opção "Indisponível" com `isDisabled` e diga o motivo na `coverage` com tom `negative` (o marcador abre o detalhe);
  - desatualizado: pílula de aviso com o tempo desde a última atualização (`staleAfterMs`);
  - parcial: `coverage` com tom `warning` e o detalhe no marcador.

### Filtros, abas e menus

- `FilterPills`: pílulas brancas sobre a página e cinza claras dentro de cards. A ativa fica no gradiente azul do destaque, e a contagem vai numa bolha. Desabilitada, a pílula fica só com contorno.
- Contagem: `count: 0` mostra 0; `count: null` mostra "—", lido como "sem contagem"; sem `count`, nada aparece.
- `PillTabs`: trilha de pílula com a aba ativa em branco e o ícone no azul. Em telas estreitas, a trilha rola na horizontal e não quebra.
- Menus (`PillSelect` e `SelectField`): lista com cantos de 16 px, opção de 40 px, fundo cinza claro ao focar e check no azul. A lista da `PillSelect` se alinha à pílula inteira.

### OpenCard e DetailPanel

- `OpenCard`: cantos de 24 px, sombra smooth, ícone em círculo de 40 px e número no peso 600.
- `DetailPanel`: cantos de 24 px no lado aberto, cabeçalho sem borda, ícone em círculo e fechar num círculo cinza. No celular, vira folha de baixo com cantos de 24 px e a ação principal na largura toda.

### StatCard em destaque por token

O padrão é grafite. O azul do indicador em destaque é só token, sem editar o componente:

```ts
<RbTheme tokens={{
  statFeaturedFrom: "var(--rb-featured-from)",
  statFeaturedTo: "var(--rb-featured-to)",
  statFeaturedMuted: "var(--rb-on-featured)",
}} />
```

No azul, o texto secundário vai a branco pleno: com 76% de opacidade, ele ficaria abaixo de 4,5:1.

## Migração da 0.3.0-rc.x

- **Destaque**: `--rb-accent` deixa de ser verde e vira o azul Rbbt, nos dois modos. Quem tem marca própria troca por tokens, como já fazia (um cliente com azul próprio continua com o seu). Para manter o verde da 0.3, passe `accent`, `accentSoft`, `accentBorder`, `focus` e `sparkFill` com os valores antigos (estão no CHANGELOG).
- **`anatomy="lean"`**: o card muda de desenho, e as props continuam as mesmas. Fonte e atualização saem do card e vão para "Como calculamos". A linha de comparação vira a pílula com a linha "Rótulo: valor". Para o desenho anterior, fixe a 0.3.0-rc.3.
- **Panel com `lean`**: a moldura ganha raio 24, padding 24, sombra suave e nenhuma borda. O conteúdo dos widgets de painel muda na Etapa 2 (seção acima).
- **PillSelect**: o chevron passa a ficar num círculo, em todos os modos.
- **Etapa 2**:
  - para manter o laranja da barra em destaque, passe `highlight` com `#c2410c` no claro e `#fb923c` no escuro;
  - para manter a `PriorityList` enxuta em lista, passe `itemDetail="expandable"`;
  - `ComparisonTable` e `EvolutionChart` com `lean` mudam só o desenho, e as props continuam as mesmas.
- **Fase 2**:
  - `ContextBar` com `lean` troca os campos por pílulas, com as mesmas props. Para os campos com ajuda visível, use `anatomy="full"`;
  - filtros, abas, menus, `OpenCard` e `DetailPanel` mudam só o desenho.
