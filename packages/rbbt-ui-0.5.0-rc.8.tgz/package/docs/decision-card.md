# Cartão de decisão (`DecisionCard`) · 0.5.0-rc.7 (Lote 4)

Um cartão por decisão: **problema**, **evidência** (números e links para a origem), **proposta**,
**responsável** e **prazo**, com o **estado** (rascunho, proposto, decidido, descartado) e o **motivo do
estado** visível (quem, quando e por quê). Nasce de um alerta ou de um item da fila de prioridades e guarda o
**contexto original congelado**.

## Quando usar

- Transformar um alerta ou uma prioridade em decisão rastreável, sem perder o recorte em que o problema foi visto.
- Para a lista ordenada de prioridades, use a fila; para medir o efeito depois da ação, o placar de efeito.

## Dados

```ts
type DecisionData = {
  id: string;
  title: string; // nome curto (título do cartão)
  problem: string; // o que está errado (some quando igual ao título)
  evidence: DecisionEvidence[];
  proposal?: string | null;
  owner?: { id?: string; name: string } | null;
  due?: IsoDay | null; // AAAA-MM-DD
  state: "draft" | "proposed" | "decided" | "discarded";
  stateNote?: { by: string; at: DateInput; reason: string } | null; // quem, quando, por quê
  context?: DecisionContextSnapshot | null; // congelado
};
type DecisionEvidence = {
  id?: string; // liga ao valor do snapshot e a currentValues
  label: string;
  value?: number | null; // indefinido = evidência em texto (note); null = ausência (nunca zero); NaN = leitura inválida
  format?: ValueFormat;
  missingReason?: string;
  href?: string; // link para a origem
  source?: string;
  note?: string;
};
```

## Nasce de um alerta ou da fila (snapshot imutável)

```ts
captureContextSnapshot(input, capturedAt) // cópia profunda congelada, capturedAt obrigatório (vira ISO UTC)
decisionFromAlert(alert, context, capturedAt, options?)
decisionFromQueueItem(item, context, capturedAt, options?)
```

- **Snapshot:** `{ capturedAt, origin: { kind, id, title }, period: { label, start?, end? }, filters: [{ label, value }],
  stores: string[], values: DecisionValue[], source: { label, href?, updatedAt? } }`. `Object.freeze` em todos os
  níveis: mudar a entrada depois não muda o snapshot, e o snapshot não aceita mudança. `capturedAt` inválido lança
  `RangeError` (snapshot sem data e hora não existe).
- **Alerta** (formato genérico): `{ id, title, description?, values?, period?, stores?, filters?, source? }`. O que o
  alerta traz vence; `context` completa o que faltar. As evidências são os valores do alerta. Nasce em rascunho.
- **Item da fila** (aceito pela forma, sem importar o widget da fila):
  `{ id, title, subject?, impact?: { value, format?, basis?, missingReason? }, urgency?: { due?, window?, label? },
  confidence?: { level, reason }, owner?, evidence?: [{ label, value?, format?, href?, source? }] }`. O impacto entra
  como "Impacto estimado" (valor `impact` do snapshot, com a base da conta), sempre em moeda: vale `impact.format`;
  sem ele, `options.impactFormat`; sem os dois, R$ sem centavos, como a fila (no cartão, o valor inteiro:
  "R$ 18.400"). Impacto `null` continua "Sem leitura", nunca R$ 0. Evidências com número entram no snapshot
  (`evidence-1`, `evidence-2`…); confiança e urgência viram evidência em texto; responsável e prazo (prazo ou fim da
  janela) vêm preenchidos. O recorte (`subject`) entra no título ("Margem caindo · Loja 07") e o problema é a mesma
  frase, então o cartão não repete a seção "Problema". `context` dá período, filtros, lojas e fonte da fila no momento.
- **Opções** (`options?`, as duas funções): `id` (padrão `decisao-<id da origem>`), `messages` (rótulos criados aqui)
  e, só na fila, `impactFormat`.
- **Na tela:** "Contexto do alerta · 30/10/2026 07:12" (ou "Contexto da fila") com período, lojas (até 3 e "+N lojas";
  a lista inteira no detalhe), filtros e fonte (link e atualização). "Ver contexto original" abre o `DetailPanel` com
  origem, todos os filtros e lojas e a tabela dos valores no momento da captura (e os de agora).

## Valores que mudaram

`currentValues: Record<idDoValor, number | null>` e `currentAt` (quando foram lidos). Por id, `compareValue(alerta, agora)`:

| Caso | Na tela |
| --- | --- |
| sem chave em `currentValues` | só o valor do alerta |
| igual | o valor e "igual agora" |
| diferente | "no alerta R$ 12.400 · agora R$ 15.800" e a diferença "+R$ 3.400 (+27,4%)"; percentuais em p.p. |
| `null`/`NaN` agora | "no alerta 62% · sem leitura agora" (**ausência agora ≠ zero**) |
| sem leitura no alerta | "no alerta sem leitura · agora 240" |

A diferença é neutra (sem cor de bom ou ruim): o cartão não conhece a polaridade da métrica.

## Ações (só callbacks)

| Ação | Estado | Callback |
| --- | --- | --- |
| Propor | rascunho | `onPropose(decision)`; desabilitado com o motivo enquanto faltar proposta, responsável ou prazo |
| Decidir | proposto | `onDecide(decision)` |
| Atribuir | rascunho, proposto | `onAssign({ owner, due }, decision)` pelo formulário de responsável e prazo |
| Descartar | rascunho, proposto | `onDiscard(motivo, decision)` pelo formulário com motivo obrigatório |

Decidido e descartado são registro: sem botões, com a frase de encerramento. Botão aparece quando há callback ou
entrada em `permissions`. **Sem permissão** (`permissions: { decide: { allowed: false, reason } }` ou `false`): o botão
fica desabilitado, com cadeado e o motivo visível embaixo ("Decidir: só a gerência regional decide."), ligado por
`aria-describedby`; nunca escondido. O cartão não grava, não usa localStorage e não chama rede: depois do callback, o
estado exibido continua vindo das props.

## Formulário de responsável e prazo

- Responsável obrigatório (sugestões de `people` por `datalist`; nome igual a uma pessoa da lista leva o `id`).
- Prazo obrigatório, `dd/mm/aaaa` ou `AAAA-MM-DD` (`parseDueDate`; 31/02 é inválido) e **não antes de `today`**
  (padrão: hoje no fuso `timeZone`). Regras em `validateAssignment(input, today, locale)`.
- Erros: `aria-invalid` no campo, mensagem ligada por `aria-describedby` (antes da dica), anúncio "2 campos precisam de
  correção." e **foco no primeiro campo com erro**. Esc ou "Cancelar" fecham e devolvem o foco ao botão.

## Estados e contexto

`status`: `loading` (esqueleto), `empty`, `error` (com `onRetry`), `partial` (com `partialNote`), `stale`, `restricted`.
Período e lojas no subtítulo (do snapshot, ou `period`/`scope`), fonte no rodapé (padrão: a do snapshot).

## Adaptador

```ts
decisionFromRecord(record, { id, title, problem?, proposal?, state?, owner?, due?, stateBy?, stateAt?, stateReason?,
  evidence?: [{ id?, label, value: "metricas.perdidas", format?, href?, source? }] })
```

Números por `toMetricValue` (`adapters/series.ts`): vazio/`null` = ausência (`null`), "12.400,50" vira número, texto
inválido vira `NaN` ("Leitura inválida"). Estado em pt ou en ("Proposto", "decided"); desconhecido vira rascunho.
Prazo em ISO, `dd/mm/aaaa` ou série do Excel. Registro não tem snapshot: o contexto só nasce de um alerta ou da fila.

## Texto alternativo

`display="text"` mostra o cartão em linhas (`decisionSummary(decision, options)`), útil também para copiar numa mensagem.

## Movimento e acessibilidade

Cascata só na entrada, com Motion (estado, problema, evidência, proposta, responsável, contexto, ações; atraso por
`entranceDelay` e pelos tokens de movimento); troca de dado, de estado ou formulário aberto não refaz a cascata, e nada
se desloca com movimento reduzido. Seções nomeadas por título; comparação lida por extenso ("Vendas perdidas: no alerta R$ 12.400,
agora R$ 15.800, diferença +R$ 3.400 (+27,4%)"); links "ver na origem" com o nome da evidência; detalhe com foco preso,
Esc fecha e devolve o foco a "Ver contexto original". axe sem violações no claro e no escuro, com o detalhe aberto e
com o formulário em erro. A 360 px a evidência empilha, sem rolagem lateral e sem reticências em valores.

## Fora de escopo

Edição de problema e proposta no cartão, histórico de estados, comentários e reabertura de decisão.
