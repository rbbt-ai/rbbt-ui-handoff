# Meta × realizado · `BulletBar`, `BulletList` e a célula da `ComparisonTable` (0.5.0-rc.5)

Bullet chart compacto para comparar o realizado com a meta por loja. Cabe numa linha de tabela
(12–20 px de altura) e tem duas formas de uso: sozinho, como lista por loja (`BulletList`), ou como
célula da `ComparisonTable` (`bulletColumnCell`). Renderização em DOM próprio (sem biblioteca de
gráfico, sem canvas): cada linha da lista é focável e tem nome acessível completo.

## Anatomia

| Elemento | O que mostra | Token |
| --- | --- | --- |
| Faixas ao fundo | `< 90%`, `90–100%` e `≥ 100%` da meta (cortes em `cuts`) | `--rb-bullet-band-low`, `-mid`, `-high` |
| Barra do realizado | realizado ÷ meta na escala | `--rb-bullet-bar` (destaque do tema ou do cliente) |
| Marca da meta | traço cheio em 100% | `--rb-bullet-target` |
| Marca da projeção (opcional) | traço pontilhado em projeção ÷ meta | `--rb-bullet-projection` |
| Texto ao lado | `98,0% · −R$ 6,9 mil` (atingimento · diferença para a meta) | texto 600 + diferença mais leve |
| Leitura | ícone + texto: abaixo, perto, atingida, sem meta, meta zero, sem dado | `--rb-bullet-below`, `-near`, `-met`, `-none` |

Medidas: trilho `--rb-bullet-track-h` (12 px), barra `--rb-bullet-bar-h` (6 px), marcas
`--rb-bullet-mark-h` (18 px). A caixa nunca passa de 20 px.

## Dados

```ts
interface BulletDatum {
  actual: number | null | undefined;  // realizado; ausente = "sem dado" (nunca 0)
  target: number | null | undefined;  // meta; ausente = "sem meta" (nunca 0%)
  projection?: number | null;         // projeção de fechamento (opcional)
}
interface BulletItem extends BulletDatum { id: string; label: string; sublabel?: string }
interface BulletListData { items: ReadonlyArray<BulletItem> }
```

- **Atingimento** = realizado ÷ meta. **Diferença** = realizado − meta.
- A faixa usa o atingimento **arredondado às casas exibidas** (`decimals`, padrão 1): o texto `90,0%` e a faixa
  "perto da meta" nunca discordam.
- **Sem meta** (`target` nulo, ausente ou negativo): estado próprio, trilho tracejado, sem faixa, sem barra e
  sem "0%". O texto mostra `Sem meta · R$ 154,8 mil` (o realizado continua visível).
- **Meta zero** (`target: 0`): caso de borda declarado. Não há divisão: `Meta zero · +R$ 12,4 mil`.
- **Sem dado** (`actual` ausente): `Sem dado`, nunca barra em zero. **Realizado 0 com meta** é leitura: `0,0%`, faixa
  abaixo da meta.
- Total da tabela: só as linhas com meta > 0 e realizado entram ("Total das 6 de 8 lojas com meta e
  realizado"); sem meta e sem dado ficam fora, nunca como zero.

### Adaptador

`bulletFromRecords(records, mapping)` lê linhas de uma view de Bases ou de um cenário
(`createScenarioReader(...).rows("meta-realizado")`), com a regra de número de `toMetricValue`
(`adapters/series.ts`): `"1.234,5"` vira número; `""`, `null` e texto inválido são ausência. Campos por nome
ou caminho com pontos (`readPath`). Linhas repetidas da mesma loja somam; se uma delas não tem leitura, o
campo fica sem leitura (somar só as outras trataria a falta como zero).

```ts
const data = bulletFromRecords(rows, { id: "loja", label: "nome", actual: "realizado", target: "meta", projection: "projecao" });
```

## `BulletBar` (primitivo)

| Prop | Tipo | Padrão | |
| --- | --- | --- | --- |
| `actual`, `target`, `projection` | `number \| null` | | leitura |
| `label` | `string` | | entra no nome acessível |
| `format` | `ValueFormat` | BRL compacto, 1 casa | realizado, meta e diferença |
| `cuts` | `[number, number]` | `[0.9, 1]` | cortes das faixas em fração da meta |
| `max` | `number` | automático (≥ 1,2, até 2) | fim da escala em fração da meta; use o mesmo valor em várias barras para alinhar as metas |
| `decimals` | `number` | `1` | casas do atingimento |
| `text` | `"full" \| "pct" \| "none"` | `"full"` | texto ao lado |
| `decorative` | `boolean` | `false` | `aria-hidden` quando o nome já está num elemento acima |

Sem `decorative`, o gráfico tem `role="img"` e o **nome acessível completo**, por exemplo:
"Centro: realizado R$ 336.900, 98,0% da meta de R$ 343.800, diferença −R$ 6.900, perto da meta, projeção
R$ 352.400 (102,5%)".

Acima do fim da escala, a barra fica cortada com a ponta em chanfro; o texto mostra o valor real.

### Espaço mínimo do rótulo

O texto do valor fica **sempre fora da barra, ao lado dela**, então nenhuma barra fica sem rótulo. O trilho
precisa de pelo menos **64 px** (`BULLET_MIN_TRACK_PX`, token `--rb-bullet-min-track`; 6,5 rem na célula da
tabela). Quando o contêiner é menor que o trilho mínimo + o texto (~140 px em pt-BR), o texto **desce para
baixo da barra** (quebra do flex), nunca some e nunca se sobrepõe. Testado por geometria no DOM (e2e).

## `BulletList` (widget)

Frame comum (título, período, lojas, origem, estados carregando, vazio, parcial, erro), resumo em uma frase
("4 de 6 lojas atingiram a meta · 1 sem meta"), legenda das faixas e das marcas, uma linha por loja (nome +
leitura com ícone, BulletBar, texto), ordenação (`attainment`: menor atingimento primeiro, padrão; `gap`:
maior falta; `name`) e tabela alternativa (loja, realizado, meta, atingimento, diferença, projeção, situação).
Sem meta, meta zero e sem dado ficam sempre no fim da ordem.

- **Teclado:** uma linha na ordem de Tab; setas, Home/End; Esc fecha o balão.
- **Hover discreto:** linha ativa, as outras recuam (opacidade da barra, texto mais suave), balão com
  realizado, meta, atingimento, diferença, projeção e o período. O tap no celular dá o mesmo estado; tap
  fora fecha.
- **Posição do balão:** o lugar livre mais perto da linha ativa, medido no DOM. Ele nunca cobre a própria
  linha nem texto do quadro (nomes, leituras, legenda) e evita os trilhos das outras linhas quando dá.
  Sem lugar para o completo, o compacto omite o período, que já está no cabeçalho.
- **Movimento:** a cascata só vale na entrada (`RbEntrance`/`useEntrance`); na troca de recorte, a barra e as
  marcas vão do valor antigo ao novo, sem passar por zero; com movimento reduzido, nada anima.
- **Celular:** abaixo de 30 rem de contêiner, nome e leitura em cima, barra e texto embaixo; 360 px sem
  rolagem lateral.

## Célula da `ComparisonTable`

Campo aditivo e compatível `ComparisonColumn.cell?: (ctx: ComparisonCellContext) => ReactNode` (ver o
contrato da ComparisonTable). Helper pronto:

```tsx
const columns: ComparisonColumn[] = [
  { id: "actual", header: "Realizado", format: { style: "currency", currency: "BRL" } },
  { id: "target", header: "Meta", format: { style: "currency", currency: "BRL" }, emptyText: "sem meta" },
  {
    id: "attainment", header: "Meta × realizado",
    format: { style: "percent", minimumFractionDigits: 1, maximumFractionDigits: 1 },
    derived: { kind: "ratio", of: ["actual", "target"] },
    cell: bulletColumnCell({ actualColumn: "actual", targetColumn: "target", projectionColumn: "projection" }),
  },
];
```

`bulletColumnCell({ targetColumn, projectionColumn?, actualColumn?, format?, cuts?, max = 1.25, decimals?, text? })`
lê a meta e a projeção em `row.values` (a projeção pode estar só nos valores, sem coluna). O **valor numérico
da coluna** continua valendo para a ordenação, o CSV, a conferência de colunas derivadas e o leitor de tela: a
célula mantém o texto padrão para tecnologias assistivas e põe o desenho como decorativo. No modo cartão
(< 640 px), o mesmo renderizador ocupa a largura do cartão.

## i18n

Mensagens pt-BR e en-US em `bulletMessages`; sobrescreva qualquer uma por `messages`.
