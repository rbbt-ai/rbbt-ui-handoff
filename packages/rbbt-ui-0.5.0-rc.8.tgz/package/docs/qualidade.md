## Uso

`QualityOverview` responde "posso confiar nestes números?" antes da decisão: três cards de confiança (**cobertura**, **fonte e posição**, **mesmo universo**), o **mapa de cobertura** por unidade, com busca e ordenação, e **Origem e fórmula**.

## Dados (contrato com Bases)

- Cobertura: `coverageFromRecords(rows, { value, id })` → `{ covered, total, missing }`. Cobertura desconhecida (`null`) aparece como "Cobertura indisponível", nunca "0".
- Mapa: `coverageMapFromRecords(rows, { id, label?, value, lastReading? }, { now?, staleAfterMs? })` → `ok` (com dados), `stale` (leitura mais velha que `staleAfterMs`) ou `missing` (sem valor numérico).
- Origem e fórmula: o mesmo conteúdo do `Methodology` (`source`, `formula`, `coverage`, `exclusions`, `limitations`…).

## Títulos do cliente (0.5.0-rc.2)

- Cada card aceita `label`, que troca o título fixo: `coverage.label` (padrão "Cobertura"), `snapshot.label` ("Fonte e posição") e `universe.label` ("Mesmo universo"). Ex.: "Lojas com dados", "Snapshot de 26/10, 06:00".
- `methodologyTitle` troca o título do bloco "Origem e fórmula" (ex.: "Origem e fórmula, sempre disponíveis.").
- O card é nomeado pelo título visível (`aria-labelledby`); sem os textos do cliente, ficam os do pacote.

## Acessibilidade

- Situação sempre com texto ("Sem leitura", "Desatualizada", "Com dados") e ponto de cor; sem leitura também ganha listras.
- Busca em pílula (React Aria) e ordenação em controle segmentado; "Nenhuma unidade encontrada" em região de status.

## Estados

Carregando, erro (com "Tentar de novo"), cobertura desconhecida. A contagem da cobertura anima na entrada do workspace.
