# Card de insight · `InsightCard` e `InsightList` (0.5.0-rc.8)

Um achado em texto, curto e verificável. O texto sai de modelos determinísticos a partir de dados
estruturados (sem LLM e sem rede) e cada achado aponta a evidência que o sustenta.

## Anatomia

| Parte | O que mostra |
| --- | --- |
| Cabeçalho | título curto, tom em texto (Positivo, Atenção ou Neutro) e polaridade ("subir é bom") |
| Frase principal | uma frase curta: "Ticket médio da Praia subiu 13,2% contra a média da rede." |
| Apoio | até duas frases ("A variação coincide com a vitrine de Dia das Crianças.") |
| Números | os valores do achado com os formatadores da biblioteca; ausência = "sem leitura" |
| Força | forte, moderado ou fraco, sempre com o motivo ("variação de 13,2%, bem acima do limiar de 2%") |
| Aviso parcial | quando falta loja: "Com 7 de 8 lojas: falta a leitura de 1 loja." |
| Evidência | link "Ver evidência: <rótulo>" |
| Ações | fixar, dispensar e abrir, por callback; sem permissão, desabilitada com o motivo visível |
| Rodapé | período, lojas e origem, sempre visíveis |

A cor nunca é o único sinal: o tom e a força aparecem em texto.

## Modelos de texto

```ts
const achado = insightFromComparison({
  id: "ticket-praia",
  metric: "ticket médio da Praia",        // como entra na frase
  current: 214, reference: 189,           // aceita texto numérico (regra de toMetricValue)
  referenceLabel: "a média da rede",
  format: { style: "currency", currency: "BRL", maximumFractionDigits: 0 },
  polarity: "higher-is-better",
  coverage: { reporting: 8, total: 8 },   // lojas com leitura × esperadas
  coincidesWith: "a vitrine de Dia das Crianças",
  period: "Semanas 32 a 43 de 2026",
  source: "ERP fictício · vendas por loja",
  evidence: { label: "ticket médio por loja", kind: "detail", href: "https://…" },
});
```

`insightFromSeries` recebe `points` (`{ label, value }`, com `null` para lacuna) e descreve a série do
primeiro ao último valor válido. Regras dos dois modelos:

- **Ausência** vira "sem leitura de X", nunca 0. Sem referência: "… sem leitura de <referência> para comparar".
- **Parcial** qualifica a frase ("com 7 de 8 lojas") e deixa o achado fraco, com o motivo.
- **Estável:** variação relativa dentro do limiar (`threshold`, padrão 2%) vira "estável".
- **Força:** forte a partir de 3× o limiar com todos os dados; moderado acima do limiar; fraco no estável, no
  parcial, com lacunas ou sem dado.
- **Polaridade:** subir com `lower-is-better` vira "Atenção"; `neutral` não colore.
- **Sem causa:** o apoio diz "coincide com", nunca "por causa de".
- **Locale:** mensagens pt-BR e en-US em `insightCardMessages`; `messages` troca qualquer texto.

`insightSummary(achado)` devolve o achado inteiro em frases, para a alternativa em texto ou um resumo.

## Evidência

`InsightEvidence` = `{ label, href?, kind?, target? }`.

- **`href`** (origem externa): só `http(s)`; outro protocolo (`javascript:`, `data:`) é recusado e o card mostra
  "Evidência: <rótulo> (sem link)". O link abre em nova aba com `rel="noopener noreferrer"`.
- **`onOpenEvidence(evidence, insight)`**: o consumidor escolhe o destino. `kind` e `target` são dicas que o card
  não interpreta. Os três destinos de referência (catálogo, história "Evidência"):
  - `xray`: `useXray().open(request, { returnFocusId: insightEvidenceId(insight) })`, o raio-X do Lote 4;
  - `detail`: um `DetailPanel` com os números em tabela;
  - `widget`: rolagem até o widget de origem (`scrollIntoView`, `auto` com movimento reduzido) e foco nele.
- Com os dois, o clique simples abre o destino do consumidor e o clique com modificador abre a origem externa.
- O nome acessível é sempre "Ver evidência: <rótulo>".

## Estados

`status`: `loading`, `empty` ("Nenhum achado neste recorte."), `partial` (com `partialNote`) e `error` (com
`onRetry`). Sem achado, `period`, `stores` e `source` mantêm o rodapé visível.

## Ações e persistência

`onPin`, `onDismiss` e `onOpen`. O card não grava nada, não usa localStorage e não chama rede; `pinned` só é
exibido. `permissions` aceita `false` ou `{ allowed: false, reason }`: o botão fica desabilitado e o motivo
aparece em texto.

## Movimento (Motion)

- **Entrada:** cascata curta das partes do card (cabeçalho, frase, apoio, números, força, links e rodapé), só na
  entrada (`useEntrance`/`entranceDelay`).
- **Troca de filtro:** os números vão do valor antigo ao novo com `CountUp` (`useCountUp`), sem cascata; ausência
  troca direto.
- **Movimento reduzido:** valores finais direto. Nenhum `@keyframes`, `transition-delay` ou
  `requestAnimationFrame` próprio.

## Segurança

Texto de dados é texto: nada de `dangerouslySetInnerHTML`. Um título ou frase com `<script>` aparece literal.
