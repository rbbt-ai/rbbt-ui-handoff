# Cascata do resultado (`ResultWaterfall`) · contrato 0.5.0-rc.5

Do resultado do período de comparação (base) ao resultado atual, pelos degraus **volume**, **preço** e **mix**, e **resíduo/outros** quando houver. Conciliada ao centavo: base + Σ degraus = atual.

## Entradas

- **(a) Itens** (`data.items`): `{ id, label, baseQuantity, basePrice, currentQuantity, currentPrice }`. O modelo decompõe.
- **(b) Efeitos prontos** (`data.effects`): `{ base, current, volume?, price?, mix? }`. O widget calcula o resíduo = atual − base − Σ efeitos conhecidos.
- Opcional na entrada (a): `baseResult` e `currentResult`, os totais oficiais da fonte. A parte que os itens não explicam entra no resíduo como "não explicado pela fonte".
- `null` é **sem dado** e nunca vira zero. Zero é leitura: quantidade 0 na base = item novo; 0 no atual = item descontinuado. Com quantidade 0, o valor unitário daquele período não é exigido.

## Método (entrada a)

Com R = Σ qᵢ·pᵢ, Q = Σ qᵢ, P̄0 = R0 ÷ Q0 e s = participação na quantidade (qᵢ ÷ Q), nos itens presentes nos dois períodos:

| Degrau | Fórmula | Leitura |
| --- | --- | --- |
| Volume | (Q1 − Q0) × P̄0 | variação de quantidade ao preço e mix da base |
| Mix | Σᵢ (s1ᵢ − s0ᵢ) × Q1 × p0ᵢ | mudança de participação a preços da base |
| Preço | Σᵢ (p1ᵢ − p0ᵢ) × q1ᵢ | variação de preço sobre a quantidade atual |

- Volume + mix + preço = R1 − R0 exatamente nos itens comparáveis (antes do arredondamento).
- **Centavos inteiros.** O resultado de cada item (q × p) e cada efeito são arredondados uma vez ao centavo, meio para longe do zero. O que o arredondamento deixa vai para o resíduo ("arredondamento"), nunca é escondido.
- **Resíduo/outros** = atual − base − (volume + preço + mix) = itens novos + descontinuados + não explicado + arredondamento. O degrau aparece quando não é zero ou quando há algo para declarar nele.
- **Itens sem dado:** ficam fora da base e do atual calculados e aparecem listados em "Sem dado". Com totais oficiais, o valor deles entra no resíduo como "não explicado".
- **Efeitos prontos sem dado:** o degrau aparece tracejado com o texto "Sem dado" e o valor dele fica no resíduo.

## Leitura visual

- Barras cheias na base e no atual; degraus flutuantes com **sinal, seta e valor em texto**, além da cor (`--rb-waterfall-up`, `--rb-waterfall-down`, `--rb-waterfall-residual`, `--rb-waterfall-total`, `--rb-waterfall-none`). Linhas-guia tracejadas (`--rb-waterfall-guide`) ligam o fim de um degrau ao começo do seguinte.
- **Eixo (`baseline`)**: em `auto`, quando os degraus são pequenos perto do resultado, o eixo começa acima de zero num valor redondo; a quebra aparece nas barras cheias e a nota diz onde o eixo começa. `zero` força o eixo do zero.
- **Rótulo de valor sempre visível.** O rótulo fica fora da barra, 6 px acima (positivo, base e atual) ou abaixo (negativo), então não depende da altura da barra. O espaço mínimo é a largura da coluna: **88 px** (`RESULT_WATERFALL_MIN_COLUMN`), medido para o rótulo mais largo ("▼ −R$ 123,4 mil", ~84 px a 12 px). Quando o contêiner não dá 88 px por degrau (6 degraus + vãos de 10 px = 578 px), a cascata vira **linhas horizontais**: nome, barra e valor em colunas próprias, sem colisão a 360 px.
- Tabela alternativa: cada degrau em R$ (com centavos) e em % do resultado da base, com o acumulado. A nota de conciliação fica visível nas duas vistas: "Base + efeitos = atual · resíduo R$ 0,03".

## Interação e movimento

- Cada degrau é um item focável (tabindex móvel). Setas ← → (e ↑ ↓) percorrem; Home/End; Esc fecha o balão. Hover discreto: o degrau ativo fica, os outros recuam, e o balão mostra valor, % da base, "de X para Y", a fórmula e o contexto. No celular, o tap dá o mesmo estado; tap fora fecha.
- Posição do balão (colunas): o primeiro lugar livre medido no DOM, na ordem acima da barra, ao lado da coluna (direita, depois esquerda) e abaixo. Ele nunca cobre rótulos de valor, nomes, o chão do eixo nem a própria barra e, quando dá, também não cobre as outras barras. Se o balão completo não couber em lugar nenhum, entra o compacto (nome, valor e leitura). O de-para, a fórmula e o contexto continuam na tabela. Em linhas (estreito), o balão fica acima da linha ativa ou, sem espaço, abaixo dela.
- Entrada em cascata só na janela da entrada (`RbEntrance`/`useEntrance`): cada barra cresce a partir do nível anterior. Na troca de recorte, as barras vão do valor antigo ao novo (propriedades CSS registradas com `@property`), sem cascata e sem passar por zero. Movimento reduzido: sem animação, contorno no degrau ativo.

## Adaptador

`resultWaterfallFromRecords(records, mapping, extra?)` lê linhas de uma view de Bases ou de um cenário (`createScenarioReader(...).rows(...)`), com números pela regra de `toMetricValue` ("1.234,56" vira número; vazio e texto inválido são ausência, nunca zero).

- Itens: `{ id, label?, baseQuantity, currentQuantity, basePrice | baseRevenue, currentPrice | currentRevenue, order? }`. Linhas repetidas do mesmo item somam quantidade e receita; o preço vira o médio. Uma leitura faltando deixa o lado do item sem dado.
- Efeitos prontos: `{ step, value, names? }`, uma linha por degrau (`base`, `volume`, `price`, `mix`, `current`).

## Estados

Carregando, vazio, parcial, erro, sem permissão e desatualizado pelo frame comum (`useWidgetFrame`). Sem base, sem atual ou sem item com dado: estado vazio com o motivo. Período, lojas e origem ficam sempre visíveis.
