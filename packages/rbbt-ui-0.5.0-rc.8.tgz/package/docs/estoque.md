## Uso

`StockGrid` mostra o estoque de uma referência por tamanho × unidade, com cobertura em semanas e posição datada. `TransferSimulator` simula uma transferência entre duas unidades e mostra o efeito previsto nas duas pontas. **Nenhum dos dois movimenta estoque.**

## Simulador sob demanda (0.5.0-rc.2)

`TransferSimulatorDialog` é o mesmo simulador num painel lateral (folha inferior no celular), aberto pelo botão "Simular transferência" da grade (`onSimulate`). Recebe as props do `TransferSimulator` e mais `isOpen`, `onClose`, `returnFocusId?` e `portalContainer?`.

- **Foco:** entra no painel ao abrir. Esc, o botão de fechar e o clique fora fecham, e o foco volta ao botão que abriu (ou ao `returnFocusId`).
- **Glass:** o painel tem o desfoque das superfícies (`backdrop-filter`) sobre um vidro mais denso. Sem suporte a desfoque no navegador, fica opaco.
- **Continua "Simulação":** o selo fica no topo do painel e nada é movimentado. "Criar rascunho de avaliação" vai para o rodapé fixo, ao lado das notas.
- O `TransferSimulator` sempre aberto, num painel da página, continua valendo.

## Quantidade: mínimo, máximo e motivo (0.5.0-rc.2)

| Prop | Padrão | Regra |
|---|---|---|
| `minQuantity` | `0` | piso da quantidade |
| `maxQuantity` | — | teto configurado (ex.: 4 peças por transferência) |

- O teto efetivo é o menor entre o estoque da origem e `maxQuantity` (`transferLimits`). Estoque sem leitura não vira zero: vale só o teto configurado.
- Origem zerada: faixa 0–0, os dois botões desabilitados e "A origem não tem estoque: não há peças para transferir."
- Nos limites, "−" e "+" ficam desabilitados e o motivo aparece em texto, sob os controles: "Máximo: 4 peças por transferência.", "Máximo: 3 peças, todo o estoque da origem.", "Mínimo: 1 peça." Fora deles, a faixa: "De 1 a 4 peças por transferência." O texto descreve o campo (`aria-describedby`) e é anunciado (`aria-live`). Textos em `messages`: `quantityRange`, `quantityAtMax`, `quantityAtMin`, `originEmpty`.
- Fora da faixa (ex.: outra origem com menos estoque), a quantidade volta ao limite por `onQuantityChange`. `clampTransferQuantity(quantidade, limites)` aplica a mesma regra fora do componente.
- `messages.pieces(valor, quantidade)` escolhe singular ou plural ("1 peça", "2 peças").

## Idioma do passo (0.5.0-rc.2)

Os nomes dos botões do passo ("Diminuir a quantidade", "Aumentar a quantidade") e os números do campo seguem o `locale` do widget (padrão `pt-BR`), nunca o idioma do navegador. Textos em `messages.decrease` e `messages.increase`.

## Textos do cliente (0.5.0-rc.2)

- `StockGrid.legend`: troca a legenda dos sinais da grade (padrão: `messages.stockLegend`), ex.: "Zero = estoque zerado…".
- `StockGrid.note`: nota persistente sob a legenda, ex.: de onde vem a cobertura.
- `note` no `TransferSimulator` e no `TransferSimulatorDialog`: nota persistente no rodapé, depois do aviso "Não movimenta estoque…", que continua.

## Dados (contrato com Bases)

Linhas planas, uma por unidade × tamanho, lidas por `stockFromRecords(rows, mapping, ordemDosTamanhos?)`:

| Campo do mapeamento | Exemplo | Regra |
|---|---|---|
| `unit` | `"loja"` | id da unidade |
| `unitLabel` | `"nome"` | rótulo (padrão: o id) |
| `size` | `"tamanho"` | coluna da grade |
| `quantity` | `"quantidade"` | `toMetricValue`: `null`, vazio e texto inválido = **sem leitura**, nunca zero |
| `weeklySales` | `"vendaSemanal"` | venda média semanal; sem ela, a cobertura fica `—` |

Cobertura = soma dos tamanhos lidos ÷ venda semanal (`coverageWeeks`). Sem venda conhecida, não há cobertura inventada.

`simulateTransfer(origem, destino, quantidade, minimoDeSemanas?)` é pura: devolve antes/depois das duas pontas e avisos (`exceeds-stock`, `origin-below-minimum`, `same-unit`, `unknown-stock`).

`ruptureSizes(unidade, tamanhos)` devolve os tamanhos zerados na ordem da grade. Sem leitura não é ruptura.

## Container estreito

Abaixo de 560 px **de container** (não de tela), a grade cortaria tamanhos e a cobertura. Ela vira uma lista por unidade:

- nome da unidade e cobertura em semanas (com ↓ abaixo de `minCoverageWeeks`);
- só os tamanhos em ruptura, em texto: "Ruptura: 38, 42" (ou "Sem ruptura");
- "Ver grade" abre a linha completa da unidade, com os mesmos destaques da grade.

A grade continua acima de 560 px. Textos novos em `messages`: `rupture`, `noRupture`, `showGrid` e `hideGrid`.

## Estados

Carregando, vazio, erro (com "Tentar de novo") e parcial (nota visível). Desatualizado vem de `updatedAt` + `staleAfterMs` ou do `PageContextProvider`.

## Acessibilidade

- Zero: cor, listras, borda, peso e "(zerado)" para leitor de tela. Sem leitura: traço tracejado e "Sem leitura".
- Acima de 560 px, se ainda faltar espaço, a grade rola na horizontal; a área de rolagem recebe foco.
- Na lista, "Ver grade" é um botão com `aria-expanded`; o nome acessível inclui a unidade ("Ver grade · Loja 01").
- Simulador: seleções em pílula (React Aria), quantidade com `NumberField` (setas do teclado; nomes do passo no `locale` do widget), motivo dos limites em texto, resultado em região `aria-live`.
- Simulador sob demanda: diálogo com nome (o título), foco preso enquanto aberto e devolvido ao botão ao fechar.

## Movimento

Dentro de um workspace, a cobertura conta até o valor na vez das tabelas.
