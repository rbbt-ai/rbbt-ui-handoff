# Mapa de calor (`Heatmap`, 0.5.0-rc.3)

Concentração de uma métrica em dois eixos. **Quanto mais concentração, mais quente a célula.**
O padrão é dia da semana × hora; o mesmo widget serve para loja × dia e semana × dia, só mudando os dados.

## Dados

```ts
interface HeatmapData {
  x: HeatmapCategory[];          // colunas, já ordenadas (ex.: Dom–Sáb)
  y: HeatmapCategory[];          // linhas, já ordenadas (ex.: 10h–21h, lojas, semanas)
  cells: { x: string; y: string; value: number | null }[];
}
interface HeatmapCategory { id: string; label: string; short?: string }
```

- **Ausência nunca vira zero.** `value: null`, texto inválido ou par `x`×`y` sem célula = *sem leitura*:
  contorno tracejado, fora das faixas, fora do total, "Sem leitura" no balão, na tabela e no nome acessível.
  Zero é leitura: entra na faixa mais fria e vale 0% do total.
- **% do total** = valor da célula ÷ soma das leituras do recorte exibido.
- **Métrica**: `metrics` (id, rótulo e `ValueFormat`) com `metric` e `onMetricChange` controlados. O consumidor
  passa os `data` da métrica atual. Uma métrica só → sem seletor.
- **Contexto visível**: `period` e `scope` (ex.: "20–26/10 · 18 de 20 lojas") no topo; `source` no rodapé, sempre
  (`provenance: "always"` por padrão).

### Adaptadores

- `heatmapFromRecords(rows, { x, y, value, xLabel?, yLabel?, xOrder?, yOrder?, aggregate? })`: linhas de uma
  view de Bases ou `reader.rows("…")` de um cenário pronto. Campos por nome ou caminho com pontos
  (`metricas.receita`), número pela regra de `toMetricValue` ("1.234,50" → 1234,5), repetidos somados (`sum`,
  `mean` ou `last`).
- `heatmapFromMatrix({ x, y, values })`: matriz já agregada (`values[linha][coluna]`) de um JSON de cenário.
- Eixos prontos: `weekdayCategories(locale, { start })` e `hourCategories(de, até, locale)`.

## Escala e faixas

- 4 ou 5 faixas (`scale`), das mais frias às mais quentes, nos tokens `--rb-heat-1` … `--rb-heat-5`.
- **Regra de corte padrão: quantis** das leituras, com a faixa mais quente nos **10% maiores**
  (5 faixas: 30 · 25 · 20 · 15 · 10%; 4 faixas: 35 · 30 · 25 · 10%). Faixas iguais de 20% deixavam um quinto da
  grade "em brasa" e escondiam a concentração. Limites arredondados a 2 algarismos; repetidos se fundem.
- **Limites fixos** por configuração: `scale={{ method: "fixed", thresholds: [2000, 4000, 6000, 8000] }}`.
- A legenda mostra os limites com Intl (compacto): `< R$ 4,4 mil`, `≥ R$ 4,4 mil`, … A mais quente vem em negrito.
- As duas faixas mais frias têm **hachura** (densa e espaçada): a leitura não depende só de cor.
- A mais quente tem destaque luminoso (`--rb-heat-glow`, anel `--rb-heat-ring` no escuro).

| Token | Uso |
| --- | --- |
| `--rb-heat-1` … `--rb-heat-5` | Cores das faixas (cliente pode trocar: `heat1`…`heat5` no `RbClientTheme`) |
| `--rb-heat-hatch` | Traço da hachura |
| `--rb-heat-glow`, `--rb-heat-ring` | Brilho e anel da faixa mais quente |
| `--rb-heat-absent` | Tracejado da ausência |
| `--rb-heat-label-active` | Fundo dos rótulos de linha e coluna em destaque |
| `--rb-heat-hover-in` / `--rb-heat-hover-out` | 150 ms / 110 ms (zeram com movimento reduzido) |
| `--rb-heat-hover-scale` | 1,06 |
| `--rb-heat-dim` / `--rb-heat-fade` | Recuo das outras células: escuro `brightness(0,75)` (25% mais escuras); claro opacidade 0,5 |
| `--rb-heat-hover-ease` | `cubic-bezier(0.22, 1, 0.36, 1)` (ease-out) |

## Interação

- **Hover, foco do teclado ou tap** acendem a mesma "mira":
  - a célula sobe (escala 1,06) com halo na cor da própria faixa: sombra curta no Smooth, brilho discreto no Glass;
  - as outras células recuam (25% mais escuras no escuro; no claro, opacidade 0,5, porque escurecer cores claras
    deixava a grade turva);
  - os rótulos do dia e da hora correspondentes ficam em destaque;
  - o balão aparece junto, sem atraso: dia · hora, valor exato, **% do total**, faixa e contexto.
- Tempo: entrada 150 ms ease-out, saída 110 ms, com Motion e os tokens acima, relidos a cada interação.
- **Movimento reduzido**: sem escala, sem recuo e sem animação; só contorno na célula e rótulos em destaque.
- **Toque**: o tap faz o mesmo; tocar fora da grade fecha. **Esc** fecha pelo teclado.

## Acessibilidade

- `role="grid"` com nome ("Concentração de vendas: Hora × Dia"), cabeçalhos de coluna e de linha, tabindex móvel
  (uma célula na ordem de Tab) e setas, Home/End (linha) e Ctrl+Home/End (grade).
- Nome de cada célula: "Sábado, 19h: R$ 14.328, 2,9% do total, faixa 5 de 5, mais quente".
- **Ver tabela**: alternância visível com a mesma informação em `<table>` (ausência por extenso e total).
- O balão é visual (`aria-hidden`): o leitor de tela já recebe tudo no nome da célula.

## Movimento de entrada

- Entrada na página, troca de módulo ou entrada na tela: as células acendem em **cascata** diagonal
  (`--rb-duration-enter`, `--rb-duration-stagger`, até 12 passos).
- **Troca de métrica ou de filtro**: cada célula vai da cor da faixa antiga à nova, **sem cascata e sem voltar a zero**.
- Movimento reduzido: estado final direto.

## Estados

Carregando (esqueleto com a geometria da grade), vazio (nenhuma leitura no recorte), erro (com "Tentar
novamente"), sem permissão, parcial (aviso visível) e desatualizado, pela moldura comum (`Panel`). O seletor de
métrica continua visível em todos os estados.

## Layout

- O widget segue o container. Até ~480 px de largura: células e espaços compactos, rótulos curtos.
- A 360 px, dia × hora e loja × dia cabem sem rolagem; se faltar espaço (muitas colunas), a rolagem é **só dentro
  do widget**, com os rótulos de linha fixos. A página nunca rola na horizontal.

## Por que DOM e não ECharts

O heatmap do ECharts desenha em canvas: foco por célula, nome acessível, hachura por faixa, raio e brilho por token
e a tabela alternativa ficariam fora do componente ou exigiriam camadas paralelas. A grade em DOM dá células
focáveis de verdade, hachura em CSS, tokens diretos, Motion pelas mesmas regras dos outros widgets e layout por
container, sem biblioteca nova.
