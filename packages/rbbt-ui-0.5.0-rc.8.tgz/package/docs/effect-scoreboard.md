# Placar de efeito da ação (`EffectScoreboard`)

**Desde 0.5.0-rc.7 (Lote 4).** Mostra se um indicador mudou depois de uma ação: **antes → meta → depois**, com a
**janela de avaliação explícita** (datas e duração), o estado próprio do placar, o resultado em valor e em %, a
polaridade declarada e, quando houver, a diferença contra um grupo de comparação. Um minigráfico em SVG próprio
marca o dia da ação e a janela; a tabela é a alternativa em texto. A conta inteira abre no painel "Ver a conta".

> **Ressalva sempre visível:** "Melhora depois da ação não prova que a ação causou a melhora." Ela aparece no
> corpo, nos estados gerais (carregando, vazio, erro) e dentro do painel da conta. Não há prop para escondê-la.

## Uso

```tsx
import { EffectScoreboard, effectFromSeries } from "@rbbt/ui";

const data = effectFromSeries(linhas, {
  getDay: (r) => r.dia,
  getValue: (r) => r.conversao,
  actionDay: "2026-10-13",
  windowDays: 14, // avaliação: 13/10 a 26/10
  baselineDays: 14, // antes: 29/09 a 12/10 (padrão: windowDays)
  target: 0.21,
  comparison: { label: "8 lojas sem a vitrine", records: linhasDoGrupo },
});

<EffectScoreboard
  title="Efeito da vitrine de outono"
  actionLabel="Vitrine de outono nas lojas da Zona Oeste"
  metricLabel="Conversão"
  polarity="higher-is-better"
  valueFormat={{ style: "percent", maximumFractionDigits: 1 }}
  data={data}
  scope="4 lojas da Zona Oeste"
  source="ERP · conversão = vendas ÷ visitas"
  actions={[{ id: "propor", label: "Propor nas outras lojas", primary: true, onAction: propor }]}
/>;
```

## Dados

| Campo | Tipo | Regra |
| --- | --- | --- |
| `points` | `{ day, value }[]` | Série diária de quem recebeu a ação. `null`, `NaN`, infinito **ou dia sem item** = ausência. Zero é leitura. |
| `actionDay` | dia ISO | D0, marcado no minigráfico ("Ação · 13/10"). |
| `before` / `after` | `{ start, end }` | Janelas fechadas (início e fim inclusos). `after` é a janela de avaliação. |
| `target` | `number \| null` | Meta na janela de avaliação, na unidade do valor. Sem meta: célula "—" com "sem meta". |
| `comparison` | `{ label, points }` | Grupo de comparação nas mesmas janelas (opcional). |

**Adaptador.** `effectFromSeries(records, options)` lê linhas de uma view de Bases, de um cenário ou de uma API
pela mesma regra de `adapters/series.ts`: valor por `toMetricValue` ("1.234,5" vira número; vazio, `null` e texto
inválido viram ausência, nunca zero) e dia por `toIsoDay` (ISO, dd/mm/aaaa ou série do Excel). Cada dia das duas
janelas sai na lista, com `null` quando não houver leitura; registros fora das janelas ficam de fora. Registros
repetidos no mesmo dia: `aggregate: "sum"` (padrão; se um deles não tem leitura, o dia inteiro fica sem leitura,
porque a soma parcial subestima o dia), `"mean"` ou `"last"`.

## A conta

- **Médias** de antes e de depois só com os dias que têm leitura. Dia sem leitura fica fora da média e é contado
  como ausência (aparece no painel da conta e como lacuna na curva). **Ausência nunca vira zero.**
- **Hoje não conta:** o dia de hoje ainda não terminou; a janela aberta conta até ontem.
- **Mínimo de leituras:** `minDays` (padrão 7, uma semana, limitado à duração da janela) em cada janela. Sem o
  mínimo, o lado mostra "—" e "n de 7 dias mínimos", nunca uma média pouco confiável.
- **Resultado:** depois − antes, na unidade do valor; em % = (depois − antes) ÷ |antes|. Com
  `valueFormat.style: "percent"`, a diferença sai em pontos percentuais ("+2,1 p.p.") e a variação relativa em %
  ("+11,6%"). Antes = 0: só o valor (sem %).
- **Meta:** depois − meta. "Meta atingida" ou "Faltam 0,7 p.p. para a meta", pela polaridade.
- **Grupo de comparação:** variação do grupo nas mesmas janelas e a **diferença** variação da ação − variação do
  grupo ("+1,7 p.p. acima do grupo de comparação"). Sem leituras suficientes no grupo, a linha diz isso.

## Estados

| Estado | Quando | O que aparece |
| --- | --- | --- |
| `evaluating` · em avaliação | `today` ≤ fim da janela de avaliação | Chip "Em avaliação", "9 de 14 dias · faltam 5", depois rotulado "Depois · parcial" e o resultado com o selo "parcial, não final". Antes de `minDays` leituras depois, o texto diz quantas faltam. |
| `insufficient` · dados insuficientes | Antes com menos de `minDays` leituras, ou depois sem como chegar ao mínimo | Chip "Dados insuficientes" e qual lado faltou, com as contagens. Sem número de resultado. |
| `concluded` · concluído | Janela encerrada com leituras suficientes dos dois lados | Chip "Concluído", "encerrada em 26/10/2026", resultado final. |

Os estados gerais vêm do `useWidgetFrame`: `status="loading" | "empty" | "error" | "partial" | "stale" | "restricted"`.
Sem nenhuma leitura nas janelas, o widget cai no estado vazio. Em todos, a ressalva continua visível.

## Polaridade

Declarada como nas barras divergentes: `higher-is-better` (padrão), `lower-is-better` ou `neutral`. Ela aparece
escrita ao lado de "Resultado" ("Maior é melhor") e define o tom do resultado, da meta e da diferença contra o
grupo. O tom sempre tem texto ("favorável", "desfavorável", "sem juízo", "sem variação"), nunca só cor.

## Minigráfico e tabela

- SVG próprio, sem biblioteca. Faixa da janela de avaliação, linha do D0 com o rótulo "Ação · 13/10", linha da meta
  na janela de avaliação, médias de cada janela e o grupo de comparação tracejado.
- **Dia sem leitura quebra a curva** (lacuna); um dia isolado entre lacunas vira ponto. A legenda inclui "Sem
  leitura: lacuna" quando houver ausência.
- A tabela ("Ver tabela") lista um dia por linha com a janela, a leitura ("sem leitura", "por vir") e o grupo, e
  as médias no rodapé. O SVG tem texto alternativo com antes, depois, meta e dias sem leitura.

## Painel da conta ("Ver a conta")

`DetailPanel` com foco preso, `Esc` fecha e o foco volta ao botão. Mostra cada média com o período e as
ausências, as fórmulas (depois − antes, em %, depois − meta, variação do grupo, diferença), as regras e a ressalva.
Controlado por `detailOpen` / `onDetailOpenChange`, ou não controlado.

## Ações

Só por callback (`onAction`) ou link (`href`). O componente não grava nada, não usa `localStorage` e não chama
rede. Sem permissão: `disabledReason` deixa o botão desabilitado e o motivo visível ao lado, nunca escondido.

## Motion

Cascata só na entrada (antes, meta, depois, resultado; a curva se desenha). Na troca de dados ou de filtro, os
números e a curva vão do valor antigo ao novo, interpolados pelo Motion; ausência troca na hora, sem passar por zero;
troca no meio continua do valor que está na tela, e a animação para no unmount. Com `prefers-reduced-motion`, tudo
aparece no estado final, sem deslocamento.

## Contexto sempre visível

Período (prop `period`; sem ela, o intervalo das duas janelas), lojas (`scope`) no topo e origem (`source`) no
rodapé (`provenance: "always"`).

## Props principais

| Prop | Padrão | Nota |
| --- | --- | --- |
| `title` | — | Título visível e nome da região. |
| `data` | — | `EffectScoreboardData`; `null` ou sem leitura → vazio. |
| `actionLabel`, `metricLabel` | — / "Indicador" | Ação avaliada e nome do indicador. |
| `polarity` | `higher-is-better` | Polaridade declarada. |
| `valueFormat` | número | `percent` → diferenças em p.p. |
| `minDays` | 7 | Mínimo de dias com leitura em cada janela. |
| `today` | data local | Define se a janela está aberta (use fixo em testes). |
| `period`, `scope`, `source` | — | Contexto visível. |
| `actions` | — | `EffectAction[]` por callback; `disabledReason` sem permissão. |
| `view` / `defaultView` / `onViewChange` | `chart` | Minigráfico ou tabela. |
| `detailOpen` / `onDetailOpenChange` | — | Painel da conta. |
| `messages` | pt-BR / en-US | Textos sobrescrevíveis (a ressalva também, para traduzir). |

## Funções puras

`buildEffect(data, { today, polarity, minDays })` devolve o modelo inteiro (estado, lados medidos, resultado,
meta, grupo, dias e domínio) sem DOM. `effectReading`, `effectTone`, `effectWindowDays`, `effectToday` e
`effectY` são auxiliares exportados.
