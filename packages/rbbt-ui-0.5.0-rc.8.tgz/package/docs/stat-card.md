# StatCard (0.3.0-rc.3)

Card de estatísticas "estilo card de jogador": a posição, o número principal, uma fileira de estatísticas como PTS/REB/AST e a forma recente, como os últimos jogos de um atleta (valor × referência nos últimos dias). Serve para loja, vendedor, agente ou produto: identidade, textos e regras ficam com quem usa.

Genérico: dados e textos chegam já formatados (Intl); o card não faz chamadas de rede e não conhece cliente. Versão: `0.3.0-rc.3`. Dependências: React 19, React Aria Components (o botão) e Lucide (as setas da variação e a seta da arte). Reaproveita `ProgressRing`, `StatusDot`, `Figure` e `Skeleton`.

Três anatomias, pela prop `variant`:

- **`smooth`** (padrão desde a 0.3.0-rc.3): card de raio 24 px com sombra suave, ícone num círculo, número com a pílula de variação colada e a linha "Rótulo: valor", até 3 estatísticas em mini-blocos, forma em barras-pílula e no máximo um selo. `featured` pinta o primeiro de um ranking em gradiente.
- **`plain`** (0.3.0-rc.3): enxuta. Cabeçalho leve, um número, até 3 estatísticas numa fileira, forma sem moldura e no máximo um selo. Com os mesmos dados, todos os cards de uma grade ficam com a mesma altura e os números alinhados.
- **`art`** (a anatomia da 0.3.0-rc.2): arte em gradiente no topo com posição grande e emblema, anel, grade de 4 a 6 estatísticas com legendas, forma recente com título e eixo, vários selos.

```tsx
import { StatCard } from "@rbbt/ui";
import "@rbbt/ui/styles.css";
import { Store } from "lucide-react";

<StatCard
  id="loja-04"
  title="Unidade Centro 04"
  rank={{ value: 1, of: 12, label: "atingimento" }}
  emblem={<Store />}
  overline="Região Sul"
  subtitle="loja de rua"
  status={{ label: "Acima da meta", tone: "positive" }}
  primary={{
    label: "Atingimento",
    value: "108,4%",
    delta: { text: "R$ 18,2 mil", direction: "up", tone: "positive", srLabel: "+R$ 18,2 mil vs meta" },
    baseline: { label: "Meta até 15/10", value: "R$ 216,7 mil" },
  }}
  stats={[
    { id: "venda", label: "Venda", value: "R$ 236 mil", srLabel: "Venda líquida até 17/10: R$ 236,4 mil" },
    { id: "evolucao", label: "Evolução", value: "+6,2%", tone: "positive" },
    { id: "ticket", label: "Ticket", value: "R$ 184" },
  ]}
  form={{ label: "Forma recente", caption: "venda × meta, últimos 10 dias", referenceLabel: "meta", points }}
  onOpen={() => abrirDetalhe("loja-04")}
/>
```

## Anatomia `plain`

Ritmo fixo: padding de 20 px e 16 px entre blocos.

1. **Cabeçalho leve**, na própria superfície: o título e, à direita, a posição num selo neutro e pequeno ("#1"; sem posição, "—"). Embaixo, uma linha com `overline · subtitle` ("Região Sul · loja de rua") e o status em ponto + texto à direita. Sem emblema e sem seta: o card inteiro abre o detalhe.
2. **Um número principal** de 30 px, peso 500, com decimais, moeda e unidade apagados. Com `ratio`, uma barra fina de 4 px (cheia acima de 1; só o trilho com `null`). Uma linha de apoio curta ("+R$ 7,0 mil vs meta").
3. **Até 3 estatísticas numa fileira**: rótulo curto de uma linha (12 px) e valor de 15 px com números tabulares, todos na mesma linha de base. Colunas iguais quando cabem; se a soma não couber, a última desce para a linha de baixo, sem rolagem lateral. Sem legendas: o período fica no contexto da página e o complemento vai para o `srLabel`.
4. **Forma recente sem moldura**: barras finas e a referência como uma linha sutil atrás delas. Sem título, eixo ou legenda visíveis (ficam para leitor de tela). Embaixo, só o resumo curto ("7/10 dias na meta").
5. **Pé**: o resumo à esquerda e no máximo um selo à direita, sempre no mesmo lugar. A altura do pé é reservada, com ou sem selo. Se vierem vários selos, aparece só o primeiro: ordene por prioridade.

## Anatomia `art`

1. **Arte** (topo, gradiente por tokens): posição grande (`#03`) com "de 12 · critério", emblema (monograma, número, ícone ou logo, decorativo), título, sobrelinha · subtítulo e o status em pílula.
2. **Número principal**: anel (`ratio`) ou número grande, com uma linha de apoio.
3. **Estatísticas**: rótulo pequeno em maiúsculas e valor de 19 px, em duas colunas (três a partir de 25 rem de card), com `note` embaixo. Linhas comuns: um rótulo que quebra não desalinha os valores.
4. **Forma recente**: título, barras e traço da referência, eixo com as datas e resumo ("7 de 9 dias na meta ou acima · 1 sem dados").
5. **Selos** de exceção, todos.

## Props

| Prop | Tipo | Notas |
| --- | --- | --- |
| `variant` | `"plain" \| "art"` | Padrão `plain`. |
| `title` | `string` | Obrigatória. Nome do item: título do card e nome do botão. |
| `headingLevel` | `2 \| 3 \| 4` | Padrão 3. |
| `id` | `string` | Id do botão. O foco volta para ele quando o detalhe fecha (`DetailPanel.returnFocusId`). |
| `onOpen` | `() => void` | Abre o detalhe. Sem ela, o card é estático (sem botão). |
| `opensDialog` | `boolean` | Padrão `true` (`aria-haspopup="dialog"`). `false` quando leva a outra tela. |
| `srExtra` | `string` | Descrição do botão para leitor de tela, fora do nome (padrão "abrir o detalhe"). |
| `rank` | `{ value: number \| null; of?: number; label?: string }` | Posição na lista ordenada. `value: null` = sem posição ("—"). No `plain`, "#1" num selo; no `art`, "#01 de 12 · critério". |
| `emblem` | `ReactNode` | Só no `art`. Texto curto vira monograma; aceita ícone ou logo. Decorativo. |
| `overline`, `subtitle` | `ReactNode` | Grupo/bloco e tipo/papel. |
| `status` | `{ label; tone?; srLabel? }` | Tons do `StatusDot`. |
| `primary` | `StatCardPrimary` | Ver abaixo. |
| `stats` | `StatCardStat[]` | `plain`: até 3. `art`: 4 a 6. `id`, `label`, `value` (`null` = "—", lido "sem valor"), `note` (só no `art`), `tone`, `srLabel`. |
| `form` | `StatCardForm` | Ver abaixo. |
| `badges` | `StatCardBadge[]` | `id`, `label`, `tone` (com tom ganha um ponto), `srLabel`. O `plain` mostra só o primeiro. |
| `highlighted` | `boolean` | Contorno de destaque (ex.: o item em foco na página). |
| `loading` | `boolean` | Esqueleto da mesma anatomia, `aria-busy`, sem botão. |
| `locale` | `string` | Textos padrão e algarismos da posição. Padrão `pt-BR` (há `en-US`). |
| `messages` | `Partial<StatCardMessages>` | Substitui qualquer texto padrão. |
| `className`, `data-*` | | Composição de quem usa. |

### `primary`

| Campo | Tipo | Notas |
| --- | --- | --- |
| `label` | `string` | Rótulo curto (ex.: "Atingimento"). |
| `value` | `string \| null` | Texto formatado. `null` = "—" e `absentText` no lugar do apoio. |
| `ratio` | `number \| null` | Barra fina (`plain`) ou anel (`art`): 0,79 = 79%; acima de 1 fica cheio e o texto diz o valor. `null` = só o trilho. Ausente = só o número. |
| `ringTone` | `GaugeTone` | Tom da barra ou do anel. Padrão `accent`. No `plain`, prefira uma cor só para todos os cards: o status em texto já diz a faixa. |
| `valueTone`, `supportTone` | `StatCardTone` | Só quando o sinal tem sentido. Âmbar não pinta número. |
| `support` | `string` | Uma linha de apoio (ex.: "−R$ 73,2 mil vs meta"). |
| `absentText` | `string` | Ex.: "sem leitura comparável", "sem meta no mês". |

### `form`

| Campo | Tipo | Notas |
| --- | --- | --- |
| `label`, `caption` | `string` | Título curto e complemento. No `plain`, só para leitor de tela. |
| `points` | `StatCardFormPoint[]` | `id`, `label` ("15/10"), `value`, `reference`, `state`, `valueText`, `referenceText`. Dias futuros não entram. |
| `polarity` | `"higher-is-better" \| "lower-is-better"` | Padrão `higher-is-better`. Para tempo de resposta, custo ou atraso, use `lower-is-better`. |
| `referenceLabel` | `string` | Nome da referência nos textos (padrão "referência"). |
| `summary` | `string` | Resumo próprio; sem ele o card conta os dias ("7/10 dias na meta" no `plain`). |

Situação do dia (`state`): `ok`, `partial` (hachura sobre a barra), `missing` (sem dados: anel vazio no zero, sem barra) e `closed` (sem operação: coluna hachurada, sem barra e sem referência). Sem `state`, um dia sem valor válido (`null`, `NaN`, infinito) é `missing`. **Ausência e dia fechado nunca viram zero**; zero é zero (marca de 2 px no zero) e negativo desce a partir de um zero comum.

Os textos padrão em pt-BR tratam a referência como palavra feminina ("na meta", "abaixo da meta", "sem meta diária"). Para um nome masculino ("alvo", "limite"), passe `messages.formSummaryShort`, `formSummary`, `formDayMeets` e `formDayMisses`.

## Acessibilidade

- `<article>` nomeado pelo título. O único botão fica no título e se estica sobre o card inteiro. O nome do botão é o próprio título (curto, igual ao texto visível, WCAG 2.5.3); a ação ("abrir o detalhe") é a descrição, e o cabeçalho continua só com o nome na navegação por títulos. Nada de outros botões ou links dentro.
- Posição, status, selos e ausências têm texto para leitor de tela ("Posição 3 de 12 em atingimento", "sem valor"). Estatísticas são uma lista de definição; no `plain`, o `srLabel` devolve o complemento que saiu da tela.
- A forma recente é uma `figure` com legenda; o desenho é decorativo, cada dia é lido em texto ("13/10: R$ 4,1 mil; meta R$ 5,5 mil; abaixo da meta") e o resumo visível descreve a figura.
- Foco visível no contorno do card. Hover levanta 2 px; com `prefers-reduced-motion` não há deslocamento nem transição.
- `art`: texto da arte em `--rb-on-art` / `--rb-on-art-muted` com contraste de pelo menos 4,5:1 sobre o gradiente nos dois modos.

## Tokens

`plain`: os tokens v3 de superfície, texto, tons, `accent` (barra e dias na referência), `bar`, `barMuted`, `neutralSoft` (selos), `radiusCard` e `shadowCard`. `art`: também `artFrom`, `artTo` (gradiente), `onArt` e `onArtMuted`.

## Limites

- `plain`: pensado para 17,5 rem (280 px) ou mais; em grade, `repeat(auto-fill, minmax(17.5rem, 1fr))` com 20 px de espaço. De 15 rem a 17,5 rem os valores ficam em 14 px; abaixo de 13 rem de conteúdo as estatísticas viram lista.
- `plain`, alinhamento entre cards: título, a linha "tipo · status" e os rótulos precisam caber numa linha (cerca de 34 caracteres para tipo + status em 280 px). Se um card quebrar uma linha, ele cresce e o número dele desce em relação aos vizinhos; encurte o texto na configuração.
- `art`: de 15 rem (240 px) a cerca de 26 rem; abaixo de 16,5 rem o card aperta margens e números; a partir de 25 rem a grade passa a três colunas.
- Altura: ocupa a altura da linha da grade (`height: 100%`); a forma e o pé vão para baixo.
- Forma recente: 5 a 14 dias leem bem; acima disso as colunas ficam finas demais.
- Texto longo quebra (`overflow-wrap: anywhere`), sem rolagem lateral.

## Funções puras

`formPointState`, `classifyFormPoint`, `countForm`, `formGeometry` e `formatRank` estão exportadas para testes e para quem precisar do mesmo cálculo fora do card.
