# ComparisonTable — contrato

Versão do pacote: `@rbbt/ui@0.2.0-rc.2` · estado: **candidato para revisão visual** (não aprovado). Adições do rc.2 marcadas com (rc.2); sem elas, a tabela é a do 0.2.0-rc.1.

Tabela comparável e ranking de unidades (lojas, equipes, regiões…): ordenação com critério sempre visível, números tabulares alinhados, situação por linha, grupos com subtotal, total conferido, cartões em containers estreitos e exportação CSV do recorte. Usa TanStack Table v9 para o estado de ordenação.

```tsx
import { ComparisonTable, type ComparisonColumn } from "@rbbt/ui";

const columns: ComparisonColumn[] = [
  { id: "venda", header: "Venda líquida", format: { style: "currency", currency: "BRL", notation: "standard", maximumFractionDigits: 0 }, aggregate: "sum", emphasis: "primary" },
  { id: "diferenca", header: "Dif. vs meta", format: { style: "currency", currency: "BRL", notation: "standard", maximumFractionDigits: 0 }, aggregate: "sum", signed: true, polarity: "higher-is-better" },
  { id: "atingimento", header: "Atingimento", format: { style: "percent", maximumFractionDigits: 1 } },
];

<ComparisonTable
  title="Comparação das unidades"
  rowHeader="Unidade"
  columns={columns}
  data={{ rows, groups, total }}
  presets={[{ id: "venda", label: "Maiores vendas", columnId: "venda", direction: "desc", criterion: "venda líquida, da maior para a menor" }]}
  export={{ filename: "comparacao", scope: "Rede · Outubro 2026, até 16/10" }}
  onRowAction={(row) => abrirDetalhe(row.id)}
/>;
```

Mantenha `columns` estável (constante ou `useMemo`): o TanStack recalcula modelos quando a referência muda.

## Dados de entrada (`data`)

| Campo | Significado |
| --- | --- |
| `rows[]` | `{ id, label, sublabel?, group?, values, cellText?, status?, highlight?, actionDisabledReason? }`. `values[col]`: `0` é zero; `null`/ausente mostra `cellText[col]` ou `emptyText` (ex.: "sem meta"), nunca zero. |
| `rows[].status[]` | Selos `{ label, tone?, description? }` (ex.: "Parcial", "Sem meta", "Evento"). Texto + tom, nunca só cor. |
| `groups[]` | `{ id, label, description?, totals?, cellText? }`. Subtotal informado pela fonte; colunas `sum` sem valor são somadas pelo widget. |
| `total` | `{ label, description?, values?, cellText? }`. Mesma regra. |

Colunas **não aditivas** (percentuais, médias) só têm subtotal/total quando a fonte informa — o widget nunca soma percentuais.

## Colunas (`columns`)

| Campo | Descrição |
| --- | --- |
| `id`, `header`, `shortHeader?` | Identificador, cabeçalho e rótulo curto dos cartões. |
| `format` | `ValueFormat` do pacote. Use `notation: "standard"` quando o número exato importa. Na notação compacta (0.5.0-rc.2), as células da coluna, os subtotais e o total nunca caem no mesmo texto para valores diferentes e saem com as mesmas casas (até 2); regra em [trend-indicator.md](trend-indicator.md). |
| `aggregate` | `sum` (aditiva: soma e confere) ou `none` (padrão). |
| `signed`, `polarity` | Sinal em valores ≠ 0 e juízo pelo sinal (cor + sinal). |
| `sortable` | Padrão `true`. |
| `emptyText`, `emphasis`, `description` | Texto de ausência, destaque no cartão e explicação (título do cabeçalho e exportação). |
| `group` (rc.2) | Id de um `columnGroups[]`: colunas vizinhas do mesmo grupo ganham cabeçalho comum (`th scope="colgroup"`) e divisor. Use quando blocos têm datas ou universos diferentes, ex.: "Mês até 17/10" \| "Comparação com a meta até 15/10". |
| `derived` (rc.2) | `{ kind: "difference" \| "ratio" \| "change", of: [a, b] }`: a conta que a coluna representa (`a − b`, `a ÷ b`, `(a − b) ÷ b`). O widget confere a conta em cada linha, subtotal e total; células sem um dos valores (ex.: "sem meta") ficam fora. |
| `cell` (0.5.0-rc.5) | `(ctx: ComparisonCellContext) => ReactNode`: renderizador visual da célula, **aditivo e compatível** (sem ele, nada muda). Recebe `{ value, values, column, row?, kind: "row" \| "subtotal" \| "total", layout: "table" \| "card", text, absent, locale }`. O valor numérico `values[column.id]` continua valendo para a ordenação, o CSV, a conferência de `derived` e o leitor de tela: a célula mantém o texto padrão (`text`) para tecnologias assistivas e põe o desenho em `aria-hidden`. Vale também nos cartões (< `cardBreakpoint`), onde a métrica ocupa a largura do cartão. Devolver `null`/`undefined` cai no texto padrão. Helper pronto: `bulletColumnCell({ targetColumn, projectionColumn?, actualColumn?, max = 1.25 })` (meta × realizado, ver o contrato do BulletBar). |

### Conciliação por linha (rc.2)

Quando a comparação usa um corte diferente do resto da tabela, mostre na própria linha os dois lados da conta. Ex.: a venda do mês vai até 17/10, mas meta, diferença e atingimento vão até 15/10. Nesse caso, ponha "Realizado" (até 15/10) ao lado de "Meta" no grupo "Comparação com a meta até 15/10" e declare `derived` na diferença e no atingimento. O rodapé diz "Contas por linha conferem: Diferença = Realizado − Meta · Atingimento = Realizado ÷ Meta" ou aponta a coluna que não fecha. Nos cartões, cada grupo de várias colunas vira uma seção com o rótulo do grupo; colunas soltas ficam no topo com o `shortHeader` (ponha a data nele). No CSV, o rótulo do grupo entra no cabeçalho de cada coluna ("Comparação com a meta até 15/10 · Realizado (BRL)").

## Opções

| Prop | Padrão | Descrição |
| --- | --- | --- |
| `presets` | — | Atalhos `{ id, label, columnId, direction, criterion? }`. Até 3 viram controle segmentado no cabeçalho. Na anatomia `lean` ficam na pílula "Ordenar"; sem ordenação ativa, ela diz "Ordem da fonte". |
| `searchable` (0.4.0) | `true` | Busca em pílula no cabeçalho da anatomia `lean`. Desligue em tabelas curtas (ex.: 4 canais). |
| `sort` / `defaultSort` / `onSortChange` | 1º preset | Ordenação controlada ou inicial. Cabeçalhos também ordenam (`aria-sort`). |
| `grouped` | `true` com grupos | Agrupa com subtotais; a ordenação vale dentro de cada grupo. `false` = ranking único. |
| `cardBreakpoint` | `640` | Largura do **container** abaixo da qual cada linha vira cartão. |
| `verifyTotals` | `true` | Confere subtotais/total informados contra a soma das linhas (soma compensada; tolerância de meio centavo em moeda). Divergência aparece como aviso no rodapé. |
| `export` | — | `{ filename, scope, dataAsOf? }` habilita "Exportar CSV". |
| `columnGroups` (rc.2) | — | `{ id, label, description? }[]`, referenciados por `ComparisonColumn.group`. |
| `verifyDerived` (rc.2) | `true` | Confere as colunas com `derived` e mostra o resultado no rodapé. |
| `anatomy` (rc.2) | a do `PageContextProvider`, senão `full` | `lean`: ressalvas da moldura em linha e etiquetas da linha ao lado do nome. Mostre só as exceções, com rótulo curto; ausência que já aparece na célula (ex.: "sem meta") não precisa de etiqueta. |
| `provenance` (rc.2) | `inherit` | Dentro de um `PageContextProvider`, fonte e atualização iguais às da página saem do rodapé; o CSV continua levando a fonte. |
| estados e moldura | — | `status`, `scope`, `caveat`, `partialNote`, `description`, `methodology`, `source`, `updatedAt`, `staleAfterMs`, `now`, `messages`. |

## Ações e callbacks

- `onRowAction(row)` / `rowHref(row)`: o nome da linha vira link "Abrir {nome}" (navegação para detalhe; preserve os filtros na rota). `actionDisabledReason` mostra o motivo e desabilita.
- `onSortChange(sort)`, `onRetry()`.

## Exportação CSV

Na ordem exibida, com metadados: recorte, dados de (`dataAsOf`), atualização, **instante da exportação** e fonte; depois cabeçalho com unidade (`(BRL)`, `(%)`), linhas, subtotais e total. Valores **exatos** (sem milhar nem notação compacta; moeda com 2 casas; percentual em pontos). Ausência sai como texto, nunca zero. Delimitador `;` onde a vírgula é decimal (pt-BR), `,` nos demais; BOM UTF-8.

## Estados

`loading` (linhas esqueleto), `empty`, `error`, `restricted`, `partial`, `stale`, como nos demais widgets de painel.

## Limites de tamanho

- ≥ 640 px de container: tabela; entre 640 px e a largura natural, rola **dentro do card** (região focável), nunca a página.
- < 640 px: cartões com o valor `primary` em destaque e as demais métricas em duas colunas; ordenação por seletor.
- Pílula "Ordenar" (anatomia `lean`, 0.5.0-rc.2): o critério nunca é cortado. A pílula cresce até caber o texto ("Variação R$, do menor para o maior"); quando não cabe na linha, desce para a linha de baixo; só num contêiner mais estreito que o próprio texto ele quebra em duas linhas. Conferida em 1440, 1280 e 390 px.

## Acessibilidade

`table` com `caption`, `th scope`, `aria-sort`, grupos em `th scope="colgroup"`, total em `tfoot`. O botão de ordenação do cabeçalho tem como nome só o rótulo da coluna (é o que o leitor de tela repete em cada célula); o estado vem de `aria-sort`. Linha em destaque com barra lateral, peso maior e texto para leitores de tela. Foco visível em cabeçalhos, links e controles; toque de 44 px.

## Dependências

`@tanstack/react-table` 9.3.1 (`rowSortingFeature`, `createSortedRowModel`), `react-aria-components`, `lucide-react`.
