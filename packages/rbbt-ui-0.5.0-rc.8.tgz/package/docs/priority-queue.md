# Fila de prioridades v2 · contrato (0.5.0-rc.7, Lote 4)

Uma fila curta do que atacar primeiro. Cada item traz **impacto estimado em R$** (sempre rotulado
"estimado"), **urgência** (prazo ou janela), **confiança** (alta, média ou baixa, com o motivo) e
**responsável**. A ordem é transparente: a regra aparece no topo e cada item diz **por que está acima do
seguinte**. O item abre o `DetailPanel` com a evidência (links para a origem) e a conta do impacto e da
pontuação. DOM e SVG próprios. Cliente das histórias: Pedravela Calçados (fictício).

## Props

| Prop | Tipo | Padrão | Uso |
| --- | --- | --- | --- |
| `title` | `string` | — | Título visível; nomeia a região e a lista. |
| `items` | `PriorityQueueItem[] \| null` | — | Itens. `null` ou vazio → estado vazio. |
| `today` | `IsoDay` | dia de `now` | Referência da urgência (fixe nas demos para a ordem não mudar com o relógio). |
| `weights` | `Partial<{ impact, urgency, confidence }>` | `0,5 · 0,3 · 0,2` | Pesos da pontuação (valem pela proporção). |
| `horizonDays` | `number` | `30` | Prazo a esse número de dias ou mais vale urgência 0. |
| `sort`, `defaultSort`, `onSortChange` | `"score" \| "impact" \| "urgency" \| "confidence"` | `"score"` | Ordenação (controlada ou não). |
| `display`, `defaultDisplay`, `onDisplayChange` | `"list" \| "table"` | `"list"` | Fila ou tabela alternativa. |
| `impactFormat` | `ValueFormat` | BRL compacto | Formato padrão do impacto (o item pode trazer o seu). |
| `openItemId`, `defaultOpenItemId`, `onOpenItemChange` | `string \| null` | `null` | Item com o detalhe aberto (ex.: guardado na URL pelo app). |
| `onOpenItem` | `(item) => void` | — | O usuário abriu um item (clique, Enter ou Espaço). |
| `onCreateDecision`, `onAssign` | `(item) => void` | — | Ações do detalhe. Sem o callback, o botão não existe. |
| `permissions` | `{ createDecision?, assign? } \| (item) => …` | permitido | Sem permissão: botão **desabilitado com o motivo**, nunca escondido. |
| `period`, `scope` | `string` | — | Contexto visível no topo ("Semana 44 · 26/10–01/11 · 18 lojas"). |
| `source` | `string` | — | Origem, sempre no rodapé (e no subtítulo do detalhe). |
| `status`, `partialNote`, `onRetry` | — | `"ready"` | Carregando, vazio, parcial, erro (moldura comum). |
| `messages` | `Partial<PriorityQueueMessages>` | pt-BR | Qualquer texto sobrescrevível (en-US incluso). |

## Item

```ts
interface PriorityQueueItem {
  id: string;
  title: string;                       // o problema
  subject?: string;                    // loja, unidade ou produto
  impact?: { value: number | null; format?; basis?: string; missingReason?: string };
  urgency?: { due?: IsoDay; window?: { start: IsoDay; end: IsoDay }; label?: string };
  confidence?: { level: "high" | "medium" | "low"; reason: string };
  owner?: { id?: string; name: string } | null;
  evidence?: { label: string; value?: number | null; format?; href?: string; source?: string }[];
}
```

O mesmo formato é aceito pelo cartão de decisão (`decisionFromQueueItem`): criar uma decisão a partir do
item mantém o contexto.

## Pontuação (regra documentada e configurável)

`pontuação = peso_impacto × impacto + peso_urgência × urgência + peso_confiança × confiança`, em 0–100.

- **Pesos:** padrão `impacto 0,5 · urgência 0,3 · confiança 0,2`. Valem pela proporção (são normalizados
  para somar 1); valor ausente, negativo ou inválido usa o padrão daquela parte; todos zero → o padrão. Os
  pesos efetivos aparecem na linha da regra ("Pontuação: impacto 50% · urgência 30% · confiança 20%").
- **Impacto:** módulo do valor ÷ maior módulo da fila (o maior vale 1). O sinal não muda a prioridade.
- **Urgência:** vencido ou hoje = 1; no horizonte (`horizonDays`, padrão 30) ou depois = 0; no meio,
  linear (`1 − dias ÷ horizonte`). Vale o `due`; sem ele, o fim da janela. Sem prazo = 0.
- **Confiança:** alta 1 · média 0,6 · baixa 0,3. Sem confiança informada vale como baixa.
- **Ordens:** pontuação (padrão), impacto, urgência (prazo mais próximo) e confiança. Desempate declarado
  em `SORT_CHAINS`: o critério escolhido decide; depois a pontuação, a urgência, a confiança ou o impacto;
  por fim, a ordem recebida.

## Por que está acima do seguinte

Cada item tem uma frase em relação ao seguinte, gerada por `buildPriorityQueue`:

- Ordem por pontuação: a parte que mais pesou a favor (peso × diferença), com o que empata ou o que pesa
  contra. Ex.: "acima de Loja 03 · Centro: impacto 2× maior com a mesma urgência"; "acima de Loja 12 ·
  Pampulha: confiança alta contra baixa, apesar do impacto menor".
- Impacto: razão "2,4× maior" a partir de 1,95×; abaixo disso, "impacto 26% maior".
- Urgência: "vence 6 dias antes" ou "prazo já vencido". Confiança: "confiança alta contra média".
- Empate no critério: a frase diz o que desempatou ("mesmo prazo; desempate pela pontuação, 97,0 contra
  72,0"). O nome do seguinte é o assunto quando ele é único na fila; senão, o problema.
- O detalhe repete a frase e mostra a conta: cada parte normalizada × peso = pontos, e o total.

## Ausência nunca vira zero

- `impact.value: null`, `NaN` ou texto inválido na fonte = **"sem estimativa"** (selo), nunca R$ 0. O item
  fica sem pontuação e vai para o fim nas ordens por pontuação e por impacto; o detalhe diz o motivo
  (`missingReason`) ou "Valor inválido na fonte". Zero informado é zero (estimativa de nenhum ganho).
- Sem prazo: "sem prazo" (urgência 0, fim da ordem por urgência). Sem responsável: "sem responsável".
- Evidência com `value: null`: "sem dado". O resumo no topo conta os itens sem estimativa.

## Adaptador

`priorityQueueFromRecords(records, mapping)` lê linhas de uma view de Bases ou de um cenário
(`createScenarioReader(...).rows("prioridades")`), compatível com `adapters/series.ts` (`readPath`,
`toMetricValue`): vazio/`null` é ausência, "12.400,50" vira número, texto inválido vira `NaN` (sem
estimativa). Datas aceitam `AAAA-MM-DD` e `dd/mm/aaaa`. Confiança aceita "Alta", "média", "LOW". Linha sem
problema é ignorada; sem `id`, usa a posição da linha.

```ts
priorityQueueFromRecords(rows, {
  id: "id", title: "problema", subject: "loja", impact: "impacto", due: "prazo",
  windowStart: "inicio", windowEnd: "fim", confidence: "confianca", confidenceReason: "motivo",
  owner: "responsavel", evidence: [{ label: "Pares em falta", value: "falta", href: "link", source: "ERP" }],
});
```

## Comportamento

- **Teclado:** cada item é um botão (Enter ou Espaço abre o detalhe); setas, Home e End andam pela fila.
  O detalhe prende o foco; Esc fecha e devolve o foco ao item.
- **Motion:** cascata só na entrada; na troca de ordem os itens deslizam do lugar antigo ao novo
  (`layout` do Motion); com movimento reduzido, a troca é imediata. A troca é anunciada ao leitor de tela.
- **Tabela:** "Ver tabela" mostra posição, problema, impacto estimado, prazo, confiança, responsável,
  pontuação e a frase.
- **Ações e persistência:** só por callbacks. O componente não grava, não usa armazenamento local e não
  chama rede.
- **360 px:** o impacto desce para baixo do problema e os fatos quebram em linhas; sem rolagem lateral.
