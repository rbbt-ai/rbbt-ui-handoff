# ContextBar e ScopeNote — contrato

Versão do pacote: `@rbbt/ui@0.2.0-rc.2` · estado: **candidato para revisão visual** (não aprovado). Adições do rc.2 marcadas com (rc.2); sem elas, a barra é a do 0.2.0-rc.1.

`ContextBar` é o contexto compacto do topo da página: título, perspectiva (ex.: Rede | Unidade), filtros, atualização, cobertura e fonte. `ScopeNote` mostra, junto ao título de um widget, o **recorte efetivo** quando ele não responde a um filtro da página.

```tsx
import { ContextBar, ScopeNote } from "@rbbt/ui";

<ContextBar
  title="Visão geral"
  perspective={{ label: "Perspectiva", value: perspectiva, options: [{ value: "rede", label: "Rede" }, { value: "unidade", label: "Unidade" }], onChange: setPerspectiva }}
  filters={[
    { id: "regiao", label: "Região", value: regiao, options: regioes, onChange: setRegiao },
    { id: "periodo", label: "Período", value: periodo, options: periodos, onChange: setPeriodo },
  ]}
  updatedAt="2026-10-18T06:10:00-03:00"
  coverage={{ label: "7 de 8 unidades completas", tone: "warning", description: "1 unidade sem dados em 16 e 17/10" }}
/>;

<EvolutionChart scope={<ScopeNote label="Recorte efetivo" value="Posição de 18/10" reason="estoque não filtra por período" />} … />;
```

## ContextBar

| Prop | Padrão | Descrição |
| --- | --- | --- |
| `title`, `subtitle`, `headingLevel` | `h1` | Título da página. |
| `perspective` | — | `{ label, value, options, onChange }` em controle segmentado. |
| `filters[]` | — | `{ id, label, value, options, onChange, description?, isDisabled? }`; `options[]` com `description` opcional (ex.: "5 unidades, inclui a móvel"). Filtros são **controlados**: o estado (e a URL, para preservar ao abrir detalhes) é do consumidor. |
| `updatedAt`, `staleAfterMs`, `now` | — | "Atualizado há X" ou selo "Desatualizado". |
| `coverage` | — | `{ label, tone?, description? }` sempre visível. |
| `source`, `extra` | — | Fonte e conteúdo extra (ex.: selo "Dados fictícios"). |
| `collapseBelow` | `640` | Abaixo desta largura de container, os filtros viram resumo + botão "Filtros (N)" que abre um painel (Modal React Aria: foco preso, Esc fecha, devolve o foco). |
| `period` (rc.2) | — | Período e corte da página, primeiro item da linha de metadados (ex.: "Outubro 2026, até 17/10"). Informe o mesmo ao `PageContextProvider`. |
| `anatomy` (rc.2) | a do `PageContextProvider`, senão `full` | `lean`: período, cobertura, atualização, fonte e `extra` numa **linha só**, com "·" entre itens (nenhuma linha começa com "·" quando quebra). A cobertura vira marcador com o detalhe por clique, toque ou teclado. Recolhida, o resumo dos filtros ocupa uma linha no lugar do subtítulo, com o botão "Filtros". |
| `filters[].showInSummary` (rc.2) | `true` | `false` tira o valor do resumo recolhido, quando ele já aparece na linha de metadados (ex.: o período). |
| `options[].shortLabel` (rc.2) | — | Rótulo curto no resumo recolhido (ex.: "vs. meta" para a opção "Meta"). |
| `status` (0.4.0) | `ready` | `loading`: esqueleto das pílulas (ou do resumo e do botão, se recolhida) e da linha de metadados, na geometria do estado pronto, com `aria-busy` e aviso para leitor de tela. O título continua visível. |

**Desenho smooth (0.4.0, anatomia `lean`).** Título 26/600, perspectiva em trilha de pílula e cada filtro numa `PillSelect` de 40 px com rótulo e valor. A ajuda do filtro (`description`) vira descrição acessível da pílula; a folha do modo recolhido mostra os campos com a ajuda visível. Filtro sem opções fica desabilitado e diz "Sem opções", também no resumo (mensagem `noOptions`). Para o erro de uma lista, passe a opção "Indisponível" com `isDisabled` e o motivo na `coverage` com tom `negative`. Exemplos de todos os estados em "Smooth/Componentes · contexto, filtros e painel".

## PageContextProvider (rc.2)

Contexto da página informado uma vez: `period`, `source`, `updatedAt`, `staleAfterMs`, `now` e `anatomy`. Os widgets dentro dele herdam esses valores; com `provenance="inherit"` (padrão), o que for igual ao da página não se repete no card nem no rodapé do painel e passa para "Como calculamos"; o que difere aparece (ex.: posição de estoque datada). Sem provedor, tudo funciona como no 0.2.0-rc.1. `resolveProvenance(input, page)` é a função pura por trás, exportada para adaptadores e testes.

```tsx
<PageContextProvider period="Outubro 2026, até 17/10" source="ERP" updatedAt={atualizadoEm} staleAfterMs={26 * 3600_000} anatomy="lean">
  <ContextBar title="Visão geral" period="Outubro 2026, até 17/10" updatedAt={atualizadoEm} coverage={cobertura} extra="Dados fictícios" filters={filtros} />
  <TrendIndicator … />
  <ComparisonTable … />
</PageContextProvider>
```

## Marker (rc.2)

Ressalva de uma linha: ícone e palavra, sem caixa colorida (ex.: "Parcial · 21/22 lojas"). O tom pinta só o ícone; o sentido está na palavra. Com `detail`, vira botão (alvo de 24 px, 44 px em ponteiro grosso, sublinhado pontilhado) que abre o detalhe num painel por clique, toque ou teclado, nunca só no hover. Use só quando a ressalva muda a leitura do número.

## ScopeNote

`{ label, value, reason? }`: ícone + "Recorte efetivo: Posição de 18/10 · estoque não filtra por período". Use quando o período, a cobertura ou o universo do widget diferem do filtro da página.

## Acessibilidade

`section` nomeada pelo título; campos com rótulo visível (React Aria `Select`); painel de filtros com título, foco gerenciado e área de toque de 44 px; atualização com data absoluta para leitores de tela.

## Dependências

`react-aria-components` (`Select`, `ToggleButtonGroup`, `Modal`, `Dialog`), `lucide-react`.
