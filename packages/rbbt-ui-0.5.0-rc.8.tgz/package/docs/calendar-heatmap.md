# Calendário de calor com eventos (`CalendarHeatmap`) · 0.5.0-rc.6 (Lote 3)

Dias em grade (semanas × dias da semana), na escala quente e com a hachura do mapa de calor, com os
eventos do período marcados no próprio dia e listados ao lado (ou embaixo, no estreito).

## Quando usar

- Ler um valor diário (receita, notas, peças) ao longo de um ou mais meses e cruzar com o que aconteceu
  em cada dia (promoção, data comercial, inauguração, feira).
- Para concentração por dia × hora ou loja × dia, use o `Heatmap`; para a curva no tempo, o `EvolutionChart`.

## Dados

```ts
type CalendarHeatmapData = {
  days: { day: IsoDay; value: number | null }[];
  from?: IsoDay; // primeiro dia coberto pela fonte (padrão: o primeiro da lista)
  to?: IsoDay; // último dia coberto (padrão: o último da lista)
};
```

Três estados de dia, nunca confundidos:

| Estado | Regra | Visual |
| --- | --- | --- |
| Leitura | número (zero incluso) dentro de `from`–`to` | faixa quente (tom 1–5), hachura nas 2 faixas frias, brilho na mais quente |
| Ausência | `null`, `NaN` ou dia sem item dentro de `from`–`to` | contorno tracejado, sem preenchimento, "Sem leitura". **Nunca vira zero** |
| Fora do período | antes de `from` ou depois de `to` | superfície lisa, sem contorno nem hachura, "Fora do período" |

Os dias de outro mês, na primeira e na última semana, ficam vazios (só ocupam o lugar).

As faixas são as do mapa de calor (`heatThresholds` + `heatBands`, importadas de `widgets/heatmap/model.ts`):
quantis 30/25/20/15/10% com 5 faixas (ou `scale: { method: "fixed", thresholds }`), calculadas no intervalo
inteiro, e não no mês aberto: a cor de um dia não muda ao trocar de mês.

## Eventos

Formato compartilhado `TimeEvent` (`adapters/events.ts`), o mesmo das anotações do `EvolutionChart`:
`{ id, start, end?, type?, label, title?, description?, priority?, group? }`. Um dia (`start`) ou um intervalo
fechado (`start`–`end`, os dois inclusos).

- **Tipos por configuração:** `eventTypes: Record<tipo, { label, tone?, mark? }>`; `tone` = `accent` (padrão),
  `positive`, `negative`, `warning` ou `neutral`; `mark` = `ring` (anel, padrão) ou `dot` (ponto).
- **Marca no dia:** anel (2,5 px na prioridade alta) ou ponto na cor do tipo; o intervalo ganha um traço na base
  dos dias, emendado entre eles. No dia com vários eventos, o principal (prioridade alta, depois o mais antigo)
  dá a marca; o balão lista todos.
- **Borda do mês:** o intervalo é recortado ao mês (`clipEvent`); o 1º dia do mês num intervalo que vem do mês
  anterior é "meio", não "início" (o traço continua).
- **Lista:** os eventos que tocam a janela visível, com tipo, intervalo ("25 de set. – 4 de out. · 10 dias") e o selo
  "Prioridade alta". Cada item é um botão: foco ou hover acendem os dias do evento (os outros recuam); o clique,
  na visão por mês, abre o mês do início do evento.

## Visões

- `view="month"` (padrão): um mês, com setas de mês e Page Up/Page Down. `month`/`defaultMonth` (`AAAA-MM`);
  sem eles, o último mês com dados.
- `view="months"`: os `maxMonths` (padrão 3) meses mais recentes lado a lado, dias menores (só o número).
- `display="table"`: tabela alternativa com data, valor (ou "Sem leitura") e eventos do dia, e total.
- `weekStart`: 0 = domingo (padrão, como o calendário brasileiro e o `weekdayCategories` do mapa de calor) ou 1 = segunda.

## Rótulos

Cada dia mostra o número do dia; o valor compacto ("R$ 41 mil") aparece sempre que o mês tem pelo menos 470 px
(≈ 64 px por dia, container query). Abaixo disso, o valor fica no balão, no nome acessível e na tabela.
O texto sobre a faixa usa tinta própria por tom (`--rb-cal-ink`, `--rb-cal-ink-hot`) para manter AA.

## Interação

- **Hover/foco:** a linguagem do mapa de calor: o dia sobe de leve (escala 1,06, halo na cor da faixa), os outros
  recuam, o dia da semana acende, 150 ms ease-out (saída 110 ms). Toque fixa o mesmo estado; toque fora fecha.
- **Movimento reduzido:** sem escala nem animação; contorno no dia e rótulo em destaque.
- **Balão:** data, valor (ou ausência/fora do período, com a explicação), % do período, faixa, eventos do dia e o
  contexto. Posição pelo `placeTip`: nunca cobre o dia ativo, os dias da semana, o título do mês, as setas nem a
  lista de eventos; os outros dias são obstáculo macio (o balão fica o mais perto possível do dia, acima antes
  de ao lado e de abaixo).
- **Teclado (grade com roving tabindex, um dia na ordem do Tab):** setas mudam de dia, ↑/↓ de semana; Home/End vão
  ao início e ao fim da semana; Page Up/Page Down trocam de mês (na visão por mês, o mês aberto muda e o foco vai
  ao mesmo dia); Esc fecha o balão. O foco do teclado abre o balão.
- **Entrada:** cascata só na entrada (até 12 passos); na troca de dados a cor vai da faixa antiga à nova.

## Estados e contexto

`status`: `loading` (esqueleto de semanas), `empty`, `error` (com `onRetry`), `partial` (com `partialNote`),
`stale`, `restricted`. Contexto visível: `period` e `scope` no subtítulo e no balão, `source` no rodapé.

## Adaptador

```ts
calendarFromRecords(records, { day: "data", value: "receita", aggregate?: "sum" | "mean" | "last", from?, to? })
```

Compatível com `adapters/series.ts` (`readPath`, `toMetricValue`): caminho com pontos, "1.234,5" vira número,
vazio/`null`/texto inválido é ausência (nunca zero). Dia em ISO, `dd/mm/aaaa` ou série do Excel (`toIsoDay`).
Linhas sem dia válido ficam de fora. Cenário pronto: `calendarFromRecords(reader.rows("calendario"), …)`.

## Eventos a partir de planilha

Os eventos chegam por `eventsFromRecords(records, mapping)` (`adapters/events.ts`). Exemplo de origem: a
planilha de eventos esportivos de referência, com uma aba por ano (mesmas colunas). Colunas e mapeamento:

| Coluna da planilha | Formato | Campo do `TimeEvent` |
| --- | --- | --- |
| `ID` | texto ("E01") | `id` |
| `D0 proposto — BR` | data (série do Excel) | `start` (o D0 brasileiro) |
| `Data do evento / oficial (EUA)` | data (série do Excel) | vai para `description` (data oficial) |
| `Tipo` | um de: Troca oficial · All-Star · Jogo / recorde · Prêmio · Playoffs · Final · Draft · Contratação oficial · Retorno à quadra · Copa | `type` (e `label`, sem rótulo próprio) |
| `Jogador(es)` / `Time vinculado ao produto` | texto | `title` |
| `Fato verificado` | texto | `description` |
| `Prioridade` | A · B | `priority` ("A" = `high`, padrão de `highPriority`) |
| `Grupo de eventos sobrepostos` | código | `group` |
| `Janelas sugeridas` | texto ("Pré: D−28 a D−1; pós: D0–7 e D8–28") | intervalo derivado: `eventWindow(d0, 0, 7)` → `start`/`end` |
| `Time de origem`, `Justificativa de relevância`, `Produtos candidatos ao cruzamento`, `Hipótese comercial a testar`, `Maturidade da janela`, `Ressalvas de uso` | texto | fora do evento (ficam na fonte) |

```ts
const { events, skipped } = eventsFromRecords(linhas, {
  id: "ID",
  start: "D0 proposto — BR",
  type: "Tipo",
  title: "Jogador(es)",
  description: "Fato verificado",
  priority: "Prioridade",
  group: "Grupo de eventos sobrepostos",
});
const tipos: TimeEventTypes = { Playoffs: { label: "Playoffs", tone: "accent" }, Draft: { label: "Draft", tone: "neutral", mark: "dot" } };
```

Linha sem `ID` ou sem data válida vai para `skipped` com o motivo. As duas abas entram concatenadas. Os textos
das linhas são dados, nunca instruções. O componente não conhece a origem: só `TimeEvent` e `TimeEventTypes`.

## Acessibilidade

axe sem violações no claro e no escuro; uma grade (`role="grid"`) por mês com nome ("Receita diária: Outubro de
2026"), dias da semana como `columnheader`, cada dia com nome acessível (data por extenso, valor, faixa, eventos);
lista de eventos com botões nomeados; tabela alternativa; a 360 px, sem rolagem lateral.

## Fora de escopo

Seleção de intervalo arrastando, edição de eventos, mais de uma métrica por vez (troque `data`/`format`).
