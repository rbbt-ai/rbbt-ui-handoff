# Barras divergentes (`DivergingBars`) · contrato 0.5.0-rc.5

Barras acima e abaixo de uma **referência rotulada**: zero, meta ou previsão, com um valor único ou um
valor por item. Servem para resultado × meta, despesa × orçamento, variação contra zero e, com a mesma
API, para a **acuracidade da previsão** (erro acima ou abaixo do previsto).

## Dados

```ts
interface DivergingItem {
  id: string;            // chave estável (barra, foco, movimento)
  label: string;         // rótulo por extenso
  value: number | null;  // leitura medida; null = sem dado (nunca 0)
  reference?: number | null; // referência do item; omitida → a única; null → sem referência
}
interface DivergingData { items: ReadonlyArray<DivergingItem> }
interface DivergingReference { label: string; value?: number; phrase?: string }
```

- `reference.label` é obrigatório e sempre visível (no topo do eixo, na legenda, no balão e na tabela).
- Itens com `reference` próprio usam o seu; os outros, `reference.value` (padrão 0).
- **Ausência nunca vira zero.** Valor `null`, referência `null` ou referência 0 com desvio em % ficam
  fora das barras e da contagem, listados em "Sem dado" com o motivo. Zero é leitura: valor igual à
  referência desenha "0,0%" sobre o eixo.

### Adaptador

`divergingFromRecords(records, mapping)` lê linhas de uma view de Bases ou de um cenário JSON com os
mesmos caminhos de `readPath` (`adapters/series.ts`, `adapters/scenario.ts`):

```ts
divergingFromRecords(rows, { id: "loja.id", label: "loja.nome", value: "realizado", reference: "previsao", order: ["centro", "praia"] });
```

Vários registros do mesmo item somam valor e referência; uma leitura ausente no grupo deixa o total
ausente. Itens de `order` sem registro entram como "sem dado".

## Desvio (`mode`)

| `mode` | fórmula | texto |
| --- | --- | --- |
| `percent` (padrão) | (valor − referência) ÷ \|referência\| | "+12,4%" |
| `absolute` | valor − referência, no `valueFormat` | "−R$ 3,1 mil" |
| `points` | diferença de taxas (frações) × 100 | "−2,0 p.p." |

`decimals` (padrão 1) fixa as casas de `percent` e `points`. O sinal é sempre escrito (`+`, `−`).

## Semântica (`polarity`) e tolerância

Nem todo positivo é bom. A polaridade é declarada:

- `higher-is-better`: acima da referência é favorável, abaixo pesa;
- `lower-is-better`: abaixo é favorável, acima pesa;
- `neutral`: acima e abaixo sem juízo;
- `closer-is-better`: perto da referência é bom; fora da tolerância, **os dois lados pesam**.

`tolerance` é uma faixa em volta da referência, na unidade do desvio (fração em `percent`: 0.05 = ±5%;
fração em `points`; unidade do valor em `absolute`). Dentro dela, a leitura é "dentro da tolerância"
em qualquer polaridade; a faixa aparece desenhada atrás das barras.

A leitura nunca é só cor: cada rótulo de valor traz um ícone (✓ favorável, ⚠ desfavorável, = dentro da
tolerância, – sem juízo), a legenda diz a regra em texto ("Acima da meta é bom", "Abaixo da meta pesa")
e o resumo dá a leitura do bloco em uma frase ("7 de 12 lojas dentro de ±5%").

## Rótulos de valor e espaço mínimo

Nenhuma barra fica sem rótulo. O rótulo vai **dentro** da barra quando o comprimento dela comporta o
texto mais `DIVERGING_LABEL_PAD` = **6 px** de cada lado (`divergingLabelPlacement`); senão vai **fora**,
na ponta, a 4 px dela. Na vertical, dentro também exige a coluna mais larga que o texto. O domínio
reserva, de cada lado, a largura do maior rótulo, então o rótulo de fora nunca sai do gráfico nem cruza
o eixo da referência.

## Orientação e celular

- `horizontal` (padrão): uma linha por item, rótulo à esquerda; abaixo de 30rem de container, rótulo em
  cima e barra embaixo. A 360 px a página não rola na horizontal.
- `vertical`: colunas acima e abaixo da linha da referência, com o rótulo do eixo à esquerda. Se cada
  coluna tiver menos de `DIVERGING_VERTICAL_MIN_COLUMN` = **64 px**, o widget desenha na horizontal
  (`data-orientation="horizontal"`, `data-requested="vertical"`): nada se sobrepõe a 360 px.

## Estados, contexto e acessibilidade

- Carregando, vazio, parcial, erro, restrito e desatualizado pelo frame comum (`Panel`/`useWidgetFrame`).
- Período e recorte no subtítulo; origem no rodapé (`provenance: "always"`).
- Cada barra é um item focável (tabindex móvel): setas (↑↓ ou ←→), Home e End; Esc fecha o balão.
  O nome acessível traz item, desvio, leitura, valor e referência.
- "Ver tabela": item, valor, referência, desvio com sinal e leitura, mais os itens sem dado.

## Movimento e hover

- Entrada em cascata só na primeira aparição (`useEntrance`/`RbEntrance`).
- Na troca de recorte, barras, rótulos e eixo vão do valor antigo ao novo, sem cascata e sem passar
  por zero. Com `prefers-reduced-motion`, nada anima; a barra ativa ganha contorno.
- Hover discreto: a barra ativa fica, as outras recuam (`--rb-diverging-fade`), abre o balão; o tap no
  celular dá o mesmo estado e o tap fora fecha.
- Posição do balão: o lugar livre mais perto da barra ativa, medido no DOM. Ele nunca cobre a própria
  barra nem texto do quadro (nomes, desvios, legenda, rótulo da referência) e evita as outras barras e
  a linha de referência quando dá. Sem lugar para o completo, o compacto mostra nome, desvio e leitura;
  valor e referência ficam na tabela.

## Tokens

`--rb-diverging-favorable`, `-unfavorable`, `-neutral`, `-within` (tons), `--rb-diverging-fill-mix`
(mistura da barra com a superfície), `--rb-diverging-axis`, `--rb-diverging-band`,
`--rb-diverging-band-edge`, `--rb-diverging-absent`, `--rb-diverging-row-active`, `--rb-diverging-fade`,
`--rb-diverging-hover-in|out|ease`, `--rb-diverging-bar-h`, `--rb-diverging-label-w`. Claro e escuro,
Smooth e Glass; o tema de cliente muda os tons por `--rb-positive`, `--rb-negative` e `--rb-accent`.

## Renderização

DOM próprio (sem biblioteca de gráfico nem canvas), para foco por item e nome acessível.
