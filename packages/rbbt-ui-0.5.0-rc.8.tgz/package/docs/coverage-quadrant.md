# Quadrante velocidade × cobertura (`CoverageQuadrant`, 0.5.0-rc.4)

Onde agir no estoque: cada ponto é uma **referência** (padrão) ou uma **loja** (`itemKind="store"`), com a
velocidade de venda no eixo x e a cobertura em semanas no eixo y. Os limites dividem o plano em 4 quadrantes e
cada quadrante tem uma **ação em texto**: repor, remarcar, remanejar, manter ou acompanhar.

## Dados

```ts
interface QuadrantData {
  items: {
    id: string;
    label: string;
    detail?: string;              // linha curta: "Tênis · Linha Trilha"
    velocity: number | null;      // un/semana, ou sell-through como fração 0–1
    coverage: number | null;      // semanas
    rupture?: number | null;      // fração 0–1 dos dias sem disponibilidade
    stores?: { id: string; label: string; coverage: number | null }[]; // para remanejar
  }[];
}
```

- **Métrica do eixo x** configurável: `metrics` (`{ id, label, format, threshold? }`), `metric` e
  `onMetricChange`. Com duas ou mais métricas e `onMetricChange`, aparece o seletor ("Unidades por semana" ou
  "Sell-through"). Sem `metrics`: "Velocidade de venda" em un/sem. O widget não converte: `velocity` já vem na
  unidade da métrica atual.
- **Itens** = referência ou loja (`itemKind`): muda os textos ("referência"/"loja"), não a regra.
- **Contexto sempre visível**: `period` ("20–26/10"), `scope` ("6 lojas") e `stockDate` (dia ISO →
  "Posição do estoque 26/10") no topo e no balão; `source` no rodapé, sempre (`provenance: "always"`).
- **Ausência nunca vira zero.** `null`, `NaN`, infinito e texto inválido são *sem leitura*. Item sem velocidade
  ou sem cobertura **não entra no gráfico**: vai para a lista "Sem leitura · N referências", com o campo que
  falta, e para a tabela com "Sem leitura" no lugar do quadrante e da ação. Zero é leitura: velocidade 0 (não
  vendeu no período) fica no zero do eixo; ruptura 0 desenha o ponto sem anel. Loja sem cobertura fica fora da
  regra de remanejar.

### Adaptadores

- `quadrantFromRecords(rows, mapping)`: linhas de uma view de Bases ou `reader.rows("quadrante")` de um cenário
  pronto (`createScenarioReader`, de `adapters/scenario.ts`). Campos por nome ou caminho com pontos
  (`readPath`); número pela regra de `toMetricValue` de `adapters/series.ts` ("1.234,5" → 1234,5); vazio, `null`
  e texto inválido são ausência. Linha sem id é ignorada.
  - `id`, `label`, `detail`, `velocity` (campos).
  - Cobertura: `coverage` pronta **ou** `stock` + `weeklySales` (cobertura = estoque ÷ venda semanal, pela
    `coverageWeeks` dos adaptadores de operação; venda zero ou sem leitura → sem leitura).
  - Ruptura: `rupture` pronta (fração 0–1) **ou** `ruptureDays` + `periodDays` (campo ou número fixo).
  - Lojas para remanejar: `stores: { path?, id, label?, coverage }`. Com `path`, a lista aninhada na linha
    (cenário pronto); sem `path`, cada linha é item × loja e as linhas com o mesmo id se juntam (view de Bases).
    Ao juntar, vale a primeira leitura de cada campo; uma loja não se repete.
- `sellThrough(vendidas, estoqueFinal)` e `ruptureFromDays(diasSem, diasDoPeriodo)` para quem monta os dados.

## Regras e fórmulas

- **Cobertura (semanas)** = estoque ÷ venda média semanal.
- **Sell-through** = vendidas ÷ (vendidas + estoque final). Sem base (0 + 0), negativo ou sem leitura → sem
  leitura.
- **Ruptura** = dias sem disponibilidade no período ÷ dias do período (fração 0–1, mostrada como "38% dos dias").
  Período sem dias, dias fora do período ou valor fora de 0–1 → sem leitura (nunca cortado para caber). Abaixo
  de 0,5% e acima de zero, o texto é "< 1%".
- **Quadrante** (`quadrantOf`), limites **inclusivos**: velocidade ≥ limite é *rápida*; cobertura ≥ limite é
  *alta*. Sem leitura num dos eixos → sem quadrante.
- **Limites** (`thresholds`, sempre desenhados como linhas, com o valor na ponta do eixo):
  - velocidade: `thresholds.velocity` → `metric.threshold` → mediana das leituras do gráfico (2 algarismos);
  - cobertura: `thresholds.coverage` → 8 semanas.
- **Regra de ação** (`quadrantAction`, configurável por `rule`):

| Quadrante | Ação padrão | Leitura |
| --- | --- | --- |
| rápido + cobertura baixa | **Repor** | vende rápido e tem pouca cobertura |
| lento + cobertura alta | **Remarcar** | vende devagar e tem muita cobertura |
| rápido + cobertura alta | Manter | vende bem e está coberto |
| lento + cobertura baixa | Acompanhar | pouco estoque e pouca venda |

  - **Remanejar vence qualquer quadrante** quando há desequilíbrio entre lojas: uma loja com cobertura
    ≥ `rule.imbalance.high` e **outra** com ≤ `rule.imbalance.low` (padrão 12 e 3 semanas). O texto diz onde
    sobra e onde falta ("sobra em Jardins, falta em Batel"). Loja sem leitura não conta. `imbalance: false`
    desliga.
  - `rule.actions` troca a ação de qualquer quadrante (ex.: `{ "fast-high": "acompanhar" }`); o rótulo da
    região acompanha.
- **Escala**: cada eixo vai de 0 a um teto redondo, com folga acima do limite e no máximo 4× o limite. Leitura
  acima fica **na borda**, com seta, e o valor real no balão, na tabela e no nome acessível.

| Token | Uso |
| --- | --- |
| `--rb-quad-point` / `--rb-quad-point-edge` | Ponto (acento do tema ou do cliente) e contorno |
| `--rb-quad-repor` / `--rb-quad-remarcar` / `--rb-quad-remanejar` | Tinta das ações (info, aviso, acento) |
| `--rb-quad-repor-soft` / `--rb-quad-remarcar-soft` | Fundo discreto das regiões repor e remarcar |
| `--rb-quad-*-pill` / `--rb-quad-quiet` / `--rb-quad-quiet-pill` | Etiquetas de ação (manter e acompanhar quietas) |
| `--rb-quad-risk` / `--rb-quad-risk-track` | Anel de ruptura (negativo do tema) e trilho |
| `--rb-quad-line` / `--rb-quad-axis` | Linhas de limite (tracejadas) e eixos |
| `--rb-quad-absent` | Marca da lista "Sem leitura" |
| `--rb-quad-halo` | Halo do ponto ativo |
| `--rb-quad-hover-in` / `--rb-quad-hover-out` | 150 ms / 110 ms (zeram com movimento reduzido) |
| `--rb-quad-hover-scale` | 1,3: escala do ponto ativo |
| `--rb-quad-fade` | Recuo dos outros pontos com um ativo (0,28–0,34 conforme o tema) |
| `--rb-quad-hover-ease` | `cubic-bezier(0.22, 1, 0.36, 1)` |

## Interação

- **Ponto**: círculo cheio; **vazado** quando a ação é remanejar. **Anel** em volta = % dos dias em ruptura
  (arco proporcional, tom negativo). Sem anel: ruptura zero ou sem leitura (o balão e a tabela dizem qual).
- **Hover, foco do teclado ou tap**, no padrão do mapa de calor: o ponto ativo cresce e ganha halo, os outros
  recuam (`--rb-quad-fade`), a região do quadrante acende e o balão abre **sem atraso** com nome, ação,
  quadrante, velocidade, cobertura, ruptura em % dos dias, lojas do remanejar e o contexto (período, lojas e
  posição do estoque). Tap fora fecha.
- **Ver tabela** alterna com o gráfico (`view`/`defaultView`/`onViewChange`).

## Acessibilidade

- Os pontos ficam num `role="group"` com nome ("Velocidade × cobertura: 19 referências no gráfico") e a
  descrição dos limites e do teclado. Tabindex móvel: um ponto na ordem de Tab.
- **Setas** vão ao ponto mais próximo naquela direção (o desvio lateral pesa o dobro); **Home/End** ao primeiro e
  ao último na ordem de leitura (esquerda → direita); **Esc** fecha o balão.
- Nome de cada ponto: "‹nome›: ‹velocidade›, cobertura ‹semanas›, ruptura ‹%› dos dias. ‹Quadrante›. Ação:
  ‹ação› (‹sobra em…, falta em…›)." e, na borda, "Ponto na borda, acima da escala do gráfico."
- **Tabela**: cada item (inclusive os sem leitura) com velocidade, cobertura, ruptura (% dos dias), quadrante e
  ação; ausência por extenso. Rola dentro do widget, com foco e nome próprios.
- O balão é visual (`aria-hidden`): o leitor de tela recebe tudo no nome do ponto. Cor nunca é o único sinal:
  ação em texto, remanejar vazado, ruptura em arco e em número.

## Movimento

- Entrada na página, troca de módulo ou entrada na tela: os pontos surgem em **cascata** na ordem de leitura
  (`--rb-duration-enter`, `--rb-duration-stagger`, até 12 passos).
- **Troca de métrica ou de dado**: cada ponto, as linhas de limite e as regiões vão da posição antiga à nova
  (Motion), **sem cascata e sem passar por zero**. Mudança de largura não anima.
- Movimento reduzido: estado final direto; o ponto ativo ganha só o contorno de foco, sem escala nem recuo.

## Estados

Carregando (esqueleto com legenda e os 4 quadrantes), vazio, erro (com "Tentar novamente"), sem permissão,
parcial (aviso visível) e desatualizado, pela moldura comum (`Panel`).

## Layout

- O gráfico segue a largura do container (altura ≈ 0,56 × largura, de 236 a 400 px). Abaixo de 420 px ele fica
  quase quadrado (altura = largura, mínimo 280 px) para separar os pontos, e margens e pontos encolhem.
- Rótulos das regiões ficam no canto externo da região; se cobrem pontos, vão para o canto livre da mesma
  região. **Rótulo nunca cobre ponto**: se algum não tem lugar livre (ou abaixo de 420 px, sempre), os quatro saem
  do gráfico para uma chave 2 × 2 abaixo dele, na disposição dos quadrantes ("↖ Remarcar ↗ Manter / ↙ Acompanhar
  ↘ Repor"). As pontas dos eixos somem quando encostariam no valor do limite; o valor continua no balão, no nome
  acessível e na tabela.
- Abaixo de 264 px o gráfico não encolhe mais: rola dentro do widget. A 360 px a página nunca rola na
  horizontal; a tabela rola só dentro do widget.

## Por que SVG e não ECharts

O scatter do ECharts desenha pontos sem foco próprio nem nome acessível por ponto, e o anel de ruptura em arco,
o ponto vazado, as regiões por token de tema e de cliente e o recuo no padrão do mapa de calor exigiriam
`renderItem` e estado fora do componente. A geometria aqui é pequena (escalas lineares, 4 regiões, 2 linhas):
SVG próprio com pontos focáveis, CSS por tokens e Motion pelas regras dos outros widgets, sem biblioteca nova.
