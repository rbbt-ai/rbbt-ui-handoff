# Tabela com minigráficos · `sparklineColumnCell` na `ComparisonTable` (0.5.0-rc.8)

Minigráfico SVG por linha da `ComparisonTable`, no mesmo padrão do `bulletColumnCell`: a tabela continua
sendo a única engine (ordenação, CSV, conferência de totais, cartões abaixo de 640 px, raio-X) e a coluna
ganha um desenho por célula. Não há outra tabela nem biblioteca de gráfico nova.

## Anatomia da célula

| Elemento | O que mostra | Token |
| --- | --- | --- |
| Linha | série da linha; `null` abre lacuna (semana sem leitura), nunca desce a zero | `--rb-spark-cell-line` |
| Pontos soltos | leitura isolada entre duas lacunas | `--rb-spark-cell-line` |
| Referência (opcional) | outra série alinhada, tracejada (ex.: média da rede) | `--rb-spark-cell-reference` |
| Último ponto | ponto com halo, no tom da variação | tom favorável/desfavorável do tema; halo `--rb-spark-cell-ring` |
| Valor ao lado | último valor válido e a variação do primeiro ao último (`R$ 214 · +13%`) | texto 600 + variação mais leve |

A célula é um botão: o nome acessível é o texto alternativo completo, e clique, Enter ou Espaço abrem o
`DetailPanel` com a série em tabela (período, valor ou "sem leitura" e, com referência, a diferença).
Largura mínima do desenho: `minWidth` (padrão 88 px), que também vale nos cartões a 360 px.

## Uso

```tsx
const series = sparkSeriesFromRecords(registros, {
  key: "loja", period: "semana", value: "precoMedio",
  periods: SEMANAS, periodLabel: (iso) => `${iso.slice(8, 10)}/${iso.slice(5, 7)}`, aggregate: "mean",
});
const domain = sparkDomain(series.values());

const coluna: ComparisonColumn = {
  id: "serie",
  header: "12 semanas",
  description: sparkScaleNote("common", { domain, format: BRL }), // a escala é declarada no cabeçalho
  format: BRL,
  sortable: false,
  cell: sparklineColumnCell({
    series: (ctx) => (ctx.row ? series.get(ctx.row.id) : null),
    metric: "Preço médio",
    scale: "common", domain,
    polarity: "higher-is-better",
    referenceLabel: "Média da rede",
    detailContext: "Pedravela · 12 semanas até 01/11 · ERP fictício",
  }),
};
```

| Opção | Padrão | Função |
| --- | --- | --- |
| `series(ctx)` | — | série da linha, do subtotal ou do total; sem série, a célula cai no texto da coluna |
| `metric` | — | nome da métrica no texto alternativo e no título do detalhe |
| `format` | o da coluna | formato dos valores da série |
| `scale` | `row` | `row`: mínimo e máximo da própria linha; `common`: o mesmo domínio para todas (`domain`) |
| `polarity` | `neutral` | `higher-is-better`/`lower-is-better` dão o tom da variação; neutro não colore |
| `referenceLabel` | — | sem ele a referência não é desenhada |
| `periodUnit` | semana/semanas | unidade no texto ("2 semanas sem leitura") |
| `detailContext` | — | período, lojas e origem no subtítulo do detalhe |
| `minWidth` | 88 | largura mínima do desenho em px |
| `messages` | pt-BR/en-US | textos (`sparkMessages`) |

`ComparisonTable` ganhou `animateReorder` (padrão `false`): ao mudar a ordem, cada linha vai do lugar antigo ao
novo com Motion, sem cascata; movimento reduzido troca na hora.

## Adaptadores (Bases e cenário)

- **`sparkSeriesFromRecords(records, mapping)`** → `Map<chave, SparkSeries>`. Agrupa por `key` e `period`
  (caminho do registro, como `"loja.id"`, ou função; texto numérico aceito como em `toMetricValue`). Balde sem
  registro, ou só com valor ausente ou inválido, vira `null`. Períodos fora de `periods` são ignorados.
  `aggregate`: `sum` (padrão), `mean` (preços) ou `last` (saldos).
- **`topProductsFromRecords(records, mapping)`** → `TopProductsResult`. Ranking pela receita somada com:
  - `n` configurável (maior que a lista devolve todos, e `n` efetivo vem no resultado);
  - empate declarado: `label` (desempata pelo nome) ou `shared` (posições divididas);
  - `previous` (posição anterior por chave) → `move`: `up`, `down`, `same` ou `new`;
  - `others: true` acrescenta a linha "outros" e `check` confere top + outros contra o total
    (`total` da fonte, se informado; senão, a soma dos registros);
  - preço médio = receita ÷ unidades; sem unidades, `null`.
- `sparkSummary`, `sparkText`, `sparkDomain` e `sparkScaleNote` servem para montar o texto, o domínio comum e a
  nota do cabeçalho fora da célula.

## Texto alternativo

`sparkText` gera a frase da célula, igual no leitor de tela, no detalhe e na alternativa em texto:

> Preço médio em 12 semanas: de R$ 189 a R$ 214, +13%; 2 semanas sem leitura

Sem nenhuma leitura: "Preço médio em 12 semanas: sem leitura no período". Nunca "R$ 0".

## Estados

Os estados são os da `ComparisonTable` (`status`: `loading`, `empty`, `error`, `partial`, `stale`,
`restricted`). Linha sem série cai no texto padrão da coluna ("—"); semanas sem leitura ficam visíveis na linha
e na coluna "Sem leitura" do uso de preço médio.

## Movimento (Motion)

- **Entrada:** a linha se revela da esquerda para a direita (máscara animada com Motion) e o último ponto e o
  valor aparecem no fim. Só na entrada, sem cascata entre linhas.
- **Troca de filtro ou período:** a série vai do desenho antigo ao novo (mesmas lacunas) e o valor troca sem
  passar por zero. Se as lacunas mudam, troca na hora. Reordenar anima a posição com `animateReorder`.
- **Movimento reduzido:** valor e desenho finais direto. Nenhum `@keyframes`, `transition-delay` ou
  `requestAnimationFrame` próprio.

## Acessibilidade

- Botão por célula com o texto completo; foco visível; o detalhe prende o foco, fecha com Esc e devolve o foco
  ao botão.
- Hover discreto: balão com o ponto sob o cursor, posicionado por `placeTip` sem cobrir o desenho; o balão é
  decorativo (`aria-hidden`), porque o mesmo dado está no texto e no detalhe.
- Com raio-X (`column.xray` dentro de um `XrayProvider`), o valor ao lado vira o gatilho do raio-X e o desenho
  continua abrindo a série.
