# ReportCard · contrato (0.5.0-rc.9)

Carta colecionável de um relatório: série e situação no topo, arte com o minigráfico, título em até 2 linhas, um número com a
variação e o rodapé com a data do dado e a fonte. Proporção 5:7; funciona de 196 a 360 px de largura (a arte cede altura;
título, número e rodapé nunca encolhem).

A carta não faz rede nem polling. Recebe `ReportCardData` pronto (ou o adaptador `reportCardFromRecord` de uma linha plana) e
devolve eventos por callback.

## Uso

```tsx
import { ReportCard, reportCardFromRecord } from "@rbbt/ui";
import "@rbbt/ui/styles.css";

const card = reportCardFromRecord(row, { formats: { moeda: { style: "currency", currency: "BRL", notation: "compact" } } });
<ReportCard card={card!} icon={<Store />} id="carta-Q03" onOpen={(id) => abrirVerso(id)} />;
```

## Props

| Prop | Tipo | Padrão | Notas |
| --- | --- | --- | --- |
| `card` | `ReportCardData` | — | Pode faltar só em `loading` (esqueleto completo). |
| `status` | `WidgetStatus` | `ready` | `partial` e `stale` acrescentam o selo; `loading`, `empty`, `error` e `restricted` mostram a carta sem número e sem abrir o verso. |
| `icon` | `ReactNode` | colunas | Ícone ou arte da área. |
| `onOpen` | `(id) => void` | — | Clique, Enter ou Espaço. A carta gira 90° e chama; com movimento reduzido, chama direto. |
| `onRetry` | `(id?) => void` | — | “Tentar de novo” no estado `error`. |
| `favorite` / `onFavoriteChange` | `boolean` / `(id, favorito) => void` | — | Com o callback, aparece a estrela (`aria-pressed`). O consumidor grava. |
| `id` | `string` | — | Id do botão da carta; o verso devolve o foco a ele. |
| `locale` / `timeZone` | `string` | `pt-BR` / do navegador | Horários da execução no fuso informado. |
| `messages` | `Partial<ReportCardMessages>` | pt-BR | Textos dos estados e dos selos. |
| `previewPointer` | `{ x, y }` | — | Só para prévias e documentação: fixa o hover. |

## Dados (`ReportCardData`)

- `id` (ex.: "Q03"), `serial` ("03/45"), `title`, `area`, `owner`.
- `status: "ready" | "prepared" | "stopped"`: a raridade. Pronto = moldura holográfica e selo `BadgeCheck`; preparado =
  metálica e `ScanSearch`; parado = fosca e `CirclePause`. Sempre com ícone e texto, nunca só cor. `statusReason` é obrigatório
  no parado.
- `headline: { label, value: number | null, format: ValueFormat, missingReason?, delta? }`. `value: null` mostra “sem número” e o
  motivo; nunca vira zero. `delta: { value, label, polarity: Polarity, mode?: DeltaMode }`: `percent` (padrão, razão),
  `points` (p.p.) ou `absolute` (na unidade do número).
- `spark: { at, value: number | null }[]`: minigráfico SVG leve (`Sparkline`). Sem número não há desenho: a arte fica com a linha
  tracejada.
- `dataAsOf` (dia ISO do retrato, mostrado em UTC como dia de calendário), `savedAt` (instante ISO), `source`.
- `stale` (selo “Desatualizado”), `partial` (selo “Parcial”).
- `run: ReportRun`: `queued`, `running`, `blocked` e `failed` aparecem como selo na arte (“Na fila · 2º”, “Rodando desde
  11:05”, “Execução bloqueada”, “Execução falhou”). `idle` e `updated` ficam só no verso.

## Acessibilidade

- A carta é um `<button aria-haspopup="dialog">`. O nome vem do próprio conteúdo, na ordem série, situação, área, título,
  número, variação por extenso, data do dado e fonte (sem `aria-label`, para não divergir do texto visível).
- A situação, os selos e a execução têm sempre ícone e texto. Texto com contraste de 4,5:1; anel, ícones e bordas com 3:1.
- Tab percorre as cartas; Enter ou Espaço abre. As cartas sem número (`loading`, `empty`, `error`, `restricted`) não são botões:
  o Tab pula para a próxima, e a carta em erro oferece “Tentar de novo”.
- `reportCardLabel(card)` devolve a frase completa (série, título, situação, número e data) para quem precisar dela fora da carta.

## Movimento (só Motion)

- Hover e foco: inclinação por mola com o vetor dos dois eixos limitado a 6° (`REPORT_TILT_MAX`), a carta sobe 6 px e o
  reflexo aparece por opacidade.
- Clique: a carta gira 90° (0,2 s) antes de `onOpen`.
- Movimento reduzido: sem inclinação, sem reflexo e sem virada.
- Sem animação em CSS (quadros-chave, propriedade de animação, atraso ou transição de entrada) e sem laço de quadros do
  navegador nos arquivos da carta.

## Tema

Tokens do cliente: `--rb-featured-from/to` (a arte, via `--rb-report-art-from/to`), `accent`, `highlight`, `signal`.
Claro e escuro, famílias Glass e Smooth. Para alinhar a arte a outra peça (ex.: a EvolutionHero do workspace), troque só
`--rb-report-art-from/to`.

## Adaptador

`reportCardFromRecord(linha, mapping?)` lê uma linha plana. Os campos têm os nomes do contrato (`id`, `title`, `value`,
`deltaValue`, `runState`, `queuePosition`…) e podem ser renomeados ou apontar para caminhos com pontos (`mapping.fields`).
Situações em português (“pronto”, “preparado”, “parado”) já são aceitas; outras via `statusAliases`. Regras:

- sem `id` → `null`;
- número ausente, vazio ou inválido → `null` com o motivo (“Valor inválido na fonte”), nunca zero; `"0"` continua zero;
- situação desconhecida → parado, com o motivo “Situação não reconhecida: …”;
- datas `AAAA-MM-DD` ou `dd/mm/aaaa` viram o dia ISO; o resto é descartado.

Migração a partir da rc.8: veja `reports-migracao.md`.
