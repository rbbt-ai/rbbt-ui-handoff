# Workspace em mosaico · contrato

Versão do pacote: `@rbbt/ui@0.5.0-rc.12` · estado: **candidato para revisão visual** (o aceite é do Thiago e nunca é inferido). Tudo é aditivo: sem as props novas, cada componente é o mesmo da rc.11.

Peças: barra lateral do `WorkspaceShell`, `BentoGrid`/`BentoItem`, `StatCard` `variant="hero"`, `ProportionCard`, `AgentActivityCard`, `BridgeChart`, `ComparisonRow.polarity` e `density="compact"` no `InsightCard` e nas `DivergingBars`. Decisões e medidas: `docs/workspace-mosaico/DECISOES.md` no repositório. Passo a passo: [Receita, passo 9](receita-workspace.md). Stories: Workspace › Mosaico (Visão geral, Glass, Barra recolhida, Carregando, Módulo-molde, Composição), Widgets › Ponte em cascata e Widgets › ComparisonTable › Polaridade por linha (DRE).

## 1. `WorkspaceShell` com barra lateral

| Prop | Padrão | O que faz |
| --- | --- | --- |
| `navigation` | `"top"` | `"sidebar"` liga a barra lateral de ícones. `"top"` é a navegação da rc.11. |
| `groups` | — | Grupos da barra (`{ id, label }`). Cada módulo diz o seu em `module.group`. Módulos sem grupo vêm primeiro. |
| `module.badge` | — | Contador de pendências. `0`, `null` e ausente não mostram nada; acima de 99 vira "99+". |
| `module.badgeLabel` | "N pendentes" | Texto do badge para leitor de tela. |
| `sidebarCollapsed` / `onSidebarCollapsedChange` | interno | Recolhida (só ícones, 72 px) ou expandida. Abaixo de 1180 px de contêiner a barra recolhe sozinha. |
| `contextBar` | — | Barra de contexto fixa no topo do conteúdo (ex.: `ContextBar` com região, período e "atualizado em"). |

- **Teclado e leitor de tela:** `<nav aria-label>` com listas por grupo (`aria-labelledby`), o item atual com `aria-current="page"`, o botão de recolher com `aria-expanded` e `aria-controls`, o link "Ir para o conteúdo" primeiro no Tab.
- **Celular (contêiner < 768 px): gaveta.** A barra some e entra a barra compacta fixa: "Menu" (abre a gaveta modal, foco preso, Esc e clique fora fecham, foco volta ao "Menu"), marca, nome do módulo e troca de tema, todos com alvo de 44 px. O título da barra de contexto continua como `h1` só para leitor de tela, para não repetir o nome do módulo.
- As ações do consumidor (`actions`) aparecem uma vez só, à direita da barra de contexto.

## 2. `BentoGrid` e `BentoItem`

| Prop | Padrão | O que faz |
| --- | --- | --- |
| `BentoGrid.density` | `"comfortable"` | `"compact"` reduz o gutter para 12 px e a altura mínima das linhas. |
| `BentoGrid.label` | — | Nome da região para leitor de tela. |
| `BentoItem.span` | `1` | Colunas de 1 a 4 (em quartos) ou, com `of={3}`, em terços. |
| `BentoItem.of` | `4` | `3` para terços (1/3, 2/3, 3/3). |
| `BentoItem.rows` | `1` | Linhas de 1 a 4 (só a partir de 2 colunas). |

- **Colunas pelo contêiner, não pela janela:** 4 a partir de 880 px, 2 de 540 a 879 px e 1 abaixo de 540 px. Com 2 colunas, spans 3 e 4 viram 2; com 1 coluna, tudo vira 1.
- **Gutter único** na horizontal e na vertical: 20 px com 4 colunas e 16 px com 2 ou 1 (confortável).
- **Sem `dense`:** a ordem visual é a do DOM, que é a ordem de leitura e de Tab.
- **Regra de altura:** a grade de um módulo cabe em até 1,5 tela a 1440×900 (teste de geometria). Se não couber, use as densidades compactas ou abra o detalhe sob demanda.

## 3. `StatCard` `variant="hero"`

- `trend: { values: (number | null)[], label }` desenha o minigráfico. `null` interrompe a linha (semana sem leitura), e o `label` é o nome acessível.
- `comparisons: { id, label, delta, reference? }[]`: linhas como "vs budget" e "vs anterior", com o valor de referência e a pílula de variação (cor + seta + texto). Com `delta: null` aparece "sem dado", nunca 0%.
- O fundo usa o gradiente de destaque do tema (`--rb-featured-from/to`, com tema de cliente). É **o único destaque cromático da tela**: use um hero por módulo.

## 4. `ProportionCard`

- `segments: { id, label, value: number | null, kind?: "highlight" | "unknown", note? }[]`, `shape: "ring" | "bar"`, `format`, `totalLabel`, `period`, `scope`, `defaultTableOpen`, mais os estados do `Panel` (`status`, `partialNote`, `onRetry`, `source`, `updatedAt`).
- Um segmento em destaque (cor do tema), os demais neutros, e "a identificar" (`kind: "unknown"`) em hachura. Legenda com valor e %.
- **Ausência ≠ zero:** com `value: null` o segmento não é desenhado nem somado. Na legenda ele aparece como "sem dado", e o total vira "parcial".
- "Ver tabela" (`aria-expanded`) abre a tabela alternativa.

## 5. `AgentActivityCard`

- `items: { id, name, metric, state, time?, stateLabel? }[]` com `state` igual a `done`, `running`, `attention`, `failed` ou `idle`. O estado aparece em cor + ícone + texto, e `stateLabel` troca o texto.
- `maxItems` (padrão 4), `period`, `onOpenItem(item)` (o link de cada linha é callback, sem rota na biblioteca) e `onShowAll` ("Ver todos (N)" quando há mais itens que `maxItems`).
- Estados carregando, vazio ("Nenhuma atividade de agente hoje."), parcial e erro.

## 6. `BridgeChart` (ponte em cascata, B-002)

- `steps: { id, label, kind: "total" | "delta", value: number | null, note? }[]`, `polarity`, `baseline: "auto" | "zero"`, `valueFormat`, `highlightId` (padrão: a última âncora).
- Cada variação mostra o valor com sinal, o % sobre a âncora anterior e a leitura pela polaridade (cor + ícone + texto).
- Cada âncora é conferida contra a anterior mais as variações: "fecha com as etapas", "não fecha: diferença de X" (aviso visível) ou "sem como conferir".
- `null` vira placeholder hachurado com "sem dado" e não soma. Com eixo `auto` cortado, um aviso fica visível.
- Tabela alternativa em "Ver tabela". É irmão do `ResultWaterfall`, que continua decompondo volume, preço e mix a partir de itens.

## 7. `ComparisonRow.polarity` (B-003)

- `polarity` na linha sobrepõe a da coluna, só nas colunas que já têm polaridade (as de variação). A célula leva cor + ícone (✓ favorável, ⚠ desfavorável) + texto.
- Subtotal e total: com **uma** polaridade efetiva nas linhas, herdam essa; com polaridades misturadas, ficam **neutros** com o marcador "misto" e o motivo (dica e leitor de tela).
- O CSV não leva tom. As funções puras `cellPolarity`, `sharedPolarity` e `hasMixedPolarity` são exportadas.

## 8. `density="compact"` (células de mosaico)

- `InsightCard`: sem os parágrafos de apoio, e a força (nível e motivo) fica só para leitor de tela. Manchete, números, evidência, "Abrir", período, lojas e origem continuam visíveis.
- `DivergingBars`: em contêiner estreito, o rótulo fica ao lado da barra (coluna de 6,5rem) em vez de em cima. Cor, ícone, texto e tabela não mudam.
- O padrão (`"regular"`) é o da rc.11.

## Movimento

Entradas só com Motion (`RbEntrance`, `useEntrance`) e respeitando `prefers-reduced-motion`. Sem `@keyframes`, `animation`, `transition-delay`, transição de entrada nem `requestAnimationFrame`. A gaveta abre sem animação de entrada.
