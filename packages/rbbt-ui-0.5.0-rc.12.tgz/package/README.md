# @rbbt/ui

Widgets genéricos e reutilizáveis para Ravi Pages. Mesmo componente em contextos, clientes e usuários diferentes, mudando só dados, tema e configuração.

- **Versão:** `0.5.0-rc.12`: o **workspace em mosaico**. Traz a barra lateral do `WorkspaceShell` (`navigation="sidebar"`, com gaveta no celular), a grade `BentoGrid`/`BentoItem`, o `StatCard` `variant="hero"`, a proporção (`ProportionCard`), o status dos agentes (`AgentActivityCard`), a ponte em cascata (`BridgeChart`, B-002), a polaridade por linha na `ComparisonTable` (B-003) e `density="compact"` no `InsightCard` e nas `DivergingBars` ([contrato](docs/workspace-mosaico.md), [Receita, passo 9](docs/receita-workspace.md)). Tudo é aditivo; é candidato local. Na rc.11, na anatomia `full` do `ContextBar` (a padrão), o período De/Até virou um **campo igual aos vizinhos** (rótulo em cima, mesma caixa e mesmo foco do `SelectField`), também disponível solto com `appearance="field"`; e as docs ganham a nota **CSS do consumidor** (o pacote usa `@layer`; CSS global sem camada vence o pacote). A rc.10 trouxe o **seletor de período De/Até** (`DateRangePicker`, [contrato](docs/date-range-picker.md), [migração](docs/date-range-picker-migracao.md)), ligado ao `ContextBar` (filtro `kind: "date-range"`), e `formatDateRangeLabel` para o período em texto do `PageContextProvider` (que não muda); visual aprovado pelo Thiago em 12/11/2026, local. A rc.9 trouxe as **cartas de relatório**: a carta colecionável (`ReportCard`, [contrato](docs/report-card.md)), o baralho com busca, filtros, ordem e contadores (`ReportDeck`, [contrato](docs/report-deck.md)) e o verso em modal (`ReportDialog`, [contrato](docs/report-dialog.md)), com os adaptadores `reportCardFromRecord` e `reportDetailFromRecords` e as [notas de migração](docs/reports-migracao.md); candidato local. A rc.8 é a do **Workspace Glass** com o Lote 5 · Densidade e texto: **tabela com minigráficos** sobre a `ComparisonTable` (`sparklineColumnCell`, [contrato](docs/sparkline-table.md)) e **card de insight em texto** com link para a evidência (`InsightCard` e `InsightList`, [contrato](docs/insight-card.md)); candidato local. A rc.7 trouxe o Lote 4 · Decisão e efeito: **fila de prioridades v2** com impacto estimado, urgência, confiança, responsável e o porquê de cada posição (`PriorityQueue`, [contrato](docs/priority-queue.md)), **cartão de decisão** que nasce de um alerta ou da fila com o contexto original congelado (`DecisionCard`, [contrato](docs/decision-card.md)), **placar de efeito da ação** com antes → meta → depois, janela de avaliação e a ressalva de causalidade sempre visível (`EffectScoreboard`, [contrato](docs/effect-scoreboard.md)) e **raio-X do indicador**, que abre de qualquer número com fórmula, fonte, filtros, exclusões e conferência do total (`XrayProvider` + `XrayTrigger`, [contrato](docs/kpi-xray.md)); ações e persistência só por callbacks; candidato local. A rc.6 trouxe o Lote 3 · Tempo e contexto: **pequenos múltiplos** com escala comum e quedas em texto (`SmallMultiples`, [contrato](docs/small-multiples.md)), **calendário de calor com eventos** (`CalendarHeatmap`, [contrato](docs/calendar-heatmap.md)) e **anotações de eventos no gráfico de evolução** (prop opcional `annotations` do `EvolutionChart`, [contrato](docs/evolution-chart.md)), sobre o formato comum de eventos `TimeEvent`, candidato local. A rc.5 trouxe o Lote 2 · Resultado e desvio: **cascata do resultado** em volume, preço e mix (`ResultWaterfall`, [contrato](docs/result-waterfall.md)), **meta × realizado** em bullet que cabe numa linha de tabela (`BulletBar` e `BulletList`, [contrato](docs/bullet-bar.md)), **Pareto 80/20** (`ParetoChart`, [contrato](docs/pareto.md)) e **barras divergentes** com polaridade declarada (`DivergingBars`, [contrato](docs/diverging-bars.md)), candidato local. A rc.4 trouxe o Lote 1 · Estoque e capital: **capital em estoque** (`StockCapital`, [contrato](docs/stock-capital.md)), **quadrante velocidade × cobertura** (`CoverageQuadrant`, [contrato](docs/coverage-quadrant.md)) e **mix vendido × disponível** (`MixBalance`, [contrato](docs/mix-balance.md)), candidato local. A rc.3 trouxe o **mapa de calor** (`Heatmap`, [contrato](docs/heatmap.md)), do Lote 0. Traz a família Glass ao lado do Smooth (que continua padrão), o tema de cliente por configuração, o modelo de workspace, os componentes de Estoque, Plano de ação e Qualidade, a entrada animada com Motion e a [Receita · montar um workspace](docs/receita-workspace.md). A rc.2 corrige as lacunas da reconstrução e os achados D1–D3 (valores compactos distinguíveis, menu do celular, "Ordenar" sem corte), abre o simulador sob demanda e lê cenários prontos em JSON. Tudo é aditivo em relação à 0.4. Thiago aprovou as Prévias 1, 2 e 3 (a 3 como prova técnica) em 29/10; a rc.2 espera o aceite. Novidades e migração no [CHANGELOG](CHANGELOG.md).
- **Distribuição:** tarball local (`npm pack`). Publicação em registro npm não está autorizada.
- **Camadas:** fundação (tokens e tema) → primitivos → widgets → adaptadores.

## Conteúdo desta versão

| Camada | Exportações |
| --- | --- |
| Fundação | `RbTheme` (com `family` e `client` desde a 0.5), `useRbTheme`, `tokenVariables`, `tokensToStyle`, `defineClientTheme`, `clientThemeTokens`, tipos `RbThemeTokens`, `RbThemeMode`, `RbThemeFamily`, `RbDensity`, `RbClientTheme`, `RbClientLogo` |
| Formatação | `formatValue`, `distinctCompactFormat` (rc.2), `classifyValue`, `compareValues`, `formatDelta`, `signSentiment`, `formatRelativeTime`, `formatDateTime`, `toDate`, `formatDay`, `formatDayRange`, `dayRange`, textos padrão (`stateMessages`, `methodologyMessages`…) |
| Primitivos | `ActionButton`, `InfoPopover`, `Skeleton`, `Panel`, `WidgetState`, `SegmentedControl`, `SelectField`, `StatusChip`, `ScopeNote`, `Marker`, `Methodology`, `MethodologyList`, `useWidgetFrame` |
| Linguagem v3 (0.3) | `OpenCard`, `DetailPanel`, `useUrlParam`, `PillSelect`, `PillTabs`, `FilterPills`, `StatusDot`, `IconSquare`, `ProgressRing`, `HalfGauge`, `gaugeFill`, `Bars`, `highlightedBar`, `Figure`, `figureParts`, `numberSeparators` |
| Linguagem smooth (0.4) | `IconCircle`, `DeltaPill`, `StatTile`, `ColumnChart`, `niceScale`, `highlightedColumn`, `SegmentedGauge`, `filledSegments`, `segmentPath` |
| Contexto da página | `PageContextProvider`, `usePageContext`, `resolveProvenance`, `useWidgetProvenance` (anatomia `full` ou `lean`) |
| Widgets | `TrendIndicator`, `Sparkline`, `EvolutionChart`, `ComparisonTable`, `PriorityList`, `ContextBar`, `StatCard`, `MixExplorer` |
| Modelo de workspace (0.5) | `WorkspaceShell`, `FilterBar`, `WorkspaceHeader`, `WorkspaceSection`, `WorkspaceFooter`, `workspaceMessages` |
| Operação (0.5) | `StockGrid`, `TransferSimulator`, `TransferSimulatorDialog` (rc.2, sob demanda), `ActionBoard`, `QualityOverview`, `operationsMessages` |
| Movimento (0.5) | `RbEntrance`, `useEntrance`, `useReplayEntrance`, `CountUp`, `useCountUp`, `readMotionTokens`, `entranceDelay` |
| Funções puras dos widgets | `prepareEvolution`, `comparisonToCsv`, `checkTotals`, `checkDerived`, `deriveValue`, `sumValues`, `hasMethodologyContent`, `formPointState`, `classifyFormPoint`, `countForm`, `formGeometry`, `formatRank` |
| Adaptadores | `summarizeSeries`, `indicatorDataFromRecord`, `toMetricValue`; desde a 0.5, `coverageFromRecords`, `stockFromRecords`, `coverageWeeks`, `ruptureSizes`, `simulateTransfer`, `actionsFromRecords`, `canMoveAction`, `requiresEvidence`, `ACTION_STAGES`, `coverageMapFromRecords`; desde a rc.2, `transferLimits`, `clampTransferQuantity`, `readPath` e os de cenários prontos em JSON: `createScenarioReader`, `pickScenario`, `fillTemplate`, `templateMarkers`, `formatByName`, `iconByName` |

Progresso de meta e histórico de atividades seguem no plano (M3), depois da aprovação visual.

## Instalação

Na Page (projeto Vite + React 19), com o tarball gerado por `npm run pack` na raiz do repositório:

```bash
npm install --save-exact ./rbbt-ui-0.5.0-rc.12.tgz react@19.3.1 react-dom@19.3.1
```

A Page fixa a versão do tarball. Mudanças incompatíveis exigem nova versão, nota de migração no `CHANGELOG.md` e revisão de Thiago.

Para montar um workspace inteiro (topo com módulos, filtros, Glass, tema de cliente e os seis módulos), siga a [Receita · montar um workspace](docs/receita-workspace.md). Ela traz um exemplo completo com cliente fictício, compilado e aberto no navegador pelo `npm run pack`.

## Uso

```tsx
import "@rbbt/ui/styles.css";
import "@rbbt/ui/fonts.css"; // opcional: Plus Jakarta Sans (padrão v3), Mona Sans e Hubot Sans (OFL)
import { EvolutionChart, RbTheme, TrendIndicator } from "@rbbt/ui";

export function Painel() {
  return (
    <RbTheme canvas> {/* claro por padrão; mode="dark" para o escuro */}
      <TrendIndicator
        label="Receita líquida"
        data={{ value: 1284600, previousValue: 1142900, series: [968000, 1142900, 1284600] }}
        format={{ style: "currency", currency: "BRL" }}
        comparison={{ label: "set/2026" }}
      />
      <EvolutionChart title="Ritmo de vendas" data={dadosDoPeriodo} format={{ style: "currency", currency: "BRL" }} />
    </RbTheme>
  );
}
```

- `styles.css` não aplica reset global: só tokens `--rb-*`, utilitários com prefixo `rb:` e classes `rb-*`.
- Os widgets não fazem chamadas de rede. Dados entram por props; adaptadores convertem séries e linhas antes.
- O ECharts é carregado sob demanda pelo `EvolutionChart`: páginas sem gráfico não baixam o motor.
- Credenciais, identidade de cliente e regras de negócio ficam fora do pacote.

## Documentação

- [Linguagem v3 e contratos dos componentes novos](docs/v3.md) (card que abre, painel de detalhe, pílulas, status, ícone, anel, gauge, barras, número).
- [Receita · montar um workspace](docs/receita-workspace.md) (0.5): modelo + tema + componentes + configuração.
- Contratos: [TrendIndicator](docs/trend-indicator.md), [EvolutionChart](docs/evolution-chart.md), [ComparisonTable](docs/comparison-table.md), [PriorityList](docs/priority-list.md), [ContextBar e ScopeNote](docs/context-bar.md), [StatCard](docs/stat-card.md), [MixExplorer](docs/mix-explorer.md), [Estoque](docs/estoque.md), [Plano de ação](docs/plano-de-acao.md), [Qualidade](docs/qualidade.md).
- [Temas, identidade e densidade](docs/theming.md).
- Catálogo Storybook com exemplos, estados, variantes e API (`npm run storybook` na raiz).

## Compatibilidade

React 19 · navegadores com container queries e `color-mix()` (Chrome/Edge 111+, Safari 16.4+, Firefox 113+) · ESM.
