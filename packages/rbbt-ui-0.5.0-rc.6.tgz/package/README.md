# @rbbt/ui

Widgets genéricos e reutilizáveis para Ravi Pages. Mesmo componente em contextos, clientes e usuários diferentes, mudando só dados, tema e configuração.

- **Versão:** `0.5.0-rc.6`, a do **Workspace Glass** com o Lote 3 · Tempo e contexto: **pequenos múltiplos** com escala comum e quedas em texto (`SmallMultiples`, [contrato](docs/small-multiples.md)), **calendário de calor com eventos** (`CalendarHeatmap`, [contrato](docs/calendar-heatmap.md)) e **anotações de eventos no gráfico de evolução** (prop opcional `annotations` do `EvolutionChart`, [contrato](docs/evolution-chart.md)), sobre o formato comum de eventos `TimeEvent`, candidato local. A rc.5 trouxe o Lote 2 · Resultado e desvio: **cascata do resultado** em volume, preço e mix (`ResultWaterfall`, [contrato](docs/result-waterfall.md)), **meta × realizado** em bullet que cabe numa linha de tabela (`BulletBar` e `BulletList`, [contrato](docs/bullet-bar.md)), **Pareto 80/20** (`ParetoChart`, [contrato](docs/pareto.md)) e **barras divergentes** com polaridade declarada (`DivergingBars`, [contrato](docs/diverging-bars.md)), candidato local. A rc.4 trouxe o Lote 1 · Estoque e capital: **capital em estoque** (`StockCapital`, [contrato](docs/stock-capital.md)), **quadrante velocidade × cobertura** (`CoverageQuadrant`, [contrato](docs/coverage-quadrant.md)) e **mix vendido × disponível** (`MixBalance`, [contrato](docs/mix-balance.md)), candidato local. A rc.3 trouxe o **mapa de calor** (`Heatmap`, [contrato](docs/heatmap.md)), do Lote 0. Traz a família Glass ao lado do Smooth (que continua padrão), o tema de cliente por configuração, o modelo de workspace, os componentes de Estoque, Plano de ação e Qualidade, a entrada animada com Motion e a [Receita · montar um workspace](docs/receita-workspace.md). A rc.2 corrige as lacunas da reconstrução e os achados D1–D3 (valores compactos distinguíveis, menu do celular, "Ordenar" sem corte), abre o simulador sob demanda e lê cenários prontos em JSON. Tudo é aditivo em relação à 0.4. Thiago aprovou as Prévias 1, 2 e 3 (a 3 como prova técnica) em 29/10; a rc.2 espera o aceite. Novidades e migração no [CHANGELOG](CHANGELOG.md).
- **Distribuição:** tarball local (`npm pack`). Publicação em registro npm não está autorizada.
- **Camadas:** fundação (tokens e tema) → primitivos → widgets → adaptadores.

## Conteúdo desta versão

| Camada | Exportações |
| --- | --- |
| Fundação | `RbTheme` (com `family` e `client` desde a 0.5), `useRbTheme`, `tokenVariables`, `tokensToStyle`, `defineClientTheme`, `clientThemeTokens`, tipos `RbThemeTokens`, `RbThemeMode`, `RbThemeFamily`, `RbDensity`, `RbClientTheme`, `RbClientLogo` |
| Formatação | `formatValue`, `distinctCompactFormat` (rc.2), `classifyValue`, `compareValues`, `formatDelta`, `signSentiment`, `formatRelativeTime`, `formatDateTime`, `toDate`, `formatDay`, `formatDayRange`, `dayRange`, textos padrão (`stateMessages`, `methodologyMessages`…) |
| Primitivos | `ActionButton`, `InfoPopover`, `Skeleton`, `Panel`, `WidgetState`, `SegmentedControl`, `SelectField`, `StatusChip`, `ScopeNote`, `Marker`, `Methodology`, `MethodologyList`, `useWidgetFrame` |
| Linguagem v3 (0.3) | `OpenCard`, `DetailPanel`, `useUrlParam`, `PillSelect`, `PillTabs`, `FilterPills`, `StatusDot`, `IconSquare`, `ProgressRing`, `HalfGauge`, `gaugeFill`, `Bars`, `highlightedBar`, `Figure`, `figureParts`, `numberSeparators` |
| Linguagem smooth (0.4) | `IconCircle`, `DeltaPill`, `StatTile`, `ColumnChart`, `niceScale`, `highlightedColumn`, `SegmentedGauge`, `filledSegments`, `segmentPath` |
| Contexto da página | `PageContextProvider`, `usePageContext`, `resolveProvenance`, `useWidgetProvenance` (anatomia `full` ou `lean`) |
| Widgets | `TrendIndicator`, `Sparkline`, `EvolutionChart`, `ComparisonTable`, `PriorityList`, `ContextBar`, `StatCard`, `MixExplorer` |
| Modelo de workspace (0.5) | `WorkspaceShell`, `FilterBar`, `WorkspaceHeader`, `WorkspaceSection`, `WorkspaceFooter`, `workspaceMessages` |
| Operação (0.5) | `StockGrid`, `TransferSimulator`, `TransferSimulatorDialog` (rc.2, sob demanda), `ActionBoard`, `QualityOverview`, `operationsMessages` |
| Movimento (0.5) | `RbEntrance`, `useEntrance`, `useReplayEntrance`, `CountUp`, `useCountUp`, `readMotionTokens`, `entranceDelay` |
| Funções puras dos widgets | `prepareEvolution`, `comparisonToCsv`, `checkTotals`, `checkDerived`, `deriveValue`, `sumValues`, `hasMethodologyContent`, `formPointState`, `classifyFormPoint`, `countForm`, `formGeometry`, `formatRank` |
| Adaptadores | `summarizeSeries`, `indicatorDataFromRecord`, `toMetricValue`; desde a 0.5, `coverageFromRecords`, `stockFromRecords`, `coverageWeeks`, `ruptureSizes`, `simulateTransfer`, `actionsFromRecords`, `canMoveAction`, `requiresEvidence`, `ACTION_STAGES`, `coverageMapFromRecords`; desde a rc.2, `transferLimits`, `clampTransferQuantity`, `readPath` e os de cenários prontos em JSON: `createScenarioReader`, `pickScenario`, `fillTemplate`, `templateMarkers`, `formatByName`, `iconByName` |

Progresso de meta e histórico de atividades seguem no plano (M3), depois da aprovação visual.

## Instalação

Na Page (projeto Vite + React 19), com o tarball gerado por `npm run pack` na raiz do repositório:

```bash
npm install --save-exact ./rbbt-ui-0.5.0-rc.6.tgz react@19.3.1 react-dom@19.3.1
```

A Page fixa a versão do tarball. Mudanças incompatíveis exigem nova versão, nota de migração no `CHANGELOG.md` e revisão de Thiago.

Para montar um workspace inteiro (topo com módulos, filtros, Glass, tema de cliente e os seis módulos), siga a [Receita · montar um workspace](docs/receita-workspace.md). Ela traz um exemplo completo com cliente fictício, compilado e aberto no navegador pelo `npm run pack`.

## Uso

```tsx
import "@rbbt/ui/styles.css";
import "@rbbt/ui/fonts.css"; // opcional: Plus Jakarta Sans (padrão v3), Mona Sans e Hubot Sans (OFL)
import { EvolutionChart, RbTheme, TrendIndicator } from "@rbbt/ui";

export function Painel() {
  return (
    <RbTheme canvas> {/* claro por padrão; mode="dark" para o escuro */}
      <TrendIndicator
        label="Receita líquida"
        data={{ value: 1284600, previousValue: 1142900, series: [968000, 1142900, 1284600] }}
        format={{ style: "currency", currency: "BRL" }}
        comparison={{ label: "set/2026" }}
      />
      <EvolutionChart title="Ritmo de vendas" data={dadosDoPeriodo} format={{ style: "currency", currency: "BRL" }} />
    </RbTheme>
  );
}
```

- `styles.css` não aplica reset global: só tokens `--rb-*`, utilitários com prefixo `rb:` e classes `rb-*`.
- Os widgets não fazem chamadas de rede. Dados entram por props; adaptadores convertem séries e linhas antes.
- O ECharts é carregado sob demanda pelo `EvolutionChart`: páginas sem gráfico não baixam o motor.
- Credenciais, identidade de cliente e regras de negócio ficam fora do pacote.

## Documentação

- [Linguagem v3 e contratos dos componentes novos](docs/v3.md) (card que abre, painel de detalhe, pílulas, status, ícone, anel, gauge, barras, número).
- [Receita · montar um workspace](docs/receita-workspace.md) (0.5): modelo + tema + componentes + configuração.
- Contratos: [TrendIndicator](docs/trend-indicator.md), [EvolutionChart](docs/evolution-chart.md), [ComparisonTable](docs/comparison-table.md), [PriorityList](docs/priority-list.md), [ContextBar e ScopeNote](docs/context-bar.md), [StatCard](docs/stat-card.md), [MixExplorer](docs/mix-explorer.md), [Estoque](docs/estoque.md), [Plano de ação](docs/plano-de-acao.md), [Qualidade](docs/qualidade.md).
- [Temas, identidade e densidade](docs/theming.md).
- Catálogo Storybook com exemplos, estados, variantes e API (`npm run storybook` na raiz).

## Compatibilidade

React 19 · navegadores com container queries e `color-mix()` (Chrome/Edge 111+, Safari 16.4+, Firefox 113+) · ESM.
